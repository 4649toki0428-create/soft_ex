#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define W 12
#define H 8
typedef struct{int h;int a;}P;
typedef struct{char m[H][W+1];P p;int x;int y;}S;

int main(){
S s;char*b[H]={"############","#..........#","#..........#","#....E.....#","#..........#","#....I.....#","#.........G#","############"};
for(int i=0;i<H;i++)strcpy(s.m[i],b[i]);
s.x=1;s.y=1;s.p.h=50;s.p.a=10;
while(1){
printf("\n===RPG===\nHP:%d\n\n",s.p.h);
for(int y=0;y<H;y++){for(int x=0;x<W;x++){if(x==s.x&&y==s.y)printf("@");else printf("%c",s.m[y][x]);}printf("\n");}
char c;printf("> ");scanf(" %c",&c);if(c=='q')break;
int nx=s.x,ny=s.y;
if(c=='w')ny--;
if(c=='s')ny++;
if(c=='a')nx--;
if(c=='d')nx++;
if(s.m[ny][nx]!='#'){s.x=nx;s.y=ny;}
char t=s.m[s.y][s.x];
if(t=='E'){
int eh=0;
printf("戦闘開始\n");
while(eh>0){
int d=rand()%s.p.a;
eh-=d;
printf("攻撃 %d ダメージ\n",d);
}
printf("敵を倒した\n");
}
if(t=='I'){
printf("HP回復\n");
s.p.h+=10;
}
}
return 0;
}
