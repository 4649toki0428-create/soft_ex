#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>
#define W 12
#define H 8
#define TILE_ENEMY 'E'
#define TILE_ITEM  'I'
#define TILE_GOAL  'G'

typedef struct
{
    int player;
    int enemy;
}HP;
typedef struct
{
    char map[H][W+1]; 
    HP hp;
    int x;
    int y;
}GameState;

void    init(GameState*game);
void    draw(const GameState    *game);
int input_move(GameState    *game);
void    handle_tile(GameState   *game);
void    battle(GameState    *game);

void    draw(const  GameState  *game)
{
     char    *map_data[H]={"############","#..........#","#..........#","#....E.....#","#..........#","#....I.....#","#.........G#","############"};
    
    for(int i = 0; i < H; i++)
    {
        strcpy(game->map[i],map_data[i]);
    }
}

int input_move(GameState    *game)
{
    game->x = 1;
    game->y = 1;
    game->hp.player = 50;
    game->hp.enemy = 10;
    printf("\n===RPG===\nHP:%d\n\n",game->hp.player);
    for(int y = 0; y < H; y++){for(int x = 0; x< W; x++)
    {
        if(x == game->x && y == game->y)
        {
            printf("@");
        }
        else
        {
            printf("%c", game->map[y][x]);
        }
        printf("\n");
    }

}  

void    battle(GameState   *game);
{
    {
        printf("戦闘開始\n");
        while(game->hp.enemy > 0 && game->hp.player > 0)
        {
            int damage_enemy = rand()%game -> hp.enemy;

            game->hp.enemy -= damage_enemy;
            printf("プレイヤーの攻撃 %d ダメージ\n",damage_enemy);

            if(game->hp.enemy <= 0) break;
            int damage_player = rand()%game->hp.player;

            game->hp.player -= damage_player;
            printf("敵の攻撃 %d ダメージ\n",damage_player);    
        }
        if(game->hp.enemy <= 0)
        {
            printf("敵を倒した\n");
        }
        if(game->hp.player <= 0)
        {
            printf("ヤラレチャッタ\n==Game Over==\n");
            exit(0);
        }
    }
}

void    handle_tile(GameState   *game);
{
    char tile = game->map[game->y][game->x];

    if(tile == 'E')
    {
        battle(game);
        game->map[game->y][game->x] = '.';
    }
    else if(tile == 'I') 
    {
        printf("HP回復\n");
        game->hp.player += 10;
        game->map[game->y][game->x] = '.';
    }
    else if(tile == 'G')
    {
        printf("==Game Clear!==");
        exit(0);
    }
}

int main()
{
    srand(time(NULL));
    GameState   game;

    while(1)
    {
       draw(&game);

       if(!input_move(&game))
       {
        break;
       }

       handle_title(&game);
    }
    return 0;
}