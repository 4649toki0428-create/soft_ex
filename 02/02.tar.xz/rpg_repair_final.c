#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define Wide 12
#define Hight 8
#define TILE_ENEMY 'E'
#define TILE_ITEM  'I'
#define TILE_GOAL  'G'

typedef struct
{
    int player;
    int enemy;
} HP;

typedef struct
{
    char map[Hight][Wide + 1];
    HP   hp;
    int  x;
    int  y;
} GameState;

/*main関数内の処理を分割*/
void init(GameState *game);
void draw(const GameState *game);
int  input_move(GameState *game);
void handle_tile(GameState *game);
void battle(GameState *game);

/* 初期マップデータ */
void init(GameState *game)
{
    const char *map_data[Hight] = 
    {
        "############", "#..........#", "#..........#", "#....E.....#", "#..........#", "#....I.....#", "#.........G#", "############"
    };

    for (int i = 0; i < Hight; i++)
    {
        strcpy(game->map[i], map_data[i]);
    }

    game->x = 1;
    game->y = 1;
    game->hp.player = 50;
    game->hp.enemy = 10;
}

// プレイヤー表示
void draw(const GameState *game)
{
    printf("\n===RPG===\nHP:%d\n\n", game->hp.player);

    for (int y = 0; y < Hight; y++)
    {
        for (int x = 0; x < Wide; x++)
        {
            if (x == game->x && y == game->y)
            {
                printf("@");
            }
            else
            {
                printf("%c", game->map[y][x]);
            }
        }
        printf("\n");
    }
}

// プレイヤーの移動処理
int input_move(GameState *game)
{
    char c;

    printf("> ");
    scanf(" %c", &c);
    if(c == 'q') return(0);
    
    int nx = game->x, ny = game->y;

    if(c == 'w') ny--;
    if(c == 's') ny++;
    if(c == 'a') nx--;
    if(c == 'd') nx++;

    if (nx >= 0 && nx < Wide && ny >= 0 && ny < Hight && game->map[ny][nx] != '#')
    {
        game->x = nx;
        game->y = ny;
    }
}

// 戦闘システム
void battle(GameState *game)
{
    printf("戦闘開始\n");
    int enemy_hp;
    int player_hp;

    enemy_hp = game->hp.enemy;
    player_hp = game->hp.player;
    while(game->hp.enemy > 0 && game->hp.player > 0)
    {
        int damage_enemy = rand()%enemy_hp;

        game->hp.enemy -= damage_enemy;
        printf("プレイヤーの攻撃 %d ダメージ\n",damage_enemy);

        if(game->hp.enemy <= 0) break;
        int damage_player = rand()%player_hp;

        game->hp.player -= damage_player;
        printf("敵の攻撃 %d ダメージ\n",damage_player);    
    }

    if(game->hp.enemy <= 0)
    {
        printf("敵を倒した\n");
    }

    if(game->hp.player <= 0)
    {
        printf("ヤラレチャッタ\n==Game Over==\n");
        exit(0);
    }
}

// 文字のマスの処理
void handle_tile(GameState *game)
{
    char tile = game->map[game->y][game->x];

    if (tile == TILE_ENEMY)
    {
        battle(game);
        game->map[game->y][game->x] = '.'; 
    }
    else if (tile == TILE_ITEM)
    {
        printf("HP回復！ (+10)\n");
        game->hp.player += 10;
        game->map[game->y][game->x] = '.'; 
    }
    else if (tile == TILE_GOAL)
    {
        printf("==Game Clear!==\n");
        exit(0);
    }
}

int main(void)
{
    srand((unsigned int)time(NULL)); /*rand関数の初期化*/

    GameState game;
    init(&game); 




    while (1)
    {
        draw(&game);

        if (!input_move(&game))
        {
            break;
        }



        handle_tile(&game); 
    }

    return 0;
}