#include<SDL2/SDL.h>
#include<stdio.h>
#include"header.h"

int main(int argc, char* argv[])
{
    
}
