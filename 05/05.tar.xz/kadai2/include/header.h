//インクルードガード
#ifndef HEADER_H
#define HEADER_H

#include<stdio.h>
#include<SDL2/SDL.h>

#define SCREEN_WIDTH 640
#define SCREEN_HEIGHT 480
#define BUTTON_COUNT 3

typedef struct
{
    SDL_Rect rect;
    SDL_Color color;
    char *text;
    int isSelected;
} Button;
#endif