#include"header.h"

void init_buttons(Button buttons[])
{
    buttons[0] = (Button){{100, 50, 120, 50}, {100, 100, 255}, "Image"};
    buttons[1] = (Button){{260, 50, 120, 50}, {100, 255, 100}, "Action"};
    buttons[2] = (Button){{420, 50, 120, 50}, {255, 100, 100}, "Exit"};
}

void draw_buttons(SDL_Renderer *renderer, Button buttons[], int selectedIndex)
{
    for(int i = 0; i < BUTTON_COUNT; i++)
    {
        if(i == selectedIndex)
        {
            
        }
    }
}