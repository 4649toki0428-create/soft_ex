/*****************************************
コンパイル：gcc window.c -lSDL2 -lSDL2_gfx


******************************************/
#include<SDL2/SDL.h>
#include<stdio.h>
#include<SDL2/SDL2_gfxPrimitives.h>

const   int WINDOW_WIDTH = 800;
const   int WINDOW_HEIGHT = 600;
typedef struct
{
    int x;
    int y;
} MOUSE;
typedef struct
{
    int x;
    int y;
    int radius;
    int isDragging;
} CIRCLE;
int isSuccess = 0;

int main(int argc, char *argv[])
{
    //SDLの初期化
    if(SDL_Init(SDL_INIT_VIDEO) < 0)
    {
        printf("SDL Init Error: %s\n", SDL_GetError());
        return -1;
    }

    //ウィンドウの作成
    SDL_Window* window = SDL_CreateWindow
    (
        "kadai1",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        WINDOW_WIDTH, WINDOW_HEIGHT, 0
    );

    //レンダラーの作成
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    int isRunning = 1;
    SDL_Event event;

    //マウスの座標の初期設定
    MOUSE   mouse = {0, 0};

    //円の初期設定
    CIRCLE  circle = {150, 150, 20, 0};

    //四角形の設定
    SDL_Rect targetRect = {600, 400, 100, 100};


    while(isRunning)
    {
        //イベントの処理
        while(SDL_PollEvent(&event))
        {
            //ウィンドウが閉じられた時ゲームを終了
            if(event.type == SDL_QUIT)
            {
                isRunning = 0;
            }
            //escキーが押された時にゲームを終了
            if(event.type == SDL_KEYDOWN)
            {
                if(event.key.keysym.sym == SDLK_ESCAPE)
                {
                    isRunning = 0;
                }
            }
            //マウスがクリックされた時
            if(event.type == SDL_MOUSEBUTTONDOWN)
            {
                if(event.button.button == SDL_BUTTON_LEFT)
                {
                    //マウスと円の中心との距離を計算
                    int dx = mouse.x - circle.x;
                    int dy = mouse.y - circle.y;

                    //距離の2乗 <=　半径の2乗なら、円の内側をクリックしたとみなす                }
                    if((dx * dx) + (dy * dy) <= (circle.radius * circle.radius))
                    {
                        circle.isDragging = 1;
                    }
                }
            }
            //マウスのボタンが離された時
            if(event.type == SDL_MOUSEBUTTONUP)
            {
                if(event.button.button == SDL_BUTTON_LEFT)
                {
                    circle.isDragging = 0;
                    //四角の中に入っているかの判定
                    if(circle.x >= targetRect.x && circle.x <= targetRect.x + targetRect.w &&
                    circle.y >= targetRect.y && circle.y <= targetRect.y + targetRect.h)
                    {
                        isSuccess = 1;
                    }
                    else
                    {
                        isSuccess = 0;
                    }
                }
            }
            //マウスが動いたときに座標を更新
            if(event.type == SDL_MOUSEMOTION)
            {
                mouse.x = event.motion.x;
                mouse.y = event.motion.y;
                if(circle.isDragging == 1)
                {
                    circle.x = mouse.x;
                    circle.y = mouse.y;
                }
            }
        }
        //裏を白で塗りつぶす
        SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
        SDL_RenderClear(renderer);

        //四角形を描画
        SDL_SetRenderDrawColor(renderer, 0, 255, 0, 255);
        SDL_RenderDrawRect(renderer, &targetRect);

        //円を描画
        filledCircleRGBA(renderer, circle.x, circle.y, circle.radius, 255, 100, 100, 255);

        //マウスの座標を表示
        char    coordText[64];
        sprintf(coordText, "x, y = (%d, %d)", mouse.x, mouse.y);

        stringRGBA(renderer, 10, 10, coordText, 0, 0, 0, 255);

        //テキストの追加をする
        if(isSuccess == 1)
        {
            stringRGBA(renderer, WINDOW_WIDTH / 2 - 30, WINDOW_HEIGHT / 2, "Good Job!", 0, 0, 255, 255);
            isRunning = 0;
        }


        //描画内容を反映
        SDL_RenderPresent(renderer);

    }

    //終了処理
    if(isSuccess == 1)
    {
        SDL_Delay(2000);
    }
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();

    return 0;
}