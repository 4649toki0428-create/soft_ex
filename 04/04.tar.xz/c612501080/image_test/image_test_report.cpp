///////////////////////////////////////////////////////////////////////////////
// ソフト実験　デバイスプログラミング
// サンプルプログラム
// レポート用
// 2022年5月 伊藤桃代
// 画像を読み込んで表示
// 参考：北山 洋幸 著
//       OpenCV4基本プログラミング―さらに進化した画像処理ライブラリの定番
//       カットシステム, 2019
///////////////////////////////////////////////////////////////////////////////


//OpenCVを使うためのヘッダをインクルード
#include <opencv2/core.hpp>
#include <opencv2/videoio.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <iostream>
#include <stdio.h>

using namespace std;
using namespace cv;

int main(int argc, char* argv[])
{
    //コマンドライン引数のチェック
    //画像が指定されない場合はエラーメッセージを出力する
    if (argc < 2)
    {
        cout << "画像を指定してください\n";
        return -1;
    }
    
    //コマンドラインで指定した画像ファイルをimage1に読み込む
    Mat image1 = imread(argv[1]);
    
    ////////// 演習課題１ //////////
    //グレースケール化した画像を入力するためのMatクラスのオブジェクトを用意する
    Mat gimage;
    //
    //image1とgimageを使い、cvtColor関数を使用してグレースケール化
    //cvtColor関数の使い方を調べてみよう！
    cvtColor(image1, gimage, COLOR_BGR2GRAY);
    ////////////////////////////////
    
    //読み込んだ画像を「IMAGE」という名前のついたウィンドウに表示する
    //ウィンドウ名を変更したい場合は、"IMAGE"を"画像"や"処理結果"などに自由に変更できる
    imshow("IMAGE", image1);
    
    ////////// 演習課題１ //////////
    //グレースケール画像を表示するための処理を書く
    imshow("GIMAGE", gimage);
    ////////////////////////////////

    //自分の顔画像を対象にエッジ検出
    Mat image_canny;
    Canny(gimage, image_canny, 40.0, 200.0);
    imshow("CANNY", image_canny);

    //画素数をカウント
    int count_non_zero_pizels = countNonZero(image_canny);
    cout << "お前の戦闘力は" << count_non_zero_pizels << "か...\n";

    //なにかキーが押されるまで待つ
    waitKey(0);

    
    ////////// 演習課題１ //////////
    //グレースケール化した画像を保存するための処理を書く
    imwrite("GIMAGE.jpg", gimage);
    ////////////////////////////////

    return 0;
}