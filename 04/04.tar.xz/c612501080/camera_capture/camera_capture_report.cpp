//
// ソフトウェア設計及び実験　サンプルプログラム
// カメラから取得した画像を動画表示する
// 2022年5月　伊藤桃代
//

// 必要に応じて、インクルードファイルを追加してください
#include <opencv2/core.hpp>
#include <opencv2/videoio.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <iostream>
#include <stdio.h>

using namespace cv;
using namespace std;

int main(int, char**)
{
    

    // カメラ画像を取得するための準備
    // VideoCaptureオブジェクト captureを生成する
    // デバイスの番号は0を使用する
    VideoCapture capture(0);

    // カメラから取得した画像を入れるためのMatオブジェクト frameを準備
    Mat frame;
    
    ///// レポート課題 ////////////////////////////////////
    //グレースケール、２値化画像用のMatを用意する必要がある
    Mat gframe, bframe10, bframe100, bframe180;
    //////////////////////////////////////////////////////

    // カメラが正しく開けるか確認
    if (!capture.open(0)) {
        cerr << "カメラが開けません\n";
        return -1;
    }
    
    // カメラの画像サイズを取得しターミナルにメッセージを表示
    // VideoCaptureのgetメソッドにCAP_FRAME_WIDTHとCAP_PROP_FRAME_HEIGHT
    // を指定し、フレームの横サイズと縦サイズを取得する
    int width = capture.get(CAP_PROP_FRAME_WIDTH);
    int height = capture.get(CAP_PROP_FRAME_HEIGHT);
    cout << "画像のサイズは " << width << " x " << height << " です\n";
    
    // ターミナルにメッセージを表示
    cout << "カメラの映像を表示します\n"
        << "終了するには、何かキーを押してください\n";
    
    // whileループでカメラから取得した静止画を表示し続ける
    // 静止画が連続表示されることで動画として確認できる
    while (1)
    {
        //カメラから取得した情報から画像情報をframeに読み込む
        capture.read(frame);

        ///// レポート課題 /////////////////////////////
        //画像処理プログラムをここに追記しましょう
        //
        //(1)カメラ画像に対するグレースケール化処理
        cvtColor(frame, gframe, COLOR_BGR2GRAY);
        
        //(2)グレースケール化した画像を用いた２値化処理
        threshold(gframe, bframe10, 10, 255, THRESH_BINARY);
        threshold(gframe, bframe100, 100, 255, THRESH_BINARY);
        threshold(gframe, bframe180, 180, 255, THRESH_BINARY);
        //ここで画像を表示するため、画像処理後の画像もここで表示処理を書けば良い
        imshow("Live", frame);
        //
        //グレースケール化した画像の表示
        imshow("GLive", gframe);
        //
        //２値化した画像の表示
        imshow("BLive", bframe100);
        //
        ///////////////////////////////////////////////

        
        if (waitKey(10)>=0)
            break;
    }
 
    /////////// 演習２ 顔画像を保存 ///////////////////
    imwrite("frame.jpg", frame);
    //////////////////////////////////////////////////

    ///// レポート課題 ///////////////////////////////
    //グレースケール化した画像と２値化画像を保存
    imwrite("gframe.jpg", gframe);
    imwrite("bframe10.jpg", bframe10);
    imwrite("bframe100.jpg", bframe100);
    imwrite("bframe180.jpg", bframe180);
    /////////////////////////////////////////////////

    
    return 0;
}