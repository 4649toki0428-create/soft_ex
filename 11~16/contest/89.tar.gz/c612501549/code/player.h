#ifndef PLAYER_H
#define PLAYER_H

#include "input.h"
#include <SDL2/SDL.h>



typedef enum {
    DIR_UP,
    DIR_DOWN,
    DIR_LEFT,
    DIR_RIGHT
} Direction;

typedef struct {
    float x, y;
    float speed;
    int hp;
    int max_hp;
    Direction dir;
    int anim_frame;
    int anim_timer;
} Player;


void Player_Init(Player *p);
void Player_Update(Player *p, InputState *in);
void Player_Render(Player *p, SDL_Renderer *renderer);

#endif
