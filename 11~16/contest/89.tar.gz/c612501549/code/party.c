#include "party.h"
#include "collision.h"
#include "enemy.h"
#include "drop.h"
#include "projectile.h"
#include <SDL2/SDL.h>
#include"player.h"

#define PARTY_MAX 10
#define HISTORY_MAX 300

// 仲間のデータ
static PartyMember party[PARTY_MAX];

typedef struct {
    int has_warrior;
    int has_archer;
    int has_mage;
} PartyFlags;

static PartyFlags party_flags;


// プレイヤーの移動履歴（仲間が後ろをついてくるため）
static SDL_Point history[HISTORY_MAX];
static int history_index = 0;

// 仲間の人数（0番はプレイヤー）
static int member_count = 1;


int has_warrior = 0;
int has_archer  = 0;
int has_mage    = 0;



//------------------------------------------------------------
// 初期化
//------------------------------------------------------------
void Party_Init() {

    // 履歴を全部0で初期化
    for (int i = 0; i < HISTORY_MAX; i++) {
        history[i].x = 0;
        history[i].y = 0;
    }

    // プレイヤー（隊列の先頭）
    party[0].x = 0;
    party[0].y = 0;
    party[0].type = ALLY_SWORD;  // プレイヤーは攻撃しない
    party[0].alive = 1;

    // ★味方所持フラグ初期化
    party_flags.has_warrior = 0;
    party_flags.has_archer  = 0;
    party_flags.has_mage    = 0;

    // ★歩きアニメ初期化（i は使わない）
    party[0].anim_frame = 0;
    party[0].anim_timer = 0;
    party[0].dir = DIR_DOWN;

}


//------------------------------------------------------------
// 仲間追加
//------------------------------------------------------------
void Party_AddMember(AllyType type) {

    if (member_count >= PARTY_MAX) return;

    // ★種類ごとに1体制限（必要なら有効化）
    if (type == ALLY_SWORD && party_flags.has_warrior) return;
    if (type == ALLY_ARROW && party_flags.has_archer)  return;
    if (type == ALLY_BOMB  && party_flags.has_mage)    return;

    // 新しい仲間は直前の仲間の位置に出現
    party[member_count].x = party[member_count - 1].x;
    party[member_count].y = party[member_count - 1].y;
    party[member_count].type = type;
    party[member_count].alive = 1;

    // 攻撃タイマー初期化
    party[member_count].attack_timer = 0;
    party[member_count].attack_flash = 0;

    // ★役職ごとの攻撃間隔（秒数）
    switch (type) {
        case ALLY_SWORD: party[member_count].attack_interval = 60; break;  // 1秒
        case ALLY_ARROW: party[member_count].attack_interval = 120; break; // 2秒
        case ALLY_BOMB:  party[member_count].attack_interval = 180; break; // 3秒
    }

    // ★フラグON
    if (type == ALLY_SWORD) has_warrior = 1;
    if (type == ALLY_ARROW) has_archer  = 1;
    if (type == ALLY_BOMB)  has_mage    = 1;

    member_count++;
}


//------------------------------------------------------------
// 仲間死亡 → 隊列を詰める
//------------------------------------------------------------
void Party_KillMember(int index) {

    if (index <= 0) return;  // プレイヤーは死なない

    AllyType t = party[index].type;


    // ★フラグ解除
    if (t == ALLY_SWORD) has_warrior = 0;
    if (t == ALLY_ARROW) has_archer  = 0;
    if (t == ALLY_BOMB)  has_mage    = 0;


    // 隊列を詰める
    for (int i = index; i < member_count - 1; i++) {
        party[i] = party[i + 1];
    }

    member_count--;
}


//------------------------------------------------------------
// 更新（プレイヤー位置を受け取る）
//------------------------------------------------------------
void Party_Update(float player_x, float player_y, Enemy *enemy_list, int enemy_count) {

    // プレイヤーの位置を履歴に保存
    history[history_index].x = (int)player_x;
    history[history_index].y = (int)player_y;
    history_index = (history_index + 1) % HISTORY_MAX;

    // プレイヤー位置更新
    party[0].x = player_x;
    party[0].y = player_y;

      // ★仲間追従
   // ★仲間追従＋向き推定＋歩きアニメ
    for (int i = 1; i < member_count; i++) {

        int idx = history_index - (i * 12);
        if (idx < 0) idx += HISTORY_MAX;

        float old_x = party[i].x;
        float old_y = party[i].y;

        party[i].x = history[idx].x;
        party[i].y = history[idx].y;

        // ★向き推定
        float dx = party[i].x - old_x;
        float dy = party[i].y - old_y;

        if (fabs(dx) > fabs(dy)) {
            party[i].dir = (dx > 0) ? DIR_RIGHT : DIR_LEFT;
        } else {
            party[i].dir = (dy > 0) ? DIR_DOWN : DIR_UP;
        }

        // ★歩きアニメ更新
        party[i].anim_timer++;
        if (party[i].anim_timer >= 10) {
            party[i].anim_timer = 0;
            party[i].anim_frame = 1 - party[i].anim_frame;
        }
    }


    // 仲間の攻撃処理
    for (int i = 1; i < member_count; i++) {

        PartyMember *a = &party[i];

        //------------------------------------------------------------
        // ★一番近い敵を探す
        //------------------------------------------------------------
        Enemy *target = NULL;
        float bestDist = 999999;

        for (int e = 0; e < enemy_count; e++) {

            if (!enemy_list[e].alive) continue;
            if (!enemy_list[e].alive) continue;

            float dx = enemy_list[e].x - a->x;
            float dy = enemy_list[e].y - a->y;
            float dist = dx*dx + dy*dy;

            if (dist < bestDist) {
                bestDist = dist;
                target = &enemy_list[e];
            }
        }

        // 敵がいない → 攻撃タイマーリセット
        if (!target) {
            a->attack_timer = 0;
            continue;
        }

        //------------------------------------------------------------
        // ★攻撃クールタイム（キャラごと）
        //------------------------------------------------------------
        a->attack_timer++;
        if (a->attack_timer < a->attack_interval) continue;
        a->attack_timer = 0;  // 攻撃したのでリセット

        //------------------------------------------------------------
        // ★敵の方向を計算（弓・爆弾用）
        //------------------------------------------------------------
        float dx = target->x - a->x;
        float dy = target->y - a->y;
        float len = sqrtf(dx*dx + dy*dy);
        dx /= len;
        dy /= len;

        //------------------------------------------------------------
        // ★タイプ別攻撃
        //------------------------------------------------------------

        // 🔴 剣：円状範囲攻撃（かすり判定）
        if (a->type == ALLY_SWORD) {
            a->attack_flash = 1;
            float radius = 48.0f;  // 剣の攻撃半径

            for (int e = 0; e < enemy_count; e++) {

                if (!enemy_list[e].alive) continue;

                float ex = enemy_list[e].x;
                float ey = enemy_list[e].y;

                float ddx = ex - a->x;
                float ddy = ey - a->y;
                float dist = sqrtf(ddx*ddx + ddy*ddy);

                // ★距離判定 → かすったらダメージ
                if (dist < radius) {
                    enemy_list[e].hp -= 1;
                    if (enemy_list[e].hp <= 0) {
                        enemy_list[e].alive = 0;
                        DropType t = (rand() % 3); 
                        Drop_Spawn(enemy_list[e].x, enemy_list[e].y, t);
                    }
                }
            }
        }

        // 🟢 弓：単体攻撃（Projectile）
        if (a->type == ALLY_ARROW) {
            Projectile_Spawn(
                a->x + 12,
                a->y + 12,
                dx * 6.0f,
                dy * 6.0f,
                PROJECTILE_ARROW
            );
        }

        // 🔵 爆弾：投げる（爆発は Projectile_Update で処理）
        if (a->type == ALLY_BOMB) {
            Projectile_Spawn(
                a->x + 12,
                a->y + 12,
                dx * 3.0f,   // 爆弾はゆっくり飛ぶ
                dy * 3.0f,
                PROJ_BOMB_THROW

            );
        }
    }

    //------------------------------------------------------------
    // 仲間死亡処理（敵に触れたら死ぬ）
    //------------------------------------------------------------
    for (int e = 0; e < enemy_count; e++) {
        if (!enemy_list[e].alive) continue;

        SDL_Rect er = { enemy_list[e].x, enemy_list[e].y, 32, 32 };

        for (int i = 1; i < member_count; i++) {

            SDL_Rect ar = { party[i].x, party[i].y, 24, 24 };

            if (Collision_Check(&ar, &er)) {

                Party_KillMember(i);

                enemy_list[e].hp -= 1;
                if (enemy_list[e].hp <= 0) {
                    enemy_list[e].alive = 0;
                    DropType t = (rand() % 3); 
                    Drop_Spawn(enemy_list[e].x, enemy_list[e].y, t);
                }

                break;
            }
        }
    }

}


//------------------------------------------------------------
// 描画
//------------------------------------------------------------
extern SDL_Texture* tex_character;

void Party_Render(SDL_Renderer *renderer) {

    for (int i = 1; i < member_count; i++) {

        PartyMember *a = &party[i];

        SDL_Rect src;
        src.w = 32;
        src.h = 32;

        int base_row = 0;
            if (a->type == ALLY_SWORD) base_row = 21;
            if (a->type == ALLY_ARROW) base_row = 11;
            if (a->type == ALLY_BOMB)  base_row = 16;


        switch (a->dir) {
            case DIR_RIGHT: src.y = 32 * (base_row + 0); break;
            case DIR_UP:    src.y = 32 * (base_row + 1); break;
            case DIR_LEFT:  src.y = 32 * (base_row + 2); break;
            case DIR_DOWN:  src.y = 32 * (base_row + 3); break;
        }

        src.x = 32 * a->anim_frame;

        SDL_Rect dst = { (int)a->x, (int)a->y, 32, 32 };
        SDL_RenderCopy(renderer, tex_character, &src, &dst);

        // ★剣士の攻撃エフェクト（元コードそのまま）
        if (a->type == ALLY_SWORD && a->attack_flash == 1) {
            float radius = 48.0f;
            SDL_SetRenderDrawColor(renderer, 255, 0, 0, 80);
            SDL_Rect area = {
                (int)(a->x - radius),
                (int)(a->y - radius),
                (int)(radius * 2),
                (int)(radius * 2)
            };
            SDL_RenderFillRect(renderer, &area);
            a->attack_flash = 0;
        }
    }
}
