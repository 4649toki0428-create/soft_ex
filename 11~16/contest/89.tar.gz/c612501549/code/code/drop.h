#ifndef DROP_H
#define DROP_H

#include <SDL2/SDL.h>

//
// ★ドロップの種類（仲間追加）
//
typedef enum {
    DROP_ALLY_SWORD,   // 剣仲間
    DROP_ALLY_ARROW,   // 弓仲間
    DROP_ALLY_BOMB     // 爆弾仲間
} DropType;

//
// ★ドロップ構造体
//
typedef struct {
    float x, y;
    int active;
    DropType type;
} Drop;

#define DROP_MAX 50

void Drop_Init();
void Drop_Spawn(float x, float y, DropType type);   // ★3引数版
void Drop_Update(float player_x, float player_y);
void Drop_Render(SDL_Renderer *renderer);

#endif
