// input.h
#ifndef INPUT_H
#define INPUT_H

typedef struct {
    int btnA;
    int btnB;
    int btnX;
    int btnY;
    int btnZR;
    int btnPlus;
    int btnR;
    int btnHOME;

    int prevX;
    int prevB;
        
} InputState;

void Input_Init();
void Input_Update(InputState *in);

#endif
