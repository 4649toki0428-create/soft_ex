#include <SDL2/SDL_image.h>
#include <stdio.h>
#include "render.h"

void Render_Present(SDL_Renderer *renderer) {
    SDL_RenderPresent(renderer);
}


SDL_Texture* LoadTexture(SDL_Renderer* renderer, const char* path) {

    SDL_Surface* surf = IMG_Load(path);
    if (!surf) {
        printf("IMG_Load Error: %s\n", IMG_GetError());
        return NULL;
    }

    SDL_Texture* tex = SDL_CreateTextureFromSurface(renderer, surf);
    SDL_FreeSurface(surf);

    return tex;
}
