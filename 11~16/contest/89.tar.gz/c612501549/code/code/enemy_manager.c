#include "enemy_manager.h"
#include "enemy.h"
#include "drop.h"
#include <SDL2/SDL.h>
#include <stdlib.h>
#include "game.h"
#include "party.h" 

extern GameState game_state;

static Enemy enemies[ENEMY_MAX];
static int enemy_count = 0;
static int spawn_timer = 0;
static int game_time = 0;

static int next_group_id = 1;

static int total_spawned = 0;     // 今までにスポーンした敵の総数
#define MAX_SPAWN_TOTAL 120       // ★ゲーム全体で出す敵の最大数


//------------------------------------------------------------
// 初期化
//------------------------------------------------------------
void EnemyManager_Init() {
    enemy_count = 0;
    spawn_timer = 0;
    game_time = 0;

    for (int i = 0; i < ENEMY_MAX; i++) {
        enemies[i].alive = 0;
    }
}

//------------------------------------------------------------
// 敵を1体スポーン
//------------------------------------------------------------
void EnemyManager_SpawnSingle(float x, float y, EnemyType type) {

    if (enemy_count >= ENEMY_MAX) return;

    Enemy_Init(&enemies[enemy_count], x, y, type);
    enemies[enemy_count].alive = 1;
    enemies[enemy_count].max_hp = enemies[enemy_count].hp;

    enemies[enemy_count].group_id = 0;     // 単体
    enemies[enemy_count].group_order = 0;  // 隊列先頭扱い

    enemy_count++;
}

//------------------------------------------------------------
// 隊列スポーン（縦並び）
//------------------------------------------------------------
void EnemyManager_SpawnGroup(int count) {

    int gid = next_group_id++;
    float base_x = rand() % 600 + 20;
    float base_y = rand() % 200 + 20;

    EnemyType types[3];

    // 種類決定
    for (int i = 0; i < count; i++) {
        types[i] = rand() % ENEMY_TYPE_MAX;
    }

    // 最も遅い速度を探す
    float min_speed = 999;
    for (int i = 0; i < count; i++) {
        float sp = Enemy_GetSpeed(types[i]);
        if (sp < min_speed) min_speed = sp;
    }

    // 縦並びスポーン
    for (int i = 0; i < count; i++) {

        float sx = base_x;
        float sy = base_y + i * 40;  // ★縦並び

        EnemyManager_SpawnSingle(sx, sy, types[i]);

        enemies[enemy_count - 1].group_id = gid;
        enemies[enemy_count - 1].group_order = i;
        enemies[enemy_count - 1].speed = min_speed;  // ★隊列速度統一
    }
}

//------------------------------------------------------------
// 隊列の速度を再計算（遅い敵が死んだとき）
//------------------------------------------------------------
void EnemyManager_RecalcGroupSpeed(int gid) {

    float min_speed = 999;

    // 生存している中で最も遅い速度を探す
    for (int i = 0; i < enemy_count; i++) {
        if (enemies[i].alive && enemies[i].group_id == gid) {
            float sp = enemies[i].base_speed;
            if (sp < min_speed) min_speed = sp;
        }
    }

    // 全員に適用
    for (int i = 0; i < enemy_count; i++) {
        if (enemies[i].alive && enemies[i].group_id == gid) {
            enemies[i].speed = min_speed;
        }
    }
}

//------------------------------------------------------------
// 更新
//------------------------------------------------------------
void EnemyManager_Update() {

    game_time++;

    // ★スポーン間隔
    spawn_timer++;
    int interval = (game_time < 1800) ? 900 : 300;

    if (spawn_timer >= interval) {

    spawn_timer = 0;

    if (total_spawned < MAX_SPAWN_TOTAL) {

        if (game_time < 1800) {
            // ★序盤：1体だけ
            float sx = rand() % 600 + 20;
            float sy = rand() % 200 + 20;
            EnemyManager_SpawnSingle(sx, sy, ENEMY_NORMAL);

            total_spawned += 1;   // ★1体スポーン
        }
        else {
            // ★中盤以降：1〜3体の隊列
            int count = (rand() % 3) + 1;  // ★1〜3体固定
            EnemyManager_SpawnGroup(count);

            total_spawned += count;  // ★隊列人数ぶん増やす
        }
    }
}


    // ★敵の更新
    for (int i = 0; i < enemy_count; i++) {

        if (!enemies[i].alive) continue;

        Enemy_Update(&enemies[i]);

        // ★死亡処理
        if (enemies[i].hp <= 0) {

            // ★ここにドロップ判定を追加する
            EnemyType et = enemies[i].type;

            // 味方が持っていない種類だけドロップする
            if (et == ENEMY_WARRIOR && has_warrior == 0) {
                Drop_Spawn(enemies[i].x, enemies[i].y, DROP_ALLY_SWORD);
            }
            if (et == ENEMY_ARCHER && has_archer == 0) {
                Drop_Spawn(enemies[i].x, enemies[i].y, DROP_ALLY_ARROW);
            }
            if (et == ENEMY_MAGE && has_mage == 0) {
                Drop_Spawn(enemies[i].x, enemies[i].y, DROP_ALLY_BOMB);
            }


            int gid = enemies[i].group_id;

            enemies[i].alive = 0;

            // ★隊列の速度再計算
            if (gid != 0) {
                EnemyManager_RecalcGroupSpeed(gid);
            }

            // ★詰める
            enemies[i] = enemies[enemy_count - 1];
            enemy_count--;
            i--;
        }

    }

    if (total_spawned >= MAX_SPAWN_TOTAL && enemy_count == 0) {
    game_state = STATE_GAMECLEAR;


    }

}

//------------------------------------------------------------
// 描画
//------------------------------------------------------------
void EnemyManager_Render(SDL_Renderer *renderer) {

    for (int i = 0; i < enemy_count; i++) {
        if (enemies[i].alive) {
            Enemy_Render(&enemies[i], renderer);
        }
    }
}

//------------------------------------------------------------
// 敵配列を外部に渡す
//------------------------------------------------------------
Enemy* EnemyManager_GetList() {
    return enemies;
}

int EnemyManager_GetCount() {
    return enemy_count;
}
