
#include <SDL2/SDL.h>

void Map_Init() {
}

void Map_Update() {
}

void Map_Render(SDL_Renderer *renderer) {
}
