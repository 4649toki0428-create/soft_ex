#include "game.h"
#include "player.h"
#include "enemy_manager.h"
#include "party.h"
#include "input.h"
#include "render.h"
#include "collision.h"
#include "drop.h"
#include "projectile.h"
#include <SDL2/SDL.h>
#include <stdio.h>
#include <SDL2/SDL_ttf.h>
#include "projectile.h"
#include "explosion.h"

GameState game_state = STATE_TITLE;


SDL_Texture* tex_start;
SDL_Texture* tex_pose;
SDL_Texture* tex_gameover;
SDL_Texture* tex_gameclear;

SDL_Texture* tex_back;

SDL_Texture* tex_character;

SDL_Texture* tex_bullet;
SDL_Texture* tex_arrow;
SDL_Texture* tex_bomb_throw;
SDL_Texture* tex_soundwave;

SDL_Texture* tex_sword_effect;

SDL_Texture* tex_explosion;


TTF_Font *font = NULL;


static int pause_cursor = 0;   // 0〜3


//------------------------------------------------------------
// タイトル画面描画
//------------------------------------------------------------
void Game_RenderTitle(SDL_Renderer *renderer) {

    SDL_Rect dst = { 0, 0, 640, 480 };
    SDL_RenderCopy(renderer, tex_start, NULL, &dst);

    Render_Present(renderer);
}




Player player;
InputState input;

//------------------------------------------------------------
// 初期化
//------------------------------------------------------------
void Game_Init(SDL_Renderer *renderer) {
    Input_Init();
    Explosion_Init();
    
    if (!font) {
        printf("TTF_OpenFont Error: %s\n", TTF_GetError());
    }

        // UI
    tex_start     = LoadTexture(renderer, "illust/start.png");
    tex_pose      = LoadTexture(renderer, "illust/pose.png");
    tex_gameover  = LoadTexture(renderer, "illust/game_over.png");
    tex_gameclear = LoadTexture(renderer, "illust/game_clear.png");

    // 背景
    tex_back      = LoadTexture(renderer, "illust/back.png");

    // プレイヤー・敵・仲間（スプライトシート）
    tex_character = LoadTexture(renderer, "illust/character.png");

    // ★プレイヤー4方向画像（新しい画像）
    tex_player_down  = LoadTexture(renderer, "illust/character_player_Down.png");
    tex_player_left  = LoadTexture(renderer, "illust/character_player_L.png");
    tex_player_right = LoadTexture(renderer, "illust/character_player_R.png");
    tex_player_up    = LoadTexture(renderer, "illust/character_player_up.png");


    // 弾
    tex_bullet       = LoadTexture(renderer, "illust/bullet.png");
    tex_arrow        = LoadTexture(renderer, "illust/ya.png");
    tex_bomb_throw   = LoadTexture(renderer, "illust/bomb.png");
    tex_soundwave    = LoadTexture(renderer, "illust/sound_wave.png");

    // 剣士の攻撃エフェクト
    tex_sword_effect = LoadTexture(renderer, "illust/sword.png");

    // 爆発アニメ
    tex_explosion    = LoadTexture(renderer, "illust/bomb_done.png");


}

//------------------------------------------------------------
// 更新
//------------------------------------------------------------
void Game_Update() {

    //--------------------------------------------------------
    // ★タイトル画面
    //--------------------------------------------------------
    if (game_state == STATE_TITLE) {

        
        Input_Update(&input);
        if (input.btnA) {
            

                // ★ゲーム開始
                Player_Init(&player);
                EnemyManager_Init();
                Party_Init();
                Projectile_Init();
                Drop_Init();

                game_state = STATE_GAME;
            return;
        }

         // タイトル中は他の更新をしない
    }

    //--------------------------------------------------------
    // ★ゲーム中
    //--------------------------------------------------------
    if (game_state == STATE_GAME) {
        
        Input_Update(&input);
        Player_Update(&player, &input);
        Explosion_Update();   // ★爆発アニメ更新
        EnemyManager_Update();

        Enemy *enemy_list = EnemyManager_GetList();
        int enemy_count = EnemyManager_GetCount();

        Party_Update(player.x, player.y, enemy_list, enemy_count);
        Projectile_Update(enemy_list, enemy_count);
        Drop_Update(player.x, player.y);
        
        // ZRボタンでプレイヤー弾発射
        if (input.btnZR) {
        Projectile_SpawnPlayer(player.x, player.y, player.dir);
        }

        // プレイヤーと敵の衝突判定
        SDL_Rect p = { (int)player.x, (int)player.y, 32, 32 };

        for (int i = 0; i < enemy_count; i++) {
            if (!enemy_list[i].alive) continue;

            SDL_Rect e = { (int)enemy_list[i].x, (int)enemy_list[i].y, 32, 32 };

            if (Collision_Check(&p, &e)) {
                player.hp -= 1;
                if (player.hp <= 0) {
                    game_state = STATE_GAMEOVER;
                }
            }
        }

        // Rボタンでポーズ
        if (input.btnR) {   // ★Rボタンでポーズ
        game_state = STATE_PAUSE;
        return;
        }


        return;
    }

    //--------------------------------------------------------
    // ★ポーズメニュー
    //--------------------------------------------------------
    if (game_state == STATE_PAUSE) {

    Input_Update(&input);

    // カーソル移動（Xで上、Bで下）
    if (input.prevX) {
        pause_cursor--;
        if (pause_cursor < 0) pause_cursor = 0;
    }
    if (input.prevB) {
        pause_cursor++;
        if (pause_cursor > 3) pause_cursor = 3;
    }

    // 決定（A）
    if (input.btnA) {

        if (pause_cursor == 0) {
            // 再開
            game_state = STATE_GAME;
        }
        else if (pause_cursor == 1) {
            // 初めからやり直し
            Player_Init(&player);
            EnemyManager_Init();
            Party_Init();
            Projectile_Init();
            Drop_Init();
            game_state = STATE_GAME;
        }
        else if (pause_cursor == 2) {
            // スタート画面へ
            game_state = STATE_TITLE;
        }
        else if (pause_cursor == 3) {
            // ゲーム終了
            exit(0);
        }
    }

    return;
}


    //--------------------------------------------------------
    // ★ゲームオーバー
    //--------------------------------------------------------
    if (game_state == STATE_GAMEOVER) {
        // 必要ならクリックでタイトルに戻す処理を追加できる
        return;
    }

    //--------------------------------------------------------
    // ★ゲームクリア
    //--------------------------------------------------------
    if (game_state == STATE_GAMECLEAR) {
    // 入力でタイトルに戻るなどの処理を入れてもOK
    return;
    }

}

//------------------------------------------------------------
// 描画
//------------------------------------------------------------
void Game_Render(SDL_Renderer *renderer) {

                    // ★背景タイル描画（草原＋森の壁4方向）
            SDL_Rect src_grass        = {   0, 0, 128, 128 };
            SDL_Rect src_forest_top   = { 128, 0, 128, 128 };
            SDL_Rect src_forest_bottom= { 256, 0, 128, 128 };
            SDL_Rect src_forest_left  = { 384, 0, 128, 128 };
            SDL_Rect src_forest_right = { 512, 0, 128, 128 };

    switch (game_state) {

        case STATE_TITLE:
            Game_RenderTitle(renderer);
            Render_Present(renderer);
            break;

        case STATE_GAME:

            // 草原タイルを敷き詰める
            for (int y = 0; y < 480; y += 128) {
                for (int x = 0; x < 640; x += 128) {
                    SDL_Rect dst = { x, y, 128, 128 };
                    SDL_RenderCopy(renderer, tex_back, &src_grass, &dst);
                }
            }

            // 森の壁（上）
            for (int x = 0; x < 640; x += 128) {
                SDL_Rect dst = { x, 0, 128, 128 };
                SDL_RenderCopy(renderer, tex_back, &src_forest_top, &dst);
            }

            // 森の壁（下）
            for (int x = 0; x < 640; x += 128) {
                SDL_Rect dst = { x, 480 - 128, 128, 128 };
                SDL_RenderCopy(renderer, tex_back, &src_forest_bottom, &dst);
            }

            // 森の壁（左）
            for (int y = 0; y < 480; y += 128) {
                SDL_Rect dst = { 0, y, 128, 128 };
                SDL_RenderCopy(renderer, tex_back, &src_forest_left, &dst);
            }

            // 森の壁（右）
            for (int y = 0; y < 480; y += 128) {
                SDL_Rect dst = { 640 - 128, y, 128, 128 };
                SDL_RenderCopy(renderer, tex_back, &src_forest_right, &dst);
            }
            SDL_Rect hp_bg = { 20, 20, 100, 10 };
            SDL_RenderFillRect(renderer, &hp_bg);
            Explosion_Render(renderer);
            
            float ratio = (float)player.hp / (float)player.max_hp;
            SDL_SetRenderDrawColor(renderer, 255, 80, 80, 255);
            SDL_Rect hp_fg = { 20, 20, (int)(100 * ratio), 10 };
            SDL_RenderFillRect(renderer, &hp_fg);

            Player_Render(&player, renderer);
            EnemyManager_Render(renderer);
            Party_Render(renderer);
            Projectile_Render(renderer);
            Drop_Render(renderer);


            Render_Present(renderer);
            break;

        case STATE_GAMEOVER:
            SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
            SDL_RenderClear(renderer);

            SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
            SDL_Rect r = { 200, 200, 240, 80 };
            SDL_RenderFillRect(renderer, &r);

            Render_Present(renderer);
            break;

        case STATE_PAUSE:

            // 草原タイル
            for (int y = 0; y < 480; y += 128) {
                for (int x = 0; x < 640; x += 128) {
                    SDL_Rect dst = { x, y, 128, 128 };
                    SDL_RenderCopy(renderer, tex_back, &src_grass, &dst);
                }
            }

            // 森の壁（上）
            for (int x = 0; x < 640; x += 128) {
                SDL_Rect dst = { x, 0, 128, 128 };
                SDL_RenderCopy(renderer, tex_back, &src_forest_top, &dst);
            }

            // 森の壁（下）
            for (int x = 0; x < 640; x += 128) {
                SDL_Rect dst = { x, 480 - 128, 128, 128 };
                SDL_RenderCopy(renderer, tex_back, &src_forest_bottom, &dst);
            }

            // 森の壁（左）
            for (int y = 0; y < 480; y += 128) {
                SDL_Rect dst = { 0, y, 128, 128 };
                SDL_RenderCopy(renderer, tex_back, &src_forest_left, &dst);
            }

            // 森の壁（右）
            for (int y = 0; y < 480; y += 128) {
                SDL_Rect dst = { 640 - 128, y, 128, 128 };
                SDL_RenderCopy(renderer, tex_back, &src_forest_right, &dst);
            }
            Explosion_Render(renderer);
            Player_Render(&player, renderer);
            EnemyManager_Render(renderer);
            Party_Render(renderer);
            Projectile_Render(renderer);
            Drop_Render(renderer);

            // 半透明の黒背景
            SDL_SetRenderDrawColor(renderer, 0, 0, 0, 180);
            SDL_Rect bg = { 120, 80, 400, 300 };
            SDL_RenderFillRect(renderer, &bg);

            // メニュー項目を四角形で表現
            for (int i = 0; i < 4; i++) {

                // 選択中は黄色、その他は白
                if (i == pause_cursor)
                    SDL_SetRenderDrawColor(renderer, 255, 255, 0, 255);
                else
                    SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);

                SDL_Rect item = { 160, 120 + i * 60, 300, 40 };
                SDL_RenderFillRect(renderer, &item);
            }

            Render_Present(renderer);
            break;

        case STATE_GAMECLEAR:
            SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
            SDL_RenderClear(renderer);

            // 白い枠
            SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
            SDL_Rect box = { 120, 140, 400, 200 };
            SDL_RenderFillRect(renderer, &box);

            // 黒い中身
            SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
            SDL_Rect inner = { 140, 160, 360, 160 };
            SDL_RenderFillRect(renderer, &inner);
        
    }
}


//------------------------------------------------------------
// ゲームオーバー処理
//------------------------------------------------------------
void Game_Over() {
    printf("GAME OVER\n");
    game_state = STATE_GAMEOVER;
}
