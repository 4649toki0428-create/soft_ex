#ifndef PROJECTILE_H
#define PROJECTILE_H

#include <SDL2/SDL.h>
#include "enemy.h"
#include "drop.h"

//
//------------------------------------------------------------
// 弾の種類（プレイヤー・弓・爆弾・音波）
//------------------------------------------------------------
// ここで種類を増やすことで、描画処理や当たり判定で
// それぞれ違う画像・挙動を使えるようになる。
//
typedef enum {

    PROJ_PLAYER_BULLET,   // プレイヤーの通常弾（bullet.png）
    PROJECTILE_ARROW,           // 弓キャラの矢（ya.png）
    PROJ_BOMB_THROW,      // 爆弾使いの投げ弾（bomb.png）
                          // → 敵に当たると爆発（bomb_done.png）
    PROJ_SOUND_WAVE       // コウモリの音波（sound_wave.png）

} ProjectileType;


//
//------------------------------------------------------------
// 弾の構造体
//------------------------------------------------------------
// 位置・速度・生存フラグ・種類を持つ。
// 種類によって描画画像や当たり判定が変わる。
//------------------------------------------------------------
typedef struct {
    float x, y;          // 位置
    float vx, vy;        // 速度
    int alive;           // 生存フラグ（0なら消滅）
    ProjectileType type; // 弾の種類
} Projectile;


//
//------------------------------------------------------------
// 関数プロトタイプ
//------------------------------------------------------------

// 弾の初期化（配列を全部消す）
void Projectile_Init();

// 弾生成（矢・爆弾・音波・プレイヤー弾すべて共通）
void Projectile_Spawn(float x, float y, float vx, float vy, ProjectileType type);

// プレイヤー専用の弾（ZRなどで撃つ）
void Projectile_SpawnPlayer(float x, float y, int dir);

// 弾の更新（移動・当たり判定・爆発処理）
void Projectile_Update(Enemy *enemy_list, int enemy_count);

// 弾の描画（種類ごとに画像を切り替える）
void Projectile_Render(SDL_Renderer *renderer);

#endif
