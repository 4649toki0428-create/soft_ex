#include "enemy.h"
#include <SDL2/SDL.h>
#include <stdlib.h>

float Enemy_GetSpeed(EnemyType type) {
    switch (type) {
        case ENEMY_NORMAL:  return 1.5f;
        case ENEMY_WARRIOR: return 1.2f;
        case ENEMY_ARCHER:  return 1.8f;
        case ENEMY_MAGE:    return 1.0f;
        default: return 1.5f;
    }
}

void Enemy_Init(Enemy *e, float x, float y, EnemyType type) {

    e->x = x;
    e->y = y;
    e->type = type;

    // ★タイプ別HP
    switch (type) {
        case ENEMY_NORMAL:  e->hp = 3; break;
        case ENEMY_WARRIOR: e->hp = 4; break;
        case ENEMY_ARCHER:  e->hp = 2; break;
        case ENEMY_MAGE:    e->hp = 5; break;
        default:
        // ENEMY_TYPE_MAX など未使用の値はここに来る
        break;
    }

    e->max_hp = e->hp;
    e->alive = 1;

    // ★隊列システム初期化
    e->group_id = 0;
    e->group_order = 0;

    e->base_speed = Enemy_GetSpeed(type);
    e->speed = e->base_speed;

    // ★初期移動方向
    int dir = rand() % 4;
    switch (dir) {
        case 0: e->vx =  e->speed; e->vy = 0; break;
        case 1: e->vx = -e->speed; e->vy = 0; break;
        case 2: e->vx = 0; e->vy =  e->speed; break;
        case 3: e->vx = 0; e->vy = -e->speed; break;
    }
}

void Enemy_Update(Enemy *e) {

    if (!e->alive) return;

    // ★移動
    e->x += e->vx;
    e->y += e->vy;

    // ★壁で反転
    if (e->x < 0)         { e->x = 0;         e->vx *= -1; }
    if (e->x > 640 - 32)  { e->x = 640 - 32;  e->vx *= -1; }
    if (e->y < 0)         { e->y = 0;         e->vy *= -1; }
    if (e->y > 480 - 32)  { e->y = 480 - 32;  e->vy *= -1; }
}

void Enemy_Render(Enemy *e, SDL_Renderer *renderer) {

    if (!e->alive) return;

    SDL_Rect rect = { (int)e->x, (int)e->y, 32, 32 };

    // ★タイプ別色
    switch (e->type) {
        case ENEMY_NORMAL:  SDL_SetRenderDrawColor(renderer, 255, 50, 50, 255); break;
        case ENEMY_WARRIOR: SDL_SetRenderDrawColor(renderer, 255, 150, 50, 255); break;
        case ENEMY_ARCHER:  SDL_SetRenderDrawColor(renderer, 50, 200, 255, 255); break;
        case ENEMY_MAGE:    SDL_SetRenderDrawColor(renderer, 150, 50, 255, 255); break;
    }

    SDL_RenderFillRect(renderer, &rect);

    // ★HPバー
    float ratio = (float)e->hp / (float)e->max_hp;
    int bar_width = (int)(32 * ratio);

    SDL_Rect bar_bg = { (int)e->x, (int)e->y - 6, 32, 4 };
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderFillRect(renderer, &bar_bg);

    SDL_Rect bar_fg = { (int)e->x, (int)e->y - 6, bar_width, 4 };
    SDL_SetRenderDrawColor(renderer, 80, 255, 80, 255);
    SDL_RenderFillRect(renderer, &bar_fg);
}
