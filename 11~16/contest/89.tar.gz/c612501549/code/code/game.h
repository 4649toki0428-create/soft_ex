#ifndef GAME_H
#define GAME_H
#include <SDL2/SDL.h> 

typedef enum {
    STATE_TITLE,      // タイトル画面
    STATE_GAME,       // プレイ中
    STATE_PAUSE,      // ポーズメニュー
    STATE_GAMEOVER,   // プレイヤー死亡
    STATE_GAMECLEAR   // ★ゲームクリア（enemy_manager から参照）
} GameState;

extern GameState game_state;

void Game_Init(SDL_Renderer *renderer);
void Game_Update();
void Game_Render(SDL_Renderer *renderer);
void Game_Over();

#endif
