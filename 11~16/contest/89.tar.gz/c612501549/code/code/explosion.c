#include "explosion.h"

// 爆発最大数（同時に複数発生可能）
#define EXPLOSION_MAX 32

// 爆発データ
static Explosion exp_list[EXPLOSION_MAX];

// 爆発画像（bomb_done.png）
extern SDL_Texture *tex_explosion;

//------------------------------------------------------------
// 初期化
//------------------------------------------------------------
void Explosion_Init() {
    for (int i = 0; i < EXPLOSION_MAX; i++) {
        exp_list[i].active = 0;
    }
}

//------------------------------------------------------------
// 爆発開始（空いているスロットに登録）
//------------------------------------------------------------
void Explosion_Start(float x, float y) {

    for (int i = 0; i < EXPLOSION_MAX; i++) {

        if (!exp_list[i].active) {

            exp_list[i].active = 1;
            exp_list[i].x = x;
            exp_list[i].y = y;
            exp_list[i].frame = 0;
            exp_list[i].timer = 0;

            return;
        }
    }
}

//------------------------------------------------------------
// 爆発更新（フレーム進行）
//------------------------------------------------------------
void Explosion_Update() {

    for (int i = 0; i < EXPLOSION_MAX; i++) {

        if (!exp_list[i].active) continue;

        Explosion *e = &exp_list[i];

        e->timer++;

        // 4フレームごとに次の爆発画像へ
        if (e->timer % 4 == 0) {
            e->frame++;

            // 6フレーム再生したら終了
            if (e->frame >= 6) {
                e->active = 0;
            }
        }
    }
}

//------------------------------------------------------------
// 爆発描画
//------------------------------------------------------------
void Explosion_Render(SDL_Renderer *renderer) {

    for (int i = 0; i < EXPLOSION_MAX; i++) {

        if (!exp_list[i].active) continue;

        Explosion *e = &exp_list[i];

        // bomb_done.png の横並び6フレームを切り出す
        SDL_Rect src = {
            e->frame * 32,   // 横方向にフレームが並んでいる
            0,
            32,
            32
        };

        SDL_Rect dst = {
            (int)e->x - 16,  // 爆発中心に合わせる
            (int)e->y - 16,
            32,
            32
        };

        SDL_RenderCopy(renderer, tex_explosion, &src, &dst);
    }
}
