#ifndef ENEMY_H
#define ENEMY_H

#include <SDL2/SDL.h>

typedef enum {
    ENEMY_NORMAL,
    ENEMY_WARRIOR,
    ENEMY_ARCHER,
    ENEMY_MAGE,
    ENEMY_TYPE_MAX
} EnemyType;

typedef struct {
    float x, y;
    float vx, vy;

    int hp;
    int max_hp;
    int alive;
    EnemyType type;

    // ★隊列システム用
    int group_id;      // 0 = 単体, 1〜 = 隊列ID
    int group_order;   // 隊列内の順番

    float base_speed;  // 種類ごとの基本速度
    float speed;       // 現在の速度（隊列で統一）
} Enemy;

void Enemy_Init(Enemy *e, float x, float y, EnemyType type);
void Enemy_Update(Enemy *e);
void Enemy_Render(Enemy *e, SDL_Renderer *renderer);
float Enemy_GetSpeed(EnemyType type);

#endif
