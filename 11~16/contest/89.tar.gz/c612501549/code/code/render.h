#ifndef RENDER_H
#define RENDER_H

#include <SDL2/SDL.h>
SDL_Texture* LoadTexture(SDL_Renderer* renderer, const char* path);


void Render_Clear(SDL_Renderer *renderer);
void Render_Present(SDL_Renderer *renderer);

#endif
