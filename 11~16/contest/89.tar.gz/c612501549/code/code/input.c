// input.c
#include <SDL2/SDL.h>
#include "input.h"
#include <stdio.h>



SDL_Joystick *joy = NULL;

void Input_Init() {
    int num = SDL_NumJoysticks();
    joy = NULL;

    printf("Detected Joysticks: %d\n", num);

    for (int i = 0; i < num; i++) {
        const char *name = SDL_JoystickNameForIndex(i);
        printf("Joystick Name: %s\n", name);

        if (strstr(name, "Right Joy-Con")) {

            SDL_Joystick *tmp = SDL_JoystickOpen(i);

            if (tmp == NULL) {
                printf("SDL_JoystickOpen failed for Right Joy-Con\n");
                return;   // ★ここで終了しないとセグフォする
            }

            joy = tmp;
            printf("Right Joy-Con opened successfully\n");
            return;
        }
    }

    printf("Right Joy-Con not found\n");
}

void Input_Update(InputState *in) {
    if (!joy) {
        in->btnA = in->btnB = in->btnX = in->btnY = 0;
        return;
    }

    int oldX = in->btnX;
    int oldB = in->btnB;
 


    in->btnA = SDL_JoystickGetButton(joy, 1);
    in->btnB = SDL_JoystickGetButton(joy, 0);
    in->btnX = SDL_JoystickGetButton(joy, 2);
    in->btnY = SDL_JoystickGetButton(joy, 3);
    in->btnR = SDL_JoystickGetButton(joy, 5);
    in->btnZR = SDL_JoystickGetButton(joy, 7);
    in->btnHOME = SDL_JoystickGetButton(joy, 9);



    in->prevX = (!oldX && in->btnX);   // 前が0で今が1 → 押した瞬間
    in->prevB = (!oldB && in->btnB);


}

