#ifndef ENEMY_MANAGER_H
#define ENEMY_MANAGER_H

#include "enemy.h"
#include <SDL2/SDL.h>

#define ENEMY_MAX 50

void EnemyManager_Init();
void EnemyManager_Update();
void EnemyManager_Render(SDL_Renderer *renderer);

// 敵配列を外部に渡す
Enemy* EnemyManager_GetList();
int EnemyManager_GetCount();

// 敵を1体スポーンさせる（必要なら）
void EnemyManager_SpawnSingle(float x, float y, EnemyType type);

#endif
