#include "collision.h"
#include <SDL2/SDL.h>

int Collision_Check(SDL_Rect *a, SDL_Rect *b) {
    // SDL が用意している矩形同士の衝突判定
    if (SDL_HasIntersection(a, b)) {
        return 1;   // 衝突している
    }
    return 0;       // 衝突していない
}
