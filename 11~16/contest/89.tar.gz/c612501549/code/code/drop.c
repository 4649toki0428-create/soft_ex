#include "drop.h"
#include "collision.h"
#include "party.h"
#include <SDL2/SDL.h>
#include <stdlib.h>

static Drop drops[DROP_MAX];

//
// ★初期化
//
void Drop_Init() {
    for (int i = 0; i < DROP_MAX; i++) {
        drops[i].active = 0;
    }
}

//
// ★ドロップ生成（敵の種類に応じて呼ばれる）
//
void Drop_Spawn(float x, float y, DropType type) {

    for (int i = 0; i < DROP_MAX; i++) {
        if (!drops[i].active) {

            drops[i].active = 1;
            drops[i].x = x;
            drops[i].y = y;
            drops[i].type = type;   // ★敵の種類に応じたドロップ

            return;
        }
    }
}

//
// ★プレイヤーが拾う処理
//
void Drop_Update(float player_x, float player_y) {

    SDL_Rect player_rect = {
        (int)player_x,
        (int)player_y,
        32, 32
    };

    for (int i = 0; i < DROP_MAX; i++) {
        if (!drops[i].active) continue;

        SDL_Rect d = {
            (int)drops[i].x,
            (int)drops[i].y,
            20, 20
        };

        if (Collision_Check(&player_rect, &d)) {

            // ★仲間追加
            switch (drops[i].type) {
                case DROP_ALLY_SWORD:
                    Party_AddMember(ALLY_SWORD);
                    break;

                case DROP_ALLY_ARROW:
                    Party_AddMember(ALLY_ARROW);
                    break;

                case DROP_ALLY_BOMB:
                    Party_AddMember(ALLY_BOMB);
                    break;
            }

            drops[i].active = 0;
        }
    }
}

//
// ★描画
//
void Drop_Render(SDL_Renderer *renderer) {

    for (int i = 0; i < DROP_MAX; i++) {
        if (!drops[i].active) continue;

        SDL_Rect rect = {
            (int)drops[i].x,
            (int)drops[i].y,
            20, 20
        };

        // ★タイプ別色
        switch (drops[i].type) {
            case DROP_ALLY_SWORD:
                SDL_SetRenderDrawColor(renderer, 255, 80, 80, 255);
                break;

            case DROP_ALLY_ARROW:
                SDL_SetRenderDrawColor(renderer, 80, 255, 80, 255);
                break;

            case DROP_ALLY_BOMB:
                SDL_SetRenderDrawColor(renderer, 80, 80, 255, 255);
                break;
        }

        SDL_RenderFillRect(renderer, &rect);
    }
}
