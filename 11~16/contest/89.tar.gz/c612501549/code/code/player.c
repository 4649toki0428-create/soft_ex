// player.c
#include "player.h"
#include "input.h"
#include <SDL2/SDL.h>

void Player_Init(Player *p) {
    p->x = 320;      // 画面中央
    p->y = 400;      // 下の方
    p->speed = 3.0;  // 移動速度
    p->hp = 10;      // 初期HP
    p->max_hp = 10;  // 最大HP
    p->dir = DIR_UP; // 初期方向（上向き）
}

// 逆方向禁止（180度ターン禁止）
int opposite(Direction a, Direction b) {
    return (a == DIR_UP && b == DIR_DOWN) ||
           (a == DIR_DOWN && b == DIR_UP) ||
           (a == DIR_LEFT && b == DIR_RIGHT) ||
           (a == DIR_RIGHT && b == DIR_LEFT);
}

void Player_Update(Player *p, InputState *in) {

    // --- 方向転換 ---
    Direction new_dir = p->dir;

    if (in->btnA) new_dir = DIR_RIGHT; // A → 右
    if (in->btnX) new_dir = DIR_UP;    // X → 上
    if (in->btnY) new_dir = DIR_LEFT;  // Y → 左
    if (in->btnB) new_dir = DIR_DOWN;  // B → 下

    // 180度ターン禁止
    if (!opposite(p->dir, new_dir)) {
        p->dir = new_dir;
    }

    // --- 自動直進 ---
    switch (p->dir) {
        case DIR_RIGHT: p->x += p->speed; break;
        case DIR_LEFT:  p->x -= p->speed; break;
        case DIR_UP:    p->y -= p->speed; break;
        case DIR_DOWN:  p->y += p->speed; break;
    }

    // --- 画面外に出ないように制限 ---
    if (p->x < 0) p->x = 0;
    if (p->x > 640 - 32) p->x = 640 - 32;

    if (p->y < 0) p->y = 0;
    if (p->y > 480 - 32) p->y = 480 - 32;
}

void Player_Render(Player *p, SDL_Renderer *renderer) {

    SDL_Texture* tex = NULL;

    switch (p->dir) {
        case DIR_DOWN:  tex = tex_player_down;  break;
        case DIR_LEFT:  tex = tex_player_left;  break;
        case DIR_RIGHT: tex = tex_player_right; break;
        case DIR_UP:    tex = tex_player_up;    break;
    }

    SDL_Rect src = { 0, 0, 32, 32 };
    SDL_Rect dst = { (int)p->x, (int)p->y, 32, 32 };

    SDL_RenderCopy(renderer, tex, &src, &dst);
}

