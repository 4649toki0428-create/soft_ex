#ifndef COLLISION_H
#define COLLISION_H

#include <SDL2/SDL.h>

int Collision_Check(SDL_Rect *a, SDL_Rect *b);

#endif
