#ifndef EXPLOSION_H
#define EXPLOSION_H

#include <SDL2/SDL.h>

typedef struct {
    float x, y;     // 爆発位置
    int frame;      // 現在のフレーム（0〜5）
    int timer;      // フレーム切り替え用タイマー
    int active;     // 1=再生中、0=非表示
} Explosion;

void Explosion_Init();
void Explosion_Start(float x, float y);
void Explosion_Update();
void Explosion_Render(SDL_Renderer *renderer);

#endif
