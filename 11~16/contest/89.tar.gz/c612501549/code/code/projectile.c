#include "projectile.h"
#include "collision.h"
#include "player.h"
#include <SDL2/SDL.h>
#include <math.h>
#include "explosion.h"


#define PROJECTILE_MAX 100
#define DIR_UP    0
#define DIR_DOWN  1
#define DIR_LEFT  2
#define DIR_RIGHT 3

extern SDL_Texture* tex_bullet;
extern SDL_Texture* tex_arrow;
extern SDL_Texture* tex_bomb_throw;
extern SDL_Texture* tex_soundwave;



static Projectile proj[PROJECTILE_MAX];


//------------------------------------------------------------
// 初期化（全弾を消す）
//------------------------------------------------------------
void Projectile_Init() {
    for (int i = 0; i < PROJECTILE_MAX; i++) {
        proj[i].alive = 0;
    }
}


//------------------------------------------------------------
// 弾生成（矢・爆弾どちらもこれで生成）
//------------------------------------------------------------
void Projectile_Spawn(float x, float y, float vx, float vy, ProjectileType type) {

    for (int i = 0; i < PROJECTILE_MAX; i++) {
        if (!proj[i].alive) {

            proj[i].alive = 1;
            proj[i].x = x;
            proj[i].y = y;
            proj[i].vx = vx;
            proj[i].vy = vy;
            proj[i].type = type;   // ★種類をセット

            return;
        }
    }
}


//------------------------------------------------------------
// プレイヤーの進行方向に弾を撃つ（矢専用）
//------------------------------------------------------------
void Projectile_SpawnPlayer(float x, float y, int dir) {

    float speed = 6.0f;
    float vx = 0, vy = 0;

    switch (dir) {
        case DIR_UP:    vx = 0;      vy = -speed; break;
        case DIR_DOWN:  vx = 0;      vy = speed;  break;
        case DIR_LEFT:  vx = -speed; vy = 0;      break;
        case DIR_RIGHT: vx = speed;  vy = 0;      break;
    }

    // ★プレイヤー弾は専用タイプに変更
    Projectile_Spawn(x, y, vx, vy, PROJ_PLAYER_BULLET);
}


//------------------------------------------------------------
// 更新（移動・当たり判定・爆発処理）
//------------------------------------------------------------
void Projectile_Update(Enemy *enemy_list, int enemy_count) {

    for (int i = 0; i < PROJECTILE_MAX; i++) {

        if (!proj[i].alive) continue;

        Projectile *p = &proj[i];

        // 移動
        p->x += p->vx;
        p->y += p->vy;

        // 画面外で消滅
        if (p->x < 0 || p->x > 640 ||
            p->y < 0 || p->y > 480) {
            p->alive = 0;
            continue;
        }

        //------------------------------------------------------------
        // ★矢の当たり判定（単体攻撃）
        //------------------------------------------------------------
        if (p->type == PROJECTILE_ARROW) {

            SDL_Rect pr = { (int)p->x, (int)p->y, 8, 8 };

            for (int e = 0; e < enemy_count; e++) {

                if (!enemy_list[e].alive) continue;
                if (!enemy_list[e].alive) continue;

                SDL_Rect er = {
                    (int)enemy_list[e].x,
                    (int)enemy_list[e].y,
                    32, 32
                };

                if (Collision_Check(&pr, &er)) {

                    enemy_list[e].hp -= 1;

                    if (enemy_list[e].hp <= 0) {
                        enemy_list[e].alive = 0;
                        Drop_Spawn(enemy_list[e].x, enemy_list[e].y, DROP_ALLY_SWORD);
                    }

                    p->alive = 0;
                    break;
                }
            }
        }


        //------------------------------------------------------------
        // ★爆弾の当たり判定（敵に当たったら爆発）
        //------------------------------------------------------------
        if (p->type == PROJ_BOMB_THROW) {

            SDL_Rect pr = { (int)p->x, (int)p->y, 12, 12 };

            for (int e = 0; e < enemy_count; e++) {

                if (!enemy_list[e].alive) continue;
                if (!enemy_list[e].alive) continue;

                SDL_Rect er = {
                    (int)enemy_list[e].x,
                    (int)enemy_list[e].y,
                    32, 32
                };

                // ★爆弾が敵に当たった
                if (Collision_Check(&pr, &er)) {

                    // ★爆発範囲（半径32px）
                    for (int k = 0; k < enemy_count; k++) {

                        if (!enemy_list[k].alive) continue;

                        float dx = enemy_list[k].x - p->x;
                        float dy = enemy_list[k].y - p->y;
                        float dist = sqrtf(dx*dx + dy*dy);

                        if (dist < 32.0f) {

                            enemy_list[k].hp -= 2;

                            if (enemy_list[k].hp <= 0) {
                                enemy_list[k].alive = 0;
                                Drop_Spawn(enemy_list[k].x, enemy_list[k].y, DROP_ALLY_SWORD);
                            }
                        }
                    }
                    Explosion_Start(p->x, p->y);  // ★爆発開始
                    // 爆弾消滅
                    p->alive = 0;
                    break;
                }
            }
        }

        //------------------------------------------------------------
        // ★プレイヤー弾の当たり判定（単体攻撃）
        //------------------------------------------------------------

            if (p->type == PROJ_PLAYER_BULLET) {

            SDL_Rect pr = { (int)p->x, (int)p->y, 8, 8 };

            for (int e = 0; e < enemy_count; e++) {

                if (!enemy_list[e].alive) continue;
                if (!enemy_list[e].alive) continue;

                SDL_Rect er = {
                    (int)enemy_list[e].x,
                    (int)enemy_list[e].y,
                    32, 32
                };

                if (Collision_Check(&pr, &er)) {

                    enemy_list[e].hp -= 1;

                    if (enemy_list[e].hp <= 0) {
                        enemy_list[e].alive = 0;
                        Drop_Spawn(enemy_list[e].x, enemy_list[e].y, DROP_ALLY_SWORD);
                    }

                    p->alive = 0;
                    break;
                }
            }
        }

        //------------------------------------------------------------
        // ★音波の当たり判定（貫通攻撃）
        //------------------------------------------------------------

         if (p->type == PROJ_SOUND_WAVE) {

            SDL_Rect pr = { (int)p->x, (int)p->y, 16, 16 };

            for (int e = 0; e < enemy_count; e++) {

                if (!enemy_list[e].alive) continue;
                if (!enemy_list[e].alive) continue;

                SDL_Rect er = {
                    (int)enemy_list[e].x,
                    (int)enemy_list[e].y,
                    32, 32
                };

                if (Collision_Check(&pr, &er)) {

                    enemy_list[e].hp -= 1;

                    if (enemy_list[e].hp <= 0) {
                        enemy_list[e].alive = 0;
                        Drop_Spawn(enemy_list[e].x, enemy_list[e].y, DROP_ALLY_SWORD);
                    }

                    // ★音波は消えない（貫通）
                }
            }
        }

    }
}


//------------------------------------------------------------
// 描画（矢・爆弾の見た目）
//------------------------------------------------------------
void Projectile_Render(SDL_Renderer *renderer) {

    for (int i = 0; i < PROJECTILE_MAX; i++) {

        if (!proj[i].alive) continue;

        Projectile *p = &proj[i];
        SDL_Rect dst = { (int)p->x, (int)p->y, 32, 32 };

        switch (p->type) {

            case PROJ_PLAYER_BULLET:
                SDL_RenderCopy(renderer, tex_bullet, NULL, &dst);
                break;

            case PROJECTILE_ARROW:
                SDL_RenderCopy(renderer, tex_arrow, NULL, &dst);
                break;

            case PROJ_BOMB_THROW:
                SDL_RenderCopy(renderer, tex_bomb_throw, NULL, &dst);
                break;

            case PROJ_SOUND_WAVE:
                SDL_RenderCopy(renderer, tex_soundwave, NULL, &dst);
                break;

           
             
        }
    }
}

