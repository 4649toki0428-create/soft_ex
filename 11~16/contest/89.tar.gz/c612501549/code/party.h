#ifndef PARTY_H
#define PARTY_H

#include"player.h"
#include <SDL2/SDL.h>
#include "enemy.h"
#include "drop.h"
#include "projectile.h"





int attack_flash;   // 攻撃した瞬間だけ1になる

// 仲間の種類
typedef enum {
    ALLY_SWORD,
    ALLY_ARROW,
    ALLY_BOMB
} AllyType;


// 仲間構造体
typedef struct {
    float x, y;          // 位置
    int alive;           // 生存フラグ
    AllyType type;       // 剣・弓・爆弾
    int attack_timer;    // 攻撃クールタイム
    int attack_interval; // 攻撃間隔
    int attack_flash;    // ★攻撃した瞬間だけ1になる（剣の描画用）
        // ★歩きアニメ用
    int anim_frame;      // 0 or 1（歩き1 / 歩き2）
    int anim_timer;      // フレーム切り替え用
    Direction dir;       // ★向き
} PartyMember;



// 関数プロトタイプ
void Party_Init();
void Party_KillMember(int index);
void Party_Update(float player_x, float player_y, Enemy *enemy_list, int enemy_count);
void Party_AddMember(AllyType type);
void Party_Render(SDL_Renderer *renderer);

extern int has_warrior;
extern int has_archer;
extern int has_mage;

#endif
