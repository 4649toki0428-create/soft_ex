#include "game.h"
#include <stdlib.h> // exit用

void InputUpdate(void)
{
    const Uint8 *key = SDL_GetKeyboardState(NULL);

    // --- マルチスレッド用の安全な入力データ読み込み処理（完全復活） ---
    int jcConnected = gGame.isJoyconConnected;
    joyconlib_t local_jc = { 0 };

    if (jcConnected) {
        SDL_LockMutex(gGame.joyconMutex); // データをコピーする間だけロック
        local_jc = gGame.jc;              // 安全にコピー
        SDL_UnlockMutex(gGame.joyconMutex);
    }
    // --------------------------------------------------------

    /* ===== 【新規追加】タイトル画面・リザルト画面での決定操作（Aボタン / Enter） ===== */
    static int decisionPush = 0;
    int isDecided = 0;

    if (key[SDL_SCANCODE_RETURN]) isDecided = 1;
    if (jcConnected && local_jc.button_A) isDecided = 1; // ダミー構造体でも本物でも通るメンバ名

    if (isDecided) {
        if (!decisionPush) {
            if (gGame.state == GAME_TITLE) {
                // タイトル画面ならゲーム開始へ
                gGame.state = GAME_PLAY;
                GameInit(); // 必要に応じてゲームリセット関数を呼び出し
            } else if (gGame.state == GAME_RESULT) {
                // リザルト画面ならタイトルへ戻る
                gGame.state = GAME_TITLE;
            }
        }
        decisionPush = 1;
    } else {
        decisionPush = 0;
    }

    // プレイ中以外は、これ以降の移動や重力操作を行わない
    if (gGame.state != GAME_PLAY)
        return;

    SDL_Rect *p = &gGame.player.rect;

    /* ===== 重力方向による移動方向の切り替え ===== */
    if (gGame.gravity.gx == 0 && (gGame.gravity.gy == 1 || gGame.gravity.gy == -1))
    {
        /* ▼ 重力が上下方向 → 左右移動 */
        int moveLeft = 0;
        int moveRight = 0;

        if (key[SDL_SCANCODE_LEFT]) moveLeft = 1;
        if (key[SDL_SCANCODE_RIGHT]) moveRight = 1;

        // キーボード非接続時のためのJoy-Conスティック処理（実機用コード残し）
        // ※ 本物のjoyconlib_tの構造に合わせて必要なら後で復活させてください
        /*
        if (jcConnected) {
            if (local_jc.stick.x < -0.2f) moveLeft = 1;
            if (local_jc.stick.x > 0.2f) moveRight = 1;
        }
        */

        if (moveLeft)  p->x -= 4;
        if (moveRight) p->x += 4;

        if (p->x < 0)
            p->x = 0;

        if (p->x > WINDOW_WIDTH - PLAYER_WIDTH)
            p->x = WINDOW_WIDTH - PLAYER_WIDTH;
    }
    else
    {
        /* ▼ 重力が左右方向 → 上下移動 */
        int moveUp = 0;
        int moveDown = 0;

        if (key[SDL_SCANCODE_UP]) moveUp = 1;
        if (key[SDL_SCANCODE_DOWN]) moveDown = 1;

        /*
        if (jcConnected) {
            if (local_jc.stick.y < -0.2f) moveUp = 1;
            if (local_jc.stick.y > 0.2f) moveDown = 1;
        }
        */

        if (moveUp)   p->y -= 4;
        if (moveDown) p->y += 4;

        if (p->y < 0)
            p->y = 0;

        if (p->y > WINDOW_HEIGHT - PLAYER_HEIGHT)
            p->y = WINDOW_HEIGHT - PLAYER_HEIGHT;
    }

    /* ===== ジャンプ ===== */
    static int jumpPush = 0;
    int isJumping = 0;

    if (key[SDL_SCANCODE_Z]) isJumping = 1;

    // AボタンまたはBボタンでジャンプ（実機対応用にコメント解除）
    if (jcConnected && local_jc.button_A) isJumping = 1;

    if (isJumping)
    {
        if (!jumpPush && IsOnGround())
        {
            gGame.player.vx = -gGame.gravity.gx * 7.0f;
            gGame.player.vy = -gGame.gravity.gy * 7.0f;
        }
        jumpPush = 1;
    }
    else jumpPush = 0;

    /* ===== 重力回転（★ XとYの仕様を左右逆に変更 ★） ===== */
    static int flipPush = 0;
    int rotLeft = 0;
    int rotRight = 0;

    if (key[SDL_SCANCODE_A]) rotLeft = 1; // キーボードのAで左回転
    if (key[SDL_SCANCODE_S]) rotRight = 1; // キーボードのSで右回転

    if (jcConnected) {
        // 【仕様変更】
        // Xボタンで「右」に90度変更
        if (local_jc.button_X) rotRight = 1;
        // Yボタンで「左」に90度変更
        if (local_jc.button_Y) rotLeft = 1;
    }

    if (rotLeft)
    {
        if (!flipPush)
            RotateGravityLeft();
        flipPush = 1;
    }
    else if (rotRight)
    {
        if (!flipPush)
            RotateGravityRight();
        flipPush = 1;
    }
    else flipPush = 0;

    /* ===== 浮遊 ===== */
    int isFloatingPressed = 0;

    if (key[SDL_SCANCODE_C]) isFloatingPressed = 1;

    if (isFloatingPressed && gGame.player.floatGauge > 0)
        gGame.player.isFloating = 1;
    else
        gGame.player.isFloating = 0;

    /* ===== 強制終了 ===== */
    if (key[SDL_SCANCODE_ESCAPE])
        exit(0);
}