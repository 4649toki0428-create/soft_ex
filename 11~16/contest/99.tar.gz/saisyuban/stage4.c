#include "game.h"
#include <math.h>

#ifndef MY_PI
#define MY_PI 3.14159265358979323846f
#endif

typedef enum { DIR_UP, DIR_DOWN, DIR_LEFT, DIR_RIGHT } SpikeDir;
typedef struct { int x; int y; SpikeDir dir; } SpikeData;
typedef struct { int x; int y; int radius; bool is_collected; } ItemData;
typedef struct { int x; int y; int w; int h; SpikeDir dir; } GoalData;

// 【新規】動く壁の構造体
typedef struct {
    float x;        // 計算用の現在X（滑らかに動かすためfloat）
    float y;        // 計算用の現在Y
    int w;          // 幅
    int h;          // 高さ
    float startX;   // 移動の基準点X
    float startY;   // 移動の基準点Y
    float moveRange;// 移動する範囲（ピクセル）
    float speed;    // 移動スピード
    bool isVertical;// 縦移動ならtrue, 横移動ならfalse
} MovingWallData;

// 円（青い〇）を描画するヘルパー関数
static void DrawCircle(SDL_Renderer *renderer, int cx, int cy, int r, SDL_Color color)
{
    // 古いSDL2でも動くよう、横線（SDL_RenderDrawLine）の組み合わせで円を塗りつぶす
    SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);
    
    for (int dy = -r; dy <= r; dy++)
    {
        // 円の方程式 x^2 + y^2 = r^2 より、各Y座標におけるXの幅を計算
        int dx = (int)sqrtf((float)(r * r - dy * dy));
        SDL_RenderDrawLine(renderer, cx - dx, cy + dy, cx + dx, cy + dy);
    }
}

/* ========================================================================= */
/* 【ステージ4 配置定義】                                                     */
/* ========================================================================= */

// 固定の壁（外枠の補助など最低限）
#define STAGE4_FIXED_WALL_COUNT 2
static const SDL_Rect stage4_fixed_walls[STAGE4_FIXED_WALL_COUNT] = {
    { 0,   350, 150,  50 }, // 左の安全足場
    { 550, 350, 150,  50 }  // 右の安全足場
};

// ★【大注目】動く壁のデータ（2基）
#define STAGE4_MOVING_WALL_COUNT 2
static MovingWallData stage4_moving_walls[STAGE4_MOVING_WALL_COUNT] = {
    // 現在X, 現在Y, 幅, 高さ, 基準X, 基準Y, 移動範囲, スピード, 縦移動か
    { 200, 200, 100,  40, 200, 200, 150, 0.05f, false }, // 1. 横に往復する壁
    { 450, 400,  40, 150, 450, 400, 120, 0.04f, true }   // 2. 上下に往復する壁
};

#define STAGE4_SPIKE_COUNT 2
static const SpikeData stage4_spikes[STAGE4_SPIKE_COUNT] = {
    { 300, 675, DIR_UP }, // 地面のトラップトゲ
    { 350, 100, DIR_DOWN } // 天井のトラップトゲ
};

#define STAGE4_ITEM_COUNT 3
static ItemData stage4_items[STAGE4_ITEM_COUNT] = {
    { 250, 150, 15, false }, // 動く壁1の上空
    { 470, 300, 15, false }, // 動く壁2のすぐ横
    { 620, 500, 15, false }  // 右下の奥
};

static const GoalData stage4_goal = { 620, 290, 45, 45, DIR_UP };

// ↓↓↓ ここから追加 ↓↓↓
// ステージ4用のアイテム全取得チェック関数
static bool IsAllItemsCollected(void)
{
    for (int i = 0; i < STAGE4_ITEM_COUNT; i++) {
        if (!stage4_items[i].is_collected) return false;
    }
    return true;
}
// ↑↑↑ ここまで追加 ↑↑↑

void Stage4_GetStartPos(int *x, int *y) {
    *x = 50;  *y = 280; // 左の足場からスタート
}

void Stage4_Init(void) {
    for(int i = 0; i < STAGE4_ITEM_COUNT; i++) {
        stage4_items[i].is_collected = false;
    }
}

// ★【重要】毎フレーム動く壁の位置を計算する関数
void Stage4_Update(void)
{
    // SDL_GetTicks() のサイン波（Sin）を使って滑らかに往復移動させる
    float ticks = (float)SDL_GetTicks();
    
    for (int i = 0; i < STAGE4_MOVING_WALL_COUNT; i++) {
        MovingWallData *mw = &stage4_moving_walls[i];
        
        // -1.0 〜 +1.0 の間で変化する値
        float wave = sinf(ticks * mw->speed * 0.05f); 
        
        if (mw->isVertical) {
            mw->y = mw->startY + (wave * mw->moveRange);
        } else {
            mw->x = mw->startX + (wave * mw->moveRange);
        }
    }
}

// 三角形描画ヘルパー
static void DrawTriangle(SDL_Renderer *renderer, int x1, int y1, int x2, int y2, int x3, int y3, SDL_Color color)
{
    SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);

    // 古いSDL2用の簡易塗りつぶし（Y座標の最小・最大を求めて水平線を引く）
    int minY = y1 < y2 ? (y1 < y3 ? y1 : y3) : (y2 < y3 ? y2 : y3);
    int maxY = y1 > y2 ? (y1 > y3 ? y1 : y3) : (y2 > y3 ? y2 : y3);

    for (int y = minY; y <= maxY; y++) {
        int x_start = 99999, x_end = -99999;
        
        // 辺1-2との交点
        if ((y1 <= y && y2 > y) || (y2 <= y && y1 > y)) {
            int x = x1 + (y - y1) * (x2 - x1) / (y2 - y1);
            if (x < x_start) x_start = x;
            if (x > x_end) x_end = x;
        }
        // 辺2-3との交点
        if ((y2 <= y && y3 > y) || (y3 <= y && y2 > y)) {
            int x = x2 + (y - y2) * (x3 - x2) / (y3 - y2);
            if (x < x_start) x_start = x;
            if (x > x_end) x_end = x;
        }
        // 辺3-1との交点
        if ((y3 <= y && y1 > y) || (y1 <= y && y3 > y)) {
            int x = x3 + (y - y3) * (x1 - x3) / (y1 - y3);
            if (x < x_start) x_start = x;
            if (x > x_end) x_end = x;
        }
        
        if (x_start <= x_end) {
            SDL_RenderDrawLine(renderer, x_start, y, x_end, y);
        }
    }
}

void Stage4_Draw(void)
{
    // 1. 固定壁の描画
    SDL_SetRenderDrawColor(gGame.renderer, 100, 110, 120, 255);
    for (int i = 0; i < STAGE4_FIXED_WALL_COUNT; i++) {
        SDL_RenderFillRect(gGame.renderer, &stage4_fixed_walls[i]);
    }

    // 1b. ★動く壁の描画（色を変えて分かりやすくする）
    SDL_SetRenderDrawColor(gGame.renderer, 0, 150, 200, 255); // 動く壁はサイバーブルー
    for (int i = 0; i < STAGE4_MOVING_WALL_COUNT; i++) {
        SDL_Rect r = { (int)stage4_moving_walls[i].x, (int)stage4_moving_walls[i].y, stage4_moving_walls[i].w, stage4_moving_walls[i].h };
        SDL_RenderFillRect(gGame.renderer, &r);
    }

    // 2. トゲの描画
    SDL_Color red = { 255, 50, 50, 255 };
    for (int i = 0; i < STAGE4_SPIKE_COUNT; i++) {
        int x = stage4_spikes[i].x; int y = stage4_spikes[i].y;
        switch (stage4_spikes[i].dir) {
            case DIR_UP:    DrawTriangle(gGame.renderer, x, y + 25, x + 50, y + 25, x + 25, y, red); break;
            case DIR_DOWN:  DrawTriangle(gGame.renderer, x, y, x + 50, y, x + 25, y + 25, red); break;
            case DIR_LEFT:  DrawTriangle(gGame.renderer, x + 25, y, x + 25, y + 50, x, y + 25, red); break;
            case DIR_RIGHT: DrawTriangle(gGame.renderer, x, y, x, y + 50, x + 25, y + 25, red); break;
        }
    }

    // 3. アイテムの描画
    SDL_Color blue = { 50, 100, 255, 255 };
    for (int i = 0; i < STAGE4_ITEM_COUNT; i++) {
        if (!stage4_items[i].is_collected) { DrawCircle(gGame.renderer, stage4_items[i].x, stage4_items[i].y, stage4_items[i].radius, blue); }
    }

    // 4. ゴールの描画
    bool active = IsAllItemsCollected();
    SDL_Color goalColor = active ? (SDL_Color){ 255, 215, 0, 255 } : (SDL_Color){ 100, 100, 100, 100 };
    SDL_Color textColor = active ? (SDL_Color){ 0, 0, 0, 255 }       : (SDL_Color){ 150, 150, 150, 100 };
    SDL_Rect goalRect = { stage4_goal.x, stage4_goal.y, stage4_goal.w, stage4_goal.h };
    SDL_SetRenderDrawBlendMode(gGame.renderer, SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(gGame.renderer, goalColor.r, goalColor.g, goalColor.b, goalColor.a);
    SDL_RenderFillRect(gGame.renderer, &goalRect);
    DrawTextHelper(gGame.font, "G", goalRect.x + goalRect.w / 2, goalRect.y + goalRect.h / 2, textColor, true);
}

void Stage4_CheckCollision(void)
{
    SDL_Rect *p = &gGame.player.rect;
    SDL_Rect result;

    // 1a. 固定壁との判定
    for (int i = 0; i < STAGE4_FIXED_WALL_COUNT; i++) {
        if (SDL_IntersectRect(p, &stage4_fixed_walls[i], &result)) {
            if (result.w < result.h) {
                if (p->x + p->w / 2 < stage4_fixed_walls[i].x + stage4_fixed_walls[i].w / 2) p->x -= result.w; else p->x += result.w;
                gGame.player.vx = 0;
            } else {
                if (p->y + p->h / 2 < stage4_fixed_walls[i].y + stage4_fixed_walls[i].h / 2) p->y -= result.h; else p->y += result.h;
                gGame.player.vy = 0;
            }
        }
    }

    // 1b. ★動く壁との判定（押し出し・ハサミ込み対応）
    for (int i = 0; i < STAGE4_MOVING_WALL_COUNT; i++) {
        SDL_Rect mwRect = { (int)stage4_moving_walls[i].x, (int)stage4_moving_walls[i].y, stage4_moving_walls[i].w, stage4_moving_walls[i].h };
        if (SDL_IntersectRect(p, &mwRect, &result)) {
            if (result.w < result.h) {
                if (p->x + p->w / 2 < mwRect.x + mwRect.w / 2) p->x -= result.w; else p->x += result.w;
                gGame.player.vx = 0;
            } else {
                if (p->y + p->h / 2 < mwRect.y + mwRect.w / 2) p->y -= result.h; else p->y += result.h;
                gGame.player.vy = 0;
            }
        }
    }

    // 2. トゲ判定（ライフを減らしステージ4初期位置へ）
    for (int i = 0; i < STAGE4_SPIKE_COUNT; i++) {
        SDL_Rect spikeRect = { stage4_spikes[i].x, stage4_spikes[i].y, 50, 25 }; // 簡易化
        if (SDL_HasIntersection(p, &spikeRect)) {
            if (gGame.player.hp > 1) {
                gGame.player.hp--;
                int startX, startY; Stage4_GetStartPos(&startX, &startY);
                p->x = startX; p->y = startY;
                gGame.player.vx = 0; gGame.player.vy = 0;
                gGame.player.floatGauge = FLOAT_MAX; gGame.player.isFloating = 0;
                gGame.gravity.gx = 0; gGame.gravity.gy = 1;
                return;
            } else {
                gGame.player.hp = 0; gGame.state = GAME_RESULT; return;
            }
        }
    }

    // 3. アイテム判定
    for (int i = 0; i < STAGE4_ITEM_COUNT; i++) {
        if (!stage4_items[i].is_collected) {
            SDL_Rect itemRect = { stage4_items[i].x - 15, stage4_items[i].y - 15, 30, 30 };
            if (SDL_HasIntersection(p, &itemRect)) { stage4_items[i].is_collected = true; }
        }
    }

    // 4. ゴール判定
    if (IsAllItemsCollected()) {
        SDL_Rect goalRect = { stage4_goal.x, stage4_goal.y, stage4_goal.w, stage4_goal.h };
        if (SDL_HasIntersection(p, &goalRect)) {
            if (gGame.stage < MAX_STAGES) {
                gGame.stage++; gGame.player.hp = 3; StageReset();
            } else {
                gGame.isGameCleared = true; // ★★★ここを追加：全ステージクリア！ ★★★
                gGame.state = GAME_RESULT;  // リザルト画面へ
            }
        }
    }
}