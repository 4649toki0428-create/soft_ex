#include "game.h"
#include <math.h>

// ★ 標準規格(c11)でも絶対に弾かれないように円周率を直接定義する
#ifndef MY_PI
#define MY_PI 3.14159265358979323846f
#endif

// トゲ・ゴールの向きを定義する列挙型
typedef enum {
    DIR_UP,
    DIR_DOWN,
    DIR_LEFT,
    DIR_RIGHT
} SpikeDir;

// トゲのデータ
typedef struct {
    int x;
    int y;
    SpikeDir dir;
} SpikeData;

// アイテムのデータ
typedef struct {
    int x;              // 中心X
    int y;              // 中心Y
    int radius;         // 半径
    bool is_collected;  // 取得済みフラグ
} ItemData;

// ゴールのデータを表す構造体
typedef struct {
    int x;              // 左上X
    int y;              // 左上Y
    int w;              // 幅
    int h;              // 高さ
    SpikeDir dir;       // 向き
} GoalData;

// 円（青い〇）を描画するヘルパー関数
static void DrawCircle(SDL_Renderer *renderer, int cx, int cy, int r, SDL_Color color)
{
    // 古いSDL2でも動くよう、横線（SDL_RenderDrawLine）の組み合わせで円を塗りつぶす
    SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);
    
    for (int dy = -r; dy <= r; dy++)
    {
        // 円の方程式 x^2 + y^2 = r^2 より、各Y座標におけるXの幅を計算
        int dx = (int)sqrtf((float)(r * r - dy * dy));
        SDL_RenderDrawLine(renderer, cx - dx, cy + dy, cx + dx, cy + dy);
    }
}

/* ========================================================================= */
/* 【ステージ2 固有の配置定義】                                              */
/* ========================================================================= */

#define STAGE2_WALL_COUNT 4
static const SDL_Rect stage2_walls[STAGE2_WALL_COUNT] = {
    { 0,   350, 250,  50 }, // 左の段差
    { 450, 400, 250,  50 }, // 右の段差
    { 350, 100,  50, 200 }, // 中央上部から垂れ下がる壁
    { 300, 500,  50, 200 }  // 中央下部からそびえる壁
};

#define STAGE2_SPIKE_COUNT 4
static const SpikeData stage2_spikes[STAGE2_SPIKE_COUNT] = {
    { 100, 325, DIR_UP },    // 左の段差の上のトゲ
    { 550, 375, DIR_UP },    // 右の段差の上のトゲ
    { 325, 200, DIR_LEFT }, // 中央上の壁の側面トゲ
    { 350, 550, DIR_RIGHT }   // 中央下の壁の側面トゲ
};

#define STAGE2_ITEM_COUNT 3
static ItemData stage2_items[STAGE2_ITEM_COUNT] = {
    { 120, 200, 15, false }, // 左上の空中（上重力や浮遊で狙う）
    { 680, 200, 15, false }, // 右上の空中
    { 400, 450, 15, false }  // 中央の狭い通路の真ん中
    //{ 50, 670, 15, false }, 
    //{ 100, 670, 15, false }, 
    //{ 150, 670, 15, false }  
};

// ステージ2のゴール配置（右下の地面に設置）
static const GoalData stage2_goal = { 655, 655, 45, 45, DIR_UP };

// スタート位置
void Stage2_GetStartPos(int *x, int *y)
{
    *x = 80;
    *y = 600; // 左下からスタート
}

// ステージ2開始・リセット時のアイテム復活処理
void Stage2_Init(void)
{
    for(int i = 0; i < STAGE2_ITEM_COUNT; i++) {
        stage2_items[i].is_collected = false;
    }
}

// 三角形描画ヘルパー
static void DrawTriangle(SDL_Renderer *renderer, int x1, int y1, int x2, int y2, int x3, int y3, SDL_Color color)
{
    SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);

    // 古いSDL2用の簡易塗りつぶし（Y座標の最小・最大を求めて水平線を引く）
    int minY = y1 < y2 ? (y1 < y3 ? y1 : y3) : (y2 < y3 ? y2 : y3);
    int maxY = y1 > y2 ? (y1 > y3 ? y1 : y3) : (y2 > y3 ? y2 : y3);

    for (int y = minY; y <= maxY; y++) {
        int x_start = 99999, x_end = -99999;
        
        // 辺1-2との交点
        if ((y1 <= y && y2 > y) || (y2 <= y && y1 > y)) {
            int x = x1 + (y - y1) * (x2 - x1) / (y2 - y1);
            if (x < x_start) x_start = x;
            if (x > x_end) x_end = x;
        }
        // 辺2-3との交点
        if ((y2 <= y && y3 > y) || (y3 <= y && y2 > y)) {
            int x = x2 + (y - y2) * (x3 - x2) / (y3 - y2);
            if (x < x_start) x_start = x;
            if (x > x_end) x_end = x;
        }
        // 辺3-1との交点
        if ((y3 <= y && y1 > y) || (y1 <= y && y3 > y)) {
            int x = x3 + (y - y3) * (x1 - x3) / (y1 - y3);
            if (x < x_start) x_start = x;
            if (x > x_end) x_end = x;
        }
        
        if (x_start <= x_end) {
            SDL_RenderDrawLine(renderer, x_start, y, x_end, y);
        }
    }
}

// アイテムの全取得チェック
static bool IsAllItemsCollected(void)
{
    for (int i = 0; i < STAGE2_ITEM_COUNT; i++) {
        if (!stage2_items[i].is_collected) return false;
    }
    return true;
}

// 描画処理
void Stage2_Draw(void)
{
    // 1. 壁の描画
    for (int i = 0; i < STAGE2_WALL_COUNT; i++)
    {
        SDL_SetRenderDrawColor(gGame.renderer, 130, 140, 150, 255); // ちょっと色味を変えてステージ2感
        SDL_RenderFillRect(gGame.renderer, &stage2_walls[i]);
    }

    // 2. トゲの描画
    SDL_Color red = { 255, 50, 50, 255 };
    for (int i = 0; i < STAGE2_SPIKE_COUNT; i++)
    {
        int x = stage2_spikes[i].x;
        int y = stage2_spikes[i].y;
        switch (stage2_spikes[i].dir)
        {
            case DIR_UP:    DrawTriangle(gGame.renderer, x, y + 25, x + 50, y + 25, x + 25, y, red); break;
            case DIR_DOWN:  DrawTriangle(gGame.renderer, x, y, x + 50, y, x + 25, y + 25, red); break;
            case DIR_LEFT:  DrawTriangle(gGame.renderer, x + 25, y, x + 25, y + 50, x, y + 25, red); break;
            case DIR_RIGHT: DrawTriangle(gGame.renderer, x, y, x, y + 50, x + 25, y + 25, red); break;
        }
    }

    // 3. アイテムの描画（未取得のものだけ）
    SDL_Color blue = { 50, 100, 255, 255 };
    for (int i = 0; i < STAGE2_ITEM_COUNT; i++)
    {
        if (!stage2_items[i].is_collected) {
            DrawCircle(gGame.renderer, stage2_items[i].x, stage2_items[i].y, stage2_items[i].radius, blue);
        }
    }

    // 4. ゴールの描画（長方形の中にGと表示）
    bool active = IsAllItemsCollected();
    SDL_Color goalColor = active ? (SDL_Color){ 255, 215, 0, 255 } : (SDL_Color){ 100, 100, 100, 100 };
    SDL_Color textColor = active ? (SDL_Color){ 0, 0, 0, 255 }       : (SDL_Color){ 150, 150, 150, 100 };

    SDL_Rect goalRect;
    goalRect.x = stage2_goal.x;
    goalRect.y = stage2_goal.y;

    if (stage2_goal.dir == DIR_UP || stage2_goal.dir == DIR_DOWN) {
        goalRect.w = stage2_goal.w;
        goalRect.h = stage2_goal.h;
    } else {
        goalRect.w = stage2_goal.h;
        goalRect.h = stage2_goal.w;
    }

    SDL_SetRenderDrawBlendMode(gGame.renderer, SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(gGame.renderer, goalColor.r, goalColor.g, goalColor.b, goalColor.a);
    SDL_RenderFillRect(gGame.renderer, &goalRect);
    
    int centerX = goalRect.x + goalRect.w / 2;
    int centerY = goalRect.y + goalRect.h / 2; 
    DrawTextHelper(gGame.font, "G", centerX, centerY, textColor, true);
}

// 当たり判定処理
void Stage2_CheckCollision(void)
{
    SDL_Rect *p = &gGame.player.rect;
    SDL_Rect result;

    // 1. 壁との当たり判定
    for (int i = 0; i < STAGE2_WALL_COUNT; i++)
    {
        if (SDL_IntersectRect(p, &stage2_walls[i], &result))
        {
            if (result.w < result.h)
            {
                if (p->x + p->w / 2 < stage2_walls[i].x + stage2_walls[i].w / 2) p->x -= result.w;
                else p->x += result.w;
                gGame.player.vx = 0;
            }
            else
            {
                if (p->y + p->h / 2 < stage2_walls[i].y + stage2_walls[i].h / 2) p->y -= result.h;
                else p->y += result.h;
                gGame.player.vy = 0;
            }
        }
    }

    // 2. 【修正】トゲとの当たり判定（ライフを削り、初期位置に戻す）
    for (int i = 0; i < STAGE2_SPIKE_COUNT; i++)
    {
        SDL_Rect spikeRect = { stage2_spikes[i].x, stage2_spikes[i].y, 
                               (stage2_spikes[i].dir == DIR_UP || stage2_spikes[i].dir == DIR_DOWN) ? 50 : 25,
                               (stage2_spikes[i].dir == DIR_UP || stage2_spikes[i].dir == DIR_DOWN) ? 25 : 50 };
        if (SDL_HasIntersection(p, &spikeRect))
        {
            if (gGame.player.hp > 1) {
                gGame.player.hp--; // ライフを1減らす

                // タイムを巻き戻さず、プレイヤーの位置と速度だけをスタート地点に戻す
                int startX, startY;
                Stage2_GetStartPos(&startX, &startY);
                gGame.player.rect.x = startX;
                gGame.player.rect.y = startY;
                gGame.player.vx = 0;
                gGame.player.vy = 0;
                gGame.player.floatGauge = FLOAT_MAX;
                gGame.player.isFloating = 0;
                gGame.gravity.gx = 0;
                gGame.gravity.gy = 1; // 重力も下向きにリセット

                return; // 多段ヒット防止のため即座に判定を抜ける
            } else {
                gGame.player.hp = 0;
                gGame.state = GAME_RESULT;
                return;
            }
        }
    }

    // 3. アイテムとの当たり判定
    for (int i = 0; i < STAGE2_ITEM_COUNT; i++)
    {
        if (!stage2_items[i].is_collected)
        {
            SDL_Rect itemRect = { stage2_items[i].x - stage2_items[i].radius, 
                                   stage2_items[i].y - stage2_items[i].radius, 
                                   stage2_items[i].radius * 2, stage2_items[i].radius * 2 };
            if (SDL_HasIntersection(p, &itemRect))
            {
                stage2_items[i].is_collected = true;
            }
        }
    }

    // 4. ゴールとの当たり判定
    if (IsAllItemsCollected())
    {
        SDL_Rect goalRect;
        goalRect.x = stage2_goal.x;
        goalRect.y = stage2_goal.y;
        
        if (stage2_goal.dir == DIR_UP || stage2_goal.dir == DIR_DOWN) {
            goalRect.w = stage2_goal.w;
            goalRect.h = stage2_goal.h;
        } else {
            goalRect.w = stage2_goal.h;
            goalRect.h = stage2_goal.w;
        }
        
        if (SDL_HasIntersection(p, &goalRect))
        {
            if (gGame.stage < MAX_STAGES) {
                gGame.stage++;
                StageReset();
            } else {
                gGame.state = GAME_RESULT;
            }
        }
    }
}