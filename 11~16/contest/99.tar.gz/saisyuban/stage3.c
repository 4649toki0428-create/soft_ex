#include "game.h"
#include <math.h>

#ifndef MY_PI
#define MY_PI 3.14159265358979323846f
#endif

typedef enum {
    DIR_UP,
    DIR_DOWN,
    DIR_LEFT,
    DIR_RIGHT
} SpikeDir;

typedef struct {
    int x;
    int y;
    SpikeDir dir;
} SpikeData;

typedef struct {
    int x;
    int y;
    int radius;
    bool is_collected;
} ItemData;

typedef struct {
    int x;
    int y;
    int w;
    int h;
    SpikeDir dir;
} GoalData;

// 円（青い〇）を描画するヘルパー関数
static void DrawCircle(SDL_Renderer *renderer, int cx, int cy, int r, SDL_Color color)
{
    // 古いSDL2でも動くよう、横線（SDL_RenderDrawLine）の組み合わせで円を塗りつぶす
    SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);
    
    for (int dy = -r; dy <= r; dy++)
    {
        // 円の方程式 x^2 + y^2 = r^2 より、各Y座標におけるXの幅を計算
        int dx = (int)sqrtf((float)(r * r - dy * dy));
        SDL_RenderDrawLine(renderer, cx - dx, cy + dy, cx + dx, cy + dy);
    }
}

/* ========================================================================= */
/* 【ステージ3 固有の配置定義】                                              */
/* ========================================================================= */

#define STAGE3_WALL_COUNT 5
static const SDL_Rect stage3_walls[STAGE3_WALL_COUNT] = {
    { 200, 100,  50, 400 }, // 左の巨大柱（上から伸びる）
    { 450, 300,  50, 400 }, // 右の巨大柱（下からそびえる）
    {   0, 300, 100,  50 }, // 左壁の出っ張り
    { 600, 300, 100,  50 }, // 右壁の出っ張り
    { 300, 400, 100,  50 }  // 中央の小さな浮島
};

#define STAGE3_SPIKE_COUNT 5
static const SpikeData stage3_spikes[STAGE3_SPIKE_COUNT] = {
    { 250, 200, DIR_RIGHT },  // 左柱の右側面（右向きの壁トゲ）
    { 425, 500, DIR_LEFT }, // 右柱の左側面（左向きの壁トゲ）
    { 325, 375, DIR_UP },    // 中央浮島の上のトゲ
    {   0, 675, DIR_UP },    // 左下地面の安全対策トゲ
    { 650, 675, DIR_UP }     // 右下地面の安全対策トゲ
};

#define STAGE3_ITEM_COUNT 4
static ItemData stage3_items[STAGE3_ITEM_COUNT] = {
    {  50, 200, 15, false }, // 左上の空間
    { 350, 200, 15, false }, // 中央上の空間（柱の間）
    { 350, 600, 15, false }, // 中央下の狭い床の上
    { 650, 200, 15, false }  // 右上の空間
};

// ステージ3のゴール配置（右下の空中・右壁の出っ張りの上に配置）
static const GoalData stage3_goal = { 630, 255, 45, 45, DIR_UP };

// スタート位置
void Stage3_GetStartPos(int *x, int *y)
{
    *x = 120;
    *y = 200; // 左上の空中付近からスタート
}

void Stage3_Init(void)
{
    for(int i = 0; i < STAGE3_ITEM_COUNT; i++) {
        stage3_items[i].is_collected = false;
    }
}

// 三角形描画ヘルパー
static void DrawTriangle(SDL_Renderer *renderer, int x1, int y1, int x2, int y2, int x3, int y3, SDL_Color color)
{
    SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);

    // 古いSDL2用の簡易塗りつぶし（Y座標の最小・最大を求めて水平線を引く）
    int minY = y1 < y2 ? (y1 < y3 ? y1 : y3) : (y2 < y3 ? y2 : y3);
    int maxY = y1 > y2 ? (y1 > y3 ? y1 : y3) : (y2 > y3 ? y2 : y3);

    for (int y = minY; y <= maxY; y++) {
        int x_start = 99999, x_end = -99999;
        
        // 辺1-2との交点
        if ((y1 <= y && y2 > y) || (y2 <= y && y1 > y)) {
            int x = x1 + (y - y1) * (x2 - x1) / (y2 - y1);
            if (x < x_start) x_start = x;
            if (x > x_end) x_end = x;
        }
        // 辺2-3との交点
        if ((y2 <= y && y3 > y) || (y3 <= y && y2 > y)) {
            int x = x2 + (y - y2) * (x3 - x2) / (y3 - y2);
            if (x < x_start) x_start = x;
            if (x > x_end) x_end = x;
        }
        // 辺3-1との交点
        if ((y3 <= y && y1 > y) || (y1 <= y && y3 > y)) {
            int x = x3 + (y - y3) * (x1 - x3) / (y1 - y3);
            if (x < x_start) x_start = x;
            if (x > x_end) x_end = x;
        }
        
        if (x_start <= x_end) {
            SDL_RenderDrawLine(renderer, x_start, y, x_end, y);
        }
    }
}

static bool IsAllItemsCollected(void)
{
    for (int i = 0; i < STAGE3_ITEM_COUNT; i++) {
        if (!stage3_items[i].is_collected) return false;
    }
    return true;
}

void Stage3_Draw(void)
{
    // 1. 壁の描画
    for (int i = 0; i < STAGE3_WALL_COUNT; i++) {
        SDL_SetRenderDrawColor(gGame.renderer, 100, 100, 120, 255); // 重厚感あるダークグレー
        SDL_RenderFillRect(gGame.renderer, &stage3_walls[i]);
    }

    // 2. トゲの描画
    SDL_Color red = { 255, 50, 50, 255 };
    for (int i = 0; i < STAGE3_SPIKE_COUNT; i++) {
        int x = stage3_spikes[i].x;
        int y = stage3_spikes[i].y;
        switch (stage3_spikes[i].dir) {
            case DIR_UP:    DrawTriangle(gGame.renderer, x, y + 25, x + 50, y + 25, x + 25, y, red); break;
            case DIR_DOWN:  DrawTriangle(gGame.renderer, x, y, x + 50, y, x + 25, y + 25, red); break;
            case DIR_LEFT:  DrawTriangle(gGame.renderer, x + 25, y, x + 25, y + 50, x, y + 25, red); break;
            case DIR_RIGHT: DrawTriangle(gGame.renderer, x, y, x, y + 50, x + 25, y + 25, red); break;
        }
    }

    // 3. アイテムの描画
    SDL_Color blue = { 50, 100, 255, 255 };
    for (int i = 0; i < STAGE3_ITEM_COUNT; i++) {
        if (!stage3_items[i].is_collected) {
            DrawCircle(gGame.renderer, stage3_items[i].x, stage3_items[i].y, stage3_items[i].radius, blue);
        }
    }

    // 4. ゴールの描画
    bool active = IsAllItemsCollected();
    SDL_Color goalColor = active ? (SDL_Color){ 255, 215, 0, 255 } : (SDL_Color){ 100, 100, 100, 100 };
    SDL_Color textColor = active ? (SDL_Color){ 0, 0, 0, 255 }       : (SDL_Color){ 150, 150, 150, 100 };

    SDL_Rect goalRect;
    goalRect.x = stage3_goal.x;
    goalRect.y = stage3_goal.y;

    if (stage3_goal.dir == DIR_UP || stage3_goal.dir == DIR_DOWN) {
        goalRect.w = stage3_goal.w;
        goalRect.h = stage3_goal.h;
    } else {
        goalRect.w = stage3_goal.h;
        goalRect.h = stage3_goal.w;
    }

    SDL_SetRenderDrawBlendMode(gGame.renderer, SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(gGame.renderer, goalColor.r, goalColor.g, goalColor.b, goalColor.a);
    SDL_RenderFillRect(gGame.renderer, &goalRect);
    
    int centerX = goalRect.x + goalRect.w / 2;
    int centerY = goalRect.y + goalRect.h / 2; 
    DrawTextHelper(gGame.font, "G", centerX, centerY, textColor, true);
}

void Stage3_CheckCollision(void)
{
    SDL_Rect *p = &gGame.player.rect;
    SDL_Rect result;

    // 1. 壁との当たり判定
    for (int i = 0; i < STAGE3_WALL_COUNT; i++) {
        if (SDL_IntersectRect(p, &stage3_walls[i], &result)) {
            if (result.w < result.h) {
                if (p->x + p->w / 2 < stage3_walls[i].x + stage3_walls[i].w / 2) p->x -= result.w;
                else p->x += result.w;
                gGame.player.vx = 0;
            } else {
                if (p->y + p->h / 2 < stage3_walls[i].y + stage3_walls[i].h / 2) p->y -= result.h;
                else p->y += result.h;
                gGame.player.vy = 0;
            }
        }
    }

    // 2. トゲとの当たり判定（ライフを削り、ステージ3の初期位置にワープ）
    for (int i = 0; i < STAGE3_SPIKE_COUNT; i++) {
        SDL_Rect spikeRect = { stage3_spikes[i].x, stage3_spikes[i].y, 
                               (stage3_spikes[i].dir == DIR_UP || stage3_spikes[i].dir == DIR_DOWN) ? 50 : 25,
                               (stage3_spikes[i].dir == DIR_UP || stage3_spikes[i].dir == DIR_DOWN) ? 25 : 50 };
        if (SDL_HasIntersection(p, &spikeRect)) {
            if (gGame.player.hp > 1) {
                gGame.player.hp--;

                int startX, startY;
                Stage3_GetStartPos(&startX, &startY);
                gGame.player.rect.x = startX;
                gGame.player.rect.y = startY;
                gGame.player.vx = 0;
                gGame.player.vy = 0;
                gGame.player.floatGauge = FLOAT_MAX;
                gGame.player.isFloating = 0;
                gGame.gravity.gx = 0;
                gGame.gravity.gy = 1;

                return; 
            } else {
                gGame.player.hp = 0;
                gGame.state = GAME_RESULT;
                return;
            }
        }
    }

    // 3. アイテムとの当たり判定
    for (int i = 0; i < STAGE3_ITEM_COUNT; i++) {
        if (!stage3_items[i].is_collected) {
            SDL_Rect itemRect = { stage3_items[i].x - stage3_items[i].radius, 
                                   stage3_items[i].y - stage3_items[i].radius, 
                                   stage3_items[i].radius * 2, stage3_items[i].radius * 2 };
            if (SDL_HasIntersection(p, &itemRect)) {
                stage3_items[i].is_collected = true;
            }
        }
    }

    // 4. ゴールとの当たり判定（全クリア判定）
    if (IsAllItemsCollected()) {
        SDL_Rect goalRect;
        goalRect.x = stage3_goal.x;
        goalRect.y = stage3_goal.y;
        
        if (stage3_goal.dir == DIR_UP || stage3_goal.dir == DIR_DOWN) {
            goalRect.w = stage3_goal.w; goalRect.h = stage3_goal.h;
        } else {
            goalRect.w = stage3_goal.h; goalRect.h = stage3_goal.w;
        }
        
        if (SDL_HasIntersection(p, &goalRect)) {
            if (gGame.stage < MAX_STAGES) {
                gGame.stage++;
                gGame.player.hp = 3;
                StageReset();
            } else {
                // ステージ3がラストなので、クリアしたらそのままゲームリザルト（成功終了）へ
                gGame.state = GAME_RESULT;
            }
        }
    }
}