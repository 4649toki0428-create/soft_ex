#ifndef DRAW_H
#define DRAW_H

void DrawTitle(void);
void DrawGame(void);
void DrawResult(void);

#endif