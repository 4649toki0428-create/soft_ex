#include <stdio.h>
#include <stdbool.h>
#include "game.h"

// ★ Joy-Con環境がある時だけ本物のスレッド関数を動かす ★
int JoyconThreadFunc(void *data)
{
    SDL_mutex *mtx = (SDL_mutex *)data;
    if (!mtx) return -1;

    while (gGame.threadRunning)
    {
        joyconlib_t temp_jc;

        // メイン側でオープン済みのポート情報を安全にコピー
        SDL_LockMutex(mtx);
        temp_jc = gGame.jc; 
        SDL_UnlockMutex(mtx);

        // スレッド内でJoy-Conの通信状態を更新（ダミー環境では何もしない）
        joycon_get_state(&temp_jc);

        // 更新したデータをメイン側に安全に書き戻す
        SDL_LockMutex(mtx);
        gGame.jc = temp_jc;
        SDL_UnlockMutex(mtx);

        // CPU負荷を抑えるウェイト
        SDL_Delay(8);
    }
    return 0;
}

int main(int argc, char *argv[])
{
    bool running = true;
    SDL_Event event;

    // SDLの初期化
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_GAMECONTROLLER) != 0)
    {
        printf("SDL_Init Error : %s\n", SDL_GetError());
        return -1;
    }

    // SDL_ttfの初期化
    if (TTF_Init() == -1)
    {
        printf("TTF_Init Error : %s\n", TTF_GetError());
        SDL_Quit();
        return -1;
    }

    gGame.window = SDL_CreateWindow(
        "Gravity Box",
        SDL_WINDOWPOS_CENTERED,
        SDL_WINDOWPOS_CENTERED,
        WINDOW_WIDTH,
        WINDOW_HEIGHT,
        SDL_WINDOW_SHOWN);

    if (!gGame.window)
    {
        printf("Window Error : %s\n", SDL_GetError());
        TTF_Quit();
        SDL_Quit();
        return -1;
    }

    gGame.renderer = SDL_CreateRenderer(
        gGame.window,
        -1,
        SDL_RENDERER_ACCELERATED);

    if (!gGame.renderer)
    {
        printf("Renderer Error : %s\n", SDL_GetError());
        SDL_DestroyWindow(gGame.window);
        TTF_Quit();
        SDL_Quit();
        return -1;
    }

    // フォントファイルの読み込み
    gGame.font       = TTF_OpenFont("PixelMplus10-Regular.ttf", 24);
    gGame.font_large = TTF_OpenFont("PixelMplus10-Regular.ttf", 48);
    
    if (!gGame.font || !gGame.font_large)
    {
        printf("Font Load Error : %s\n", TTF_GetError());
        if (gGame.font)       TTF_CloseFont(gGame.font);
        if (gGame.font_large) TTF_CloseFont(gGame.font_large);
        SDL_DestroyRenderer(gGame.renderer);
        SDL_DestroyWindow(gGame.window);
        TTF_Quit();
        SDL_Quit();
        return -1;
    }

    // Joy-Con のオープンとマルチスレッドの初期化（復活・安全化配置）
    gGame.joyconMutex = SDL_CreateMutex();
    gGame.threadRunning = 0;
    gGame.joyconThread = NULL;
    gGame.isJoyconConnected = 0;

    // ダミー環境では常にエラー(Keyboard only mode)になりスレッドは立ち上がりません
    joycon_err jc_err = joycon_open(&gGame.jc, JOYCON_R);
    if (jc_err == JOYCON_ERR_NONE) {
        gGame.isJoyconConnected = 1;
        gGame.threadRunning = 1;

        gGame.joyconThread = SDL_CreateThread(JoyconThreadFunc, "JoyconThread", gGame.joyconMutex);
        if (gGame.joyconThread == NULL) {
            printf("Thread Creation Failed!\n");
            gGame.threadRunning = 0;
        } else {
            printf("Joy-Con (R) connected. Thread started successfully.\n");
        }
    } else {
        printf("Joy-Con (R) open failed (Error code: %d). Keyboard only mode.\n", jc_err);
    }

    // ゲーム状態をタイトル画面に設定
    gGame.state = GAME_TITLE;

    // ★ メインループを完全に復活 ★
    while (running)
    {
        while (SDL_PollEvent(&event))
        {
            if (event.type == SDL_QUIT)
                running = false;
        }

        GameUpdate();

        SDL_SetRenderDrawColor(gGame.renderer, 30, 30, 30, 255);
        SDL_RenderClear(gGame.renderer);

        GameDraw();

        SDL_RenderPresent(gGame.renderer);

        SDL_Delay(16);
    }

    // スレッドの停止と解放処理（復活）
    if (gGame.isJoyconConnected) {
        gGame.threadRunning = 0;
        if (gGame.joyconThread) {
            SDL_WaitThread(gGame.joyconThread, NULL);
        }
        joycon_close(&gGame.jc);
        gGame.isJoyconConnected = 0;
    }

    // ミューテックスの破棄
    if (gGame.joyconMutex) {
        SDL_DestroyMutex(gGame.joyconMutex);
    }

    GameQuit();

    // フォント資源の解放
    if (gGame.font)       TTF_CloseFont(gGame.font);
    if (gGame.font_large) TTF_CloseFont(gGame.font_large);

    SDL_DestroyRenderer(gGame.renderer);
    SDL_DestroyWindow(gGame.window);
    
    TTF_Quit();
    SDL_Quit();

    return 0;
}