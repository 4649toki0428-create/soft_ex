#ifndef GAME_H
#define GAME_H

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <stdbool.h>

#define WINDOW_WIDTH  700
#define WINDOW_HEIGHT 700
#define PLAYER_WIDTH  30
#define PLAYER_HEIGHT 30
#define FLOAT_MAX     100.0f
#define MAX_STAGES    4  // 総ステージ数

// ★ Joy-Con未接続環境用のダミー定義 ★
typedef struct {
    int button_A;
    int button_X;
    int button_Y;
} joyconlib_t;

typedef enum {
    JOYCON_ERR_NONE = 0,
    JOYCON_ERR_FAILED = -1
} joycon_err;

#define JOYCON_R 1

typedef enum {
    GAME_TITLE,
    GAME_PLAY,
    GAME_RESULT
} GameState;

/* ★ Gravity構造体 ★ */
typedef struct {
    int gx;
    int gy;
} Gravity;

/* プレイヤー構造体 */
typedef struct {
    SDL_Rect rect;
    float vx, vy;
    int hp;
    float floatGauge;
    int isFloating;
} Player;

/* ゲーム全体の情報 */
typedef struct {
    SDL_Window   *window;
    SDL_Renderer *renderer;

    GameState state;
    Player player;
    Gravity gravity;

    int score;
    Uint32 startTime;
    Uint32 nowTime;
    int stage;

    /* フォント保持用のメンバ */
    TTF_Font *font;
    TTF_Font *font_large;

    /* Joy-Con（キーボード擬似）用メンバ */
    joyconlib_t jc;
    int isJoyconConnected;
    
    /* マルチスレッド用メンバー */
    SDL_Thread *joyconThread;   
    SDL_mutex  *joyconMutex;    
    volatile int threadRunning; 
    
    int timeLimit;      // ★追加：残り時間（秒）
    Uint32 lastTime;    // ★追加：1秒の経過を測るためのタイマー

    bool isGameCleared; // ★追加：全ステージクリアしてリザルトに来たならtrue

} GameInfo;

extern GameInfo gGame;

/* ===== 関数プロトタイプ（メインシステム） ===== */
void GameInit(void);
void GameUpdate(void);
void GameDraw(void);
void GameQuit(void);
void StageReset(void); // ★ game.cの警告を消すために追加

/* ★ 他ファイルから使う関数 ★ */
int IsOnGround(void);
void RotateGravityLeft(void);
void RotateGravityRight(void);

/* ★ 文字描画用の関数ヘルパー ★ */
void DrawTextHelper(TTF_Font *font, const char *text, int x, int y, SDL_Color color, bool center);

// ★ Joy-Conライブラリのダミー関数宣言 ★
static inline joycon_err joycon_open(joyconlib_t *jc, int id) { return JOYCON_ERR_FAILED; }
static inline void joycon_close(joyconlib_t *jc) {}
static inline void joycon_get_state(joyconlib_t *jc) {}


/* ===== 各ステージ用の関数プロトタイプ ===== */
// STAGE 1（警告とエラーを消すために過不足なく宣言）
void Stage1_Init(void);
void Stage1_GetStartPos(int *x, int *y);
void Stage1_Draw(void);
void Stage1_CheckCollision(void); // ★ game.cからの呼び出しエラーを消すために追加

// STAGE 2
void Stage2_Init(void);
void Stage2_GetStartPos(int *x, int *y);
void Stage2_Draw(void);
void Stage2_CheckCollision(void);

// STAGE 3
void Stage3_Init(void);
void Stage3_GetStartPos(int *x, int *y);
void Stage3_Draw(void);
void Stage3_CheckCollision(void);

// STAGE 4
void Stage4_Init(void);
void Stage4_GetStartPos(int *x, int *y);
void Stage4_Update(void); // ★追加
void Stage4_Draw(void);
void Stage4_CheckCollision(void);

#endif