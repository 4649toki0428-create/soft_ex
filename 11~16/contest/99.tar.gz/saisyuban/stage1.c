#include "game.h"
#include <math.h>

// ★ 標準規格(c11)でも絶対に弾かれないように円周率を直接定義する
#ifndef MY_PI
#define MY_PI 3.14159265358979323846f
#endif

// トゲ・ゴールの向きを定義する列挙型
typedef enum {
    DIR_UP,
    DIR_DOWN,
    DIR_LEFT,
    DIR_RIGHT
} SpikeDir;

// トゲのデータ
typedef struct {
    int x;
    int y;
    SpikeDir dir;
} SpikeData;

// アイテムのデータ
typedef struct {
    int x;              // 中心X
    int y;              // 中心Y
    int radius;         // 半径
    bool is_collected;  // 取得済みフラグ
} ItemData;

// 【新規】ゴールのデータを表す構造体
typedef struct {
    int x;              // 左上X
    int y;              // 左上Y
    int w;              // 幅
    int h;              // 高さ
    SpikeDir dir;       // 向き
} GoalData;

// 円（青い〇）を描画するヘルパー関数
static void DrawCircle(SDL_Renderer *renderer, int cx, int cy, int r, SDL_Color color)
{
    // 古いSDL2でも動くよう、横線（SDL_RenderDrawLine）の組み合わせで円を塗りつぶす
    SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);
    
    for (int dy = -r; dy <= r; dy++)
    {
        // 円の方程式 x^2 + y^2 = r^2 より、各Y座標におけるXの幅を計算
        int dx = (int)sqrtf((float)(r * r - dy * dy));
        SDL_RenderDrawLine(renderer, cx - dx, cy + dy, cx + dx, cy + dy);
    }
}

// 配置データ定義
#define STAGE1_WALL_COUNT 3
static const SDL_Rect stage1_walls[STAGE1_WALL_COUNT] = {
    { 450, 100, 250, 100 },
    { 450, 200, 100, 100 },
    { 200, 300, 350, 200 }
};

#define STAGE1_SPIKE_COUNT 3
static const SpikeData stage1_spikes[STAGE1_SPIKE_COUNT] = {
    { 300, 500, DIR_DOWN }, 
    { 175, 400, DIR_LEFT },  
    { 100, 675, DIR_UP }
};

// ステージ1のアイテム配置（3個）
#define STAGE1_ITEM_COUNT 3
static ItemData stage1_items[STAGE1_ITEM_COUNT] = {
    //{ 50, 100, 15, false }, 
    //{ 100, 100, 15, false }, 
    //{ 150, 100, 15, false }  
    { 25, 125, 15, false }, 
    { 215, 275, 15, false }, 
    { 675, 400, 15, false } 
};

// 【変更】ステージ1のゴール配置（位置、サイズ、向きを指定）
// 一回り小さく（幅30, 高さ45）にし、試しに通常の上向き（DIR_UP）に配置しています。
// 向きを DIR_DOWN, DIR_LEFT, DIR_RIGHT に変えるだけで自動でグラフィックが回転します。
static const GoalData stage1_goal = { 550, 250, 45, 45, DIR_LEFT };

// スタート位置
void Stage1_GetStartPos(int *x, int *y)
{
    *x = 400;
    *y = 100;
}

// ステージ1開始・リセット時のアイテム復活処理
void Stage1_Init(void)
{
    for(int i = 0; i < STAGE1_ITEM_COUNT; i++) {
        stage1_items[i].is_collected = false;
    }
}

// 三角形描画ヘルパー
static void DrawTriangle(SDL_Renderer *renderer, int x1, int y1, int x2, int y2, int x3, int y3, SDL_Color color)
{
    SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);

    // 古いSDL2用の簡易塗りつぶし（Y座標の最小・最大を求めて水平線を引く）
    int minY = y1 < y2 ? (y1 < y3 ? y1 : y3) : (y2 < y3 ? y2 : y3);
    int maxY = y1 > y2 ? (y1 > y3 ? y1 : y3) : (y2 > y3 ? y2 : y3);

    for (int y = minY; y <= maxY; y++) {
        int x_start = 99999, x_end = -99999;
        
        // 辺1-2との交点
        if ((y1 <= y && y2 > y) || (y2 <= y && y1 > y)) {
            int x = x1 + (y - y1) * (x2 - x1) / (y2 - y1);
            if (x < x_start) x_start = x;
            if (x > x_end) x_end = x;
        }
        // 辺2-3との交点
        if ((y2 <= y && y3 > y) || (y3 <= y && y2 > y)) {
            int x = x2 + (y - y2) * (x3 - x2) / (y3 - y2);
            if (x < x_start) x_start = x;
            if (x > x_end) x_end = x;
        }
        // 辺3-1との交点
        if ((y3 <= y && y1 > y) || (y1 <= y && y3 > y)) {
            int x = x3 + (y - y3) * (x1 - x3) / (y1 - y3);
            if (x < x_start) x_start = x;
            if (x > x_end) x_end = x;
        }
        
        if (x_start <= x_end) {
            SDL_RenderDrawLine(renderer, x_start, y, x_end, y);
        }
    }
}

// アイテムの全取得チェック
static bool IsAllItemsCollected(void)
{
    for (int i = 0; i < STAGE1_ITEM_COUNT; i++) {
        if (!stage1_items[i].is_collected) return false;
    }
    return true;
}

// 描画処理
void Stage1_Draw(void)
{
    // 1. 壁の描画
    for (int i = 0; i < STAGE1_WALL_COUNT; i++)
    {
        SDL_SetRenderDrawColor(gGame.renderer, 150, 150, 150, 255);
        SDL_RenderFillRect(gGame.renderer, &stage1_walls[i]);
    }

    // 2. トゲの描画
    SDL_Color red = { 255, 50, 50, 255 };
    for (int i = 0; i < STAGE1_SPIKE_COUNT; i++)
    {
        int x = stage1_spikes[i].x;
        int y = stage1_spikes[i].y;
        switch (stage1_spikes[i].dir)
        {
            case DIR_UP:    DrawTriangle(gGame.renderer, x, y + 25, x + 50, y + 25, x + 25, y, red); break;
            case DIR_DOWN:  DrawTriangle(gGame.renderer, x, y, x + 50, y, x + 25, y + 25, red); break;
            case DIR_LEFT:  DrawTriangle(gGame.renderer, x + 25, y, x + 25, y + 50, x, y + 25, red); break;
            case DIR_RIGHT: DrawTriangle(gGame.renderer, x, y, x, y + 50, x + 25, y + 25, red); break;
        }
    }

    // 3. アイテムの描画（未取得のものだけ）
    SDL_Color blue = { 50, 100, 255, 255 };
    for (int i = 0; i < STAGE1_ITEM_COUNT; i++)
    {
        if (!stage1_items[i].is_collected) {
            DrawCircle(gGame.renderer, stage1_items[i].x, stage1_items[i].y, stage1_items[i].radius, blue);
        }
    }

    // 4. 【修正】ゴールの描画（長方形の中にGと表示）
    bool active = IsAllItemsCollected();
    
    // 全取得なら金色（255, 215, 0）、未達成なら薄いグレー
    SDL_Color goalColor = active ? (SDL_Color){ 255, 215, 0, 255 } : (SDL_Color){ 100, 100, 100, 100 };
    SDL_Color textColor = active ? (SDL_Color){ 0, 0, 0, 255 }       : (SDL_Color){ 150, 150, 150, 100 }; // 文字の色

    // ゴールの枠をそのまま長方形として描画
    SDL_Rect goalRect;
    goalRect.x = stage1_goal.x;
    goalRect.y = stage1_goal.y;

    // 向きが左右の時は横長、上下の時は縦長にする（判定と見た目を一致させるため）
    if (stage1_goal.dir == DIR_UP || stage1_goal.dir == DIR_DOWN) {
        goalRect.w = stage1_goal.w;
        goalRect.h = stage1_goal.h;
    } else {
        goalRect.w = stage1_goal.h;
        goalRect.h = stage1_goal.w;
    }

    // 長方形の描画
    SDL_SetRenderDrawBlendMode(gGame.renderer, SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(gGame.renderer, goalColor.r, goalColor.g, goalColor.b, goalColor.a);
    SDL_RenderFillRect(gGame.renderer, &goalRect);
    
    // 枠線を描画して少しクッキリさせる
    //SDL_SetRenderDrawColor(gGame.renderer, 255, 255, 255, goalColor.a);
    //SDL_RenderDrawRect(gGame.renderer, &goalRect);

    // 長方形の中央に「G」の文字を描画
    // DrawTextHelper(フォント, 文字列, 中心X, 中心Y, 色, 中央揃えフラグ)
    int centerX = goalRect.x + goalRect.w / 2;
    int centerY = goalRect.y + goalRect.h / 2; // フォントの高さのズレを少し調整
    DrawTextHelper(gGame.font, "G", centerX, centerY, textColor, true);
}

// 当たり判定処理
void Stage1_CheckCollision(void)
{
    SDL_Rect *p = &gGame.player.rect;
    SDL_Rect result;

    // 1. 壁との当たり判定
    for (int i = 0; i < STAGE1_WALL_COUNT; i++)
    {
        if (SDL_IntersectRect(p, &stage1_walls[i], &result))
        {
            if (result.w < result.h)
            {
                if (p->x + p->w / 2 < stage1_walls[i].x + stage1_walls[i].w / 2) p->x -= result.w;
                else p->x += result.w;
                gGame.player.vx = 0;
            }
            else
            {
                if (p->y + p->h / 2 < stage1_walls[i].y + stage1_walls[i].h / 2) p->y -= result.h;
                else p->y += result.h;
                gGame.player.vy = 0;
            }
        }
    }

    // 2. 【修正】トゲとの当たり判定（ライフを削り、初期位置に戻す）
    for (int i = 0; i < STAGE1_SPIKE_COUNT; i++)
    {
        SDL_Rect spikeRect = { stage1_spikes[i].x, stage1_spikes[i].y, 
                               (stage1_spikes[i].dir == DIR_UP || stage1_spikes[i].dir == DIR_DOWN) ? 50 : 25,
                               (stage1_spikes[i].dir == DIR_UP || stage1_spikes[i].dir == DIR_DOWN) ? 25 : 50 };
        if (SDL_HasIntersection(p, &spikeRect))
        {
            if (gGame.player.hp > 1) {
                gGame.player.hp--; // ライフを1減らす

                // タイムを巻き戻さず、プレイヤーの位置と速度だけをスタート地点に戻す
                int startX, startY;
                Stage1_GetStartPos(&startX, &startY);
                gGame.player.rect.x = startX;
                gGame.player.rect.y = startY;
                gGame.player.vx = 0;
                gGame.player.vy = 0;
                gGame.player.floatGauge = FLOAT_MAX;
                gGame.player.isFloating = 0;
                gGame.gravity.gx = 0;
                gGame.gravity.gy = 1; // 重力も下向きにリセット

                return; // 多段ヒット防止のため即座に判定を抜ける
            } else {
                gGame.player.hp = 0;
                gGame.state = GAME_RESULT;
                return;
            }
        }
    }

    // 3. アイテムとの当たり判定
    for (int i = 0; i < STAGE1_ITEM_COUNT; i++)
    {
        if (!stage1_items[i].is_collected)
        {
            SDL_Rect itemRect = { stage1_items[i].x - stage1_items[i].radius, 
                                   stage1_items[i].y - stage1_items[i].radius, 
                                   stage1_items[i].radius * 2, stage1_items[i].radius * 2 };
            if (SDL_HasIntersection(p, &itemRect))
            {
                stage1_items[i].is_collected = true;
            }
        }
    }

    // 4. 【修正】ゴールとの当たり判定（向きによってサイズを自動反転）
    if (IsAllItemsCollected())
    {
        SDL_Rect goalRect;
        goalRect.x = stage1_goal.x;
        goalRect.y = stage1_goal.y;
        
        // 上下向きならそのまま、左右向きなら幅と高さを入れ替える
        if (stage1_goal.dir == DIR_UP || stage1_goal.dir == DIR_DOWN) {
            goalRect.w = stage1_goal.w;
            goalRect.h = stage1_goal.h;
        } else {
            goalRect.w = stage1_goal.h; // 幅に本来の高さを代入
            goalRect.h = stage1_goal.w; // 高さに入来の幅を代入
        }
        
        if (SDL_HasIntersection(p, &goalRect))
        {
            if (gGame.stage < MAX_STAGES) {
                gGame.stage++;
                StageReset();
            } else {
                gGame.state = GAME_RESULT;
            }
        }
    }
}