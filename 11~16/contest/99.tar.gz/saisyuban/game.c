#include "game.h"
#include "input.h"
#include "draw.h"

// ★★★ ここで制限時間をいつでも変更・調整できます（例: 60 = 1分, 90 = 1分半） ★★★
#define STAGE_TIME_LIMIT 60

GameInfo gGame;

/* ===== 重力回転 ===== */
void RotateGravityRight(void)
{
    int gx = gGame.gravity.gx;
    int gy = gGame.gravity.gy;

    gGame.gravity.gx = gy;
    gGame.gravity.gy = -gx;
}

void RotateGravityLeft(void)
{
    int gx = gGame.gravity.gx;
    int gy = gGame.gravity.gy;

    gGame.gravity.gx = -gy;
    gGame.gravity.gy = gx;
}

/* ===== 接地判定 ===== */
int IsOnGround(void)
{
    SDL_Rect *p = &gGame.player.rect;

    if (gGame.gravity.gx == 0 && gGame.gravity.gy == 1)
        return p->y >= WINDOW_HEIGHT - PLAYER_HEIGHT;

    if (gGame.gravity.gx == 0 && gGame.gravity.gy == -1)
        return p->y <= 100;

    if (gGame.gravity.gx == 1 && gGame.gravity.gy == 0)
        return p->x >= WINDOW_WIDTH - PLAYER_WIDTH;

    if (gGame.gravity.gx == -1 && gGame.gravity.gy == 0)
        return p->x <= 0;

    return 0;
}

/* ===== ゲームのリセット・初期化 ===== */
void GameInit(void)
{
    gGame.state = GAME_PLAY;
    gGame.stage = 1; 
    gGame.player.hp = 3;
    gGame.isGameCleared = false; // ★追加：初期化時はまだ未クリア

    // ★ マクロで指定した制限時間（秒）を初期セット
    gGame.timeLimit = STAGE_TIME_LIMIT;
    gGame.lastTime = SDL_GetTicks(); // タイマーの基準点を記録

    gGame.player.rect.w = PLAYER_WIDTH;
    gGame.player.rect.h = PLAYER_HEIGHT;

    StageReset(); 
}

/* ===== 毎フレームの更新処理 ===== */
void GameUpdate(void)
{
    InputUpdate();

    switch (gGame.state)
    {
    case GAME_TITLE:
        break;

    case GAME_PLAY:
        /* ===== 【新規追加】動くギミックの更新 ===== */
        if (gGame.stage == 4) {
            Stage4_Update(); // ★毎フレーム動く壁の位置を計算
        }

        /* ===== 【新規】カウントダウン処理 ===== */
        Uint32 currentTime = SDL_GetTicks();
        // 前回の減少から1000ミリ秒（1秒）以上経っていたら
        if (currentTime - gGame.lastTime >= 1000)
        {
            gGame.timeLimit--;         // 1秒減らす
            gGame.lastTime = currentTime; // 基準点を更新

            // 0秒になったらゲームオーバー（リザルト画面へ）
            if (gGame.timeLimit <= 0)
            {
                gGame.timeLimit = 0;
                gGame.state = GAME_RESULT; 
                return;
            }
        }

        /* ===== 重力適用 ===== */
        if (gGame.player.isFloating && gGame.player.floatGauge > 0)
        {
            gGame.player.vx += gGame.gravity.gx * 0.08f;
            gGame.player.vy += gGame.gravity.gy * 0.08f;

            gGame.player.floatGauge -= 20.0f / 60.0f;
            if (gGame.player.floatGauge < 0)
                gGame.player.floatGauge = 0;
        }
        else
        {
            gGame.player.vx += gGame.gravity.gx * 0.35f;
            gGame.player.vy += gGame.gravity.gy * 0.35f;
        }

        /* ===== 移動更新 ===== */
        gGame.player.rect.x += (int)gGame.player.vx;
        gGame.player.rect.y += (int)gGame.player.vy;

        /* ===== 4辺の壁（常に当たり判定） ===== */
        SDL_Rect *p = &gGame.player.rect;

        /* 左壁 */
        if (p->x < 0)
        {
            p->x = 0; gGame.player.vx = 0;
            if (IsOnGround()) {
                gGame.player.floatGauge += 30.0f / 60.0f;
                if (gGame.player.floatGauge > FLOAT_MAX) gGame.player.floatGauge = FLOAT_MAX;
            }
        }

        /* 右壁 */
        if (p->x > WINDOW_WIDTH - PLAYER_WIDTH)
        {
            p->x = WINDOW_WIDTH - PLAYER_WIDTH; gGame.player.vx = 0;
            if (IsOnGround()) {
                gGame.player.floatGauge += 30.0f / 60.0f;
                if (gGame.player.floatGauge > FLOAT_MAX) gGame.player.floatGauge = FLOAT_MAX;
            }
        }

        /* 上壁 */
        if (p->y < 100)
        {
            p->y = 100; gGame.player.vy = 0;
            if (IsOnGround()) {
                gGame.player.floatGauge += 30.0f / 60.0f;
                if (gGame.player.floatGauge > FLOAT_MAX) gGame.player.floatGauge = FLOAT_MAX;
            }
        }

        /* 下壁 */
        if (p->y > WINDOW_HEIGHT - PLAYER_HEIGHT)
        {
            p->y = WINDOW_HEIGHT - PLAYER_HEIGHT; gGame.player.vy = 0;
            if (IsOnGround()) {
                gGame.player.floatGauge += 30.0f / 60.0f;
                if (gGame.player.floatGauge > FLOAT_MAX) gGame.player.floatGauge = FLOAT_MAX;
            }
        }

        /* ===== 各ステージ固有の判定呼び出し ===== */
        if (gGame.stage == 1) {
            Stage1_CheckCollision();
        } else if (gGame.stage == 2) {
            Stage2_CheckCollision();
        } else if (gGame.stage == 3) {  // ★ここを追加！
            Stage3_CheckCollision();
        } else if (gGame.stage == 4) { // ★ここを追加！
            Stage4_CheckCollision();
        }

    case GAME_RESULT:
        break;
    }
}

/* ===== 描画処理の振り分け ===== */
void GameDraw(void)
{
    switch (gGame.state)
    {
    case GAME_TITLE: DrawTitle(); break;
    case GAME_PLAY:  DrawGame();  break;
    case GAME_RESULT:DrawResult();break;
    }
}

/* ===== 終了処理 ===== */
void GameQuit(void)
{
}

/* ===== ステージ位置・状態リセット ===== */
void StageReset(void) {
    int startX = 0, startY = 0;
    
    switch(gGame.stage) {
        case 1: Stage1_Init(); Stage1_GetStartPos(&startX, &startY); break;
        case 2: Stage2_Init(); Stage2_GetStartPos(&startX, &startY); break;
        case 3: Stage3_Init(); Stage3_GetStartPos(&startX, &startY); break;
        case 4: Stage4_Init(); Stage4_GetStartPos(&startX, &startY); break;
    }
    gGame.player.rect.x = startX;
    gGame.player.rect.y = startY;
    
    gGame.player.vx = 0;
    gGame.player.vy = 0;
    gGame.player.floatGauge = FLOAT_MAX;
    gGame.player.isFloating = 0;

    gGame.gravity.gx = 0;
    gGame.gravity.gy = 1;

    // 🔴【新規追加】ステージ切り替え・リセット時にライフとタイムを初期値に戻す
    gGame.player.hp = 3;                  // ライフを3に全回復
    gGame.timeLimit = STAGE_TIME_LIMIT;   // タイムをマクロの初期値(60秒)に戻す
    gGame.lastTime = SDL_GetTicks();      // カウントダウン用のタイマー基準点も再設定
}