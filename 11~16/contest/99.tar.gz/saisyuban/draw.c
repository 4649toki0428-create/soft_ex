#include "game.h"
#include "draw.h"

/* ===== ステージ用の関数宣言 ===== */
void Stage1_Draw(void);
void Stage2_Draw(void); // ★ステージ2の描画関数を宣言

/* ★ 文字列を描画するための共通ヘルパー関数 ★ */
void DrawTextHelper(TTF_Font *font, const char *text, int x, int y, SDL_Color color, bool center)
{
    if (!font || !text) return;

    // 文字列からサーフェスを生成
    SDL_Surface *surface = TTF_RenderUTF8_Blended(font, text, color);
    if (!surface) return;

    // サーフェスからテクスチャを生成
    SDL_Texture *texture = SDL_CreateTextureFromSurface(gGame.renderer, surface);
    if (!texture) {
        SDL_FreeSurface(surface);
        return;
    }

    SDL_Rect dstRect = { x, y, surface->w, surface->h };
    
    // 中央揃えにする場合の座標調整
    if (center) {
        dstRect.x = x - surface->w / 2;
        dstRect.y = y - surface->h / 2;
    }

    // 画面へ描画
    // (※ 2026年現在の環境に合わせてSDL_RenderCopyを使用)
    SDL_RenderCopy(gGame.renderer, texture, NULL, &dstRect);

    // メモリの解放
    SDL_DestroyTexture(texture);
    SDL_FreeSurface(surface);
}

void DrawTitle(void)
{
    /* 背景 */
    SDL_SetRenderDrawColor(gGame.renderer, 40, 40, 40, 255);
    SDL_RenderClear(gGame.renderer);

    SDL_Color white = {255, 255, 255, 255};
    SDL_Color black = {0, 0, 0, 255};
    SDL_Color gray  = {180, 180, 180, 255};

    /* ===== タイトルロゴ文字の表示 ===== */
    DrawTextHelper(gGame.font_large, "GRAVITY BOX", 350, 140, white, true);

    /* ===== START ボタンの枠 ===== */
    SDL_Rect startRect = {250, 300, 200, 80};
    SDL_SetRenderDrawColor(gGame.renderer, 0, 200, 0, 255);
    SDL_RenderFillRect(gGame.renderer, &startRect);

    /* ===== START ボタン内の実際の文字表示 ===== */
    DrawTextHelper(gGame.font, "START", 350, 340, black, true);

    /* ===== 操作ガイドのテキストを追加 ===== */
    DrawTextHelper(gGame.font, "Press A Button or ENTER to Start", 350, 440, gray, true);
}


void DrawGame(void)
{
    SDL_SetRenderDrawColor(gGame.renderer, 40, 40, 40, 255);
    SDL_RenderClear(gGame.renderer);

    /* ===== 上部 UI領域の文字表示 ===== */
    SDL_Color white = {255, 255, 255, 255};
    char uiStr[32];

    // 1. ライフ（HP）の表示
    snprintf(uiStr, sizeof(uiStr), "LIFE: %d", gGame.player.hp);
    DrawTextHelper(gGame.font, uiStr, 30, 35, white, false);

    // 2. 残り時間のカウントダウン表示（重複を削除してスッキリ化）
    Uint32 minutes = gGame.timeLimit / 60;
    Uint32 seconds = gGame.timeLimit % 60;

    snprintf(uiStr, sizeof(uiStr), "TIME: %02d:%02d", minutes, seconds);
    DrawTextHelper(gGame.font, uiStr, 220, 35, white, false);
    
    // 3. 現在のステージ数を中央寄りに表示
    char stageStr[16];
    snprintf(stageStr, sizeof(stageStr), "STAGE: %d", gGame.stage);
    DrawTextHelper(gGame.font, stageStr, 420, 35, white, false);

    // UI領域（上部100px）とゲームプレイ領域の境界線
    SDL_SetRenderDrawColor(gGame.renderer, 100, 100, 100, 255);
    SDL_RenderDrawLine(gGame.renderer, 0, 100, 700, 100);

    /* ===== ステージ固有のグラフィック描画振り分け ===== */
    if (gGame.stage == 1) {
        Stage1_Draw();
    } else if (gGame.stage == 2) {
        Stage2_Draw();
    } else if (gGame.stage == 3) {
        Stage3_Draw();
    } else if (gGame.stage == 4) { // ★ここを追加！
        Stage4_Draw();
    }

    /* ===== プレイヤーの描画 ===== */
    SDL_SetRenderDrawColor(gGame.renderer, 0, 255, 0, 255);
    SDL_RenderFillRect(gGame.renderer, &gGame.player.rect);

    /* ===== プレイヤーの重力方向矢印（▼） ===== */
    SDL_SetRenderDrawColor(gGame.renderer, 255, 255, 255, 255);

    SDL_Rect *p = &gGame.player.rect;
    int cx = p->x + p->w / 2;   // 中心X
    int cy = p->y + p->h / 2;   // 中心Y

    int size = 12; // ▼の大きさ

    /* ▼ 下向き */
    if (gGame.gravity.gx == 0 && gGame.gravity.gy == 1)
    {
        SDL_RenderDrawLine(gGame.renderer, cx - size/2, cy - size/2, cx, cy + size/2);
        SDL_RenderDrawLine(gGame.renderer, cx + size/2, cy - size/2, cx, cy + size/2);
        SDL_RenderDrawLine(gGame.renderer, cx - size/2, cy - size/2, cx + size/2, cy - size/2);
    }

    /* ▲ 上向き */
    if (gGame.gravity.gx == 0 && gGame.gravity.gy == -1)
    {
        SDL_RenderDrawLine(gGame.renderer, cx - size/2, cy + size/2, cx, cy - size/2);
        SDL_RenderDrawLine(gGame.renderer, cx + size/2, cy + size/2, cx, cy - size/2);
        SDL_RenderDrawLine(gGame.renderer, cx - size/2, cy + size/2, cx + size/2, cy + size/2);
    }

    /* ▶ 右向き */
    if (gGame.gravity.gx == 1 && gGame.gravity.gy == 0)
    {
        SDL_RenderDrawLine(gGame.renderer, cx - size/2, cy - size/2, cx + size/2, cy);
        SDL_RenderDrawLine(gGame.renderer, cx - size/2, cy + size/2, cx + size/2, cy);
        SDL_RenderDrawLine(gGame.renderer, cx - size/2, cy - size/2, cx - size/2, cy + size/2);
    }

    /* ◀ 左向き */
    if (gGame.gravity.gx == -1 && gGame.gravity.gy == 0)
    {
        SDL_RenderDrawLine(gGame.renderer, cx + size/2, cy - size/2, cx - size/2, cy);
        SDL_RenderDrawLine(gGame.renderer, cx + size/2, cy + size/2, cx - size/2, cy);
        SDL_RenderDrawLine(gGame.renderer, cx + size/2, cy - size/2, cx + size/2, cy + size/2);
    }
}




void DrawResult(void)
{
    SDL_Color white = {255, 255, 255, 255};
    SDL_Color black = {0, 0, 0, 255};
    SDL_Color gray  = {180, 180, 180, 255};

    if (gGame.isGameCleared)
    {
        /* ========================================================================= */
        /*  GAME CLEAR 画面（全ステージクリア時）                                    */
        /* ========================================================================= */
        // 背景：上品なネイビー/ダークブルー
        SDL_SetRenderDrawColor(gGame.renderer, 20, 30, 50, 255);
        SDL_RenderClear(gGame.renderer);

        // お祝いテキスト（金色をイメージした黄色）
        SDL_Color gold = {255, 215, 0, 255};
        DrawTextHelper(gGame.font_large, "CONGRATULATIONS!", 350, 120, gold, true);
        DrawTextHelper(gGame.font, "ALL STAGES CLEARED!", 350, 190, white, true);

        /* メインボタン枠（金色） */
        SDL_Rect btnRect = {250, 300, 200, 80};
        SDL_SetRenderDrawColor(gGame.renderer, 255, 215, 0, 255);
        SDL_RenderFillRect(gGame.renderer, &btnRect);
        DrawTextHelper(gGame.font, "VICTORY", 350, 340, black, true);
        
        DrawTextHelper(gGame.font, "Press A Button or ENTER to Title", 350, 440, gray, true);
    }
    else
    {
        /* ========================================================================= */
        /*  GAME OVER 画面（死亡またはタイムアップ時）                                */
        /* ========================================================================= */
        // 背景：不気味なダークレッド
        SDL_SetRenderDrawColor(gGame.renderer, 50, 20, 20, 255);
        SDL_RenderClear(gGame.renderer);

        /* ===== リザルトテキストの表示 ===== */
        DrawTextHelper(gGame.font_large, "GAME OVER", 350, 140, white, true);

        /* RETRY ボタン枠（赤） */
        SDL_Rect retryRect = {250, 300, 200, 80};
        SDL_SetRenderDrawColor(gGame.renderer, 255, 0, 0, 255);
        SDL_RenderFillRect(gGame.renderer, &retryRect);
        DrawTextHelper(gGame.font, "RETRY", 350, 340, white, true);

        /* ===== 操作ガイドテキスト ===== */
        DrawTextHelper(gGame.font, "Press A Button or ENTER to Title", 350, 440, gray, true);
    }
}