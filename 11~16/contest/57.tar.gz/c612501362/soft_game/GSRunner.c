/*
GSRunner.c
main
*/

#include "system.h"
#include <stdio.h>
#include <joyconlib.h>

joyconlib_t gJC;
joycon_btn btn = { 0 };
SDL_bool joyconEnabled  = SDL_FALSE;
int Trapdamege;

int main(void)
{
    /** 初期化処理 **/
    /* SDL */
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER) < 0) {
        return PrintError(SDL_GetError());
    }
    /** ゲームシステム初期化 
    if (InitSystem("chara.data", "position.data") < 0) {
        PrintError("failed to initialize System");
        goto DESTROYSYSTEM;
    }
    **/
    if (InitWindow() < 0) {
        PrintError("failed to initialize Window");
        goto DESTROYSYSTEM;
    }

    
    joycon_err err = joycon_open(&gJC, JOYCON_R);
    if (JOYCON_ERR_NONE != err) {
        printf("joycon open failed:%d\n", err);
        joyconEnabled = SDL_FALSE;
        //return -1;
    }
    else {
        joyconEnabled = SDL_TRUE;
    }


    SDL_bool loopflg = SDL_TRUE;
    gGame.gamescene = GS_TITLE; 

    while (loopflg) {
        loopflg = InputEvent();

        switch (gGame.gamescene) {
            case GS_TITLE:
                UpdateTitle();
                DrawTitle();      
                break;
            
            case GS_STAGESELECT:
                UpdateSelect();
                DrawSelect();
                break;

            case GS_PLAYING:    
                UpdateGame();
                DrawGame();
                break;

            case GS_GAMEOVER:
                UpdateGameOver();
                DrawGameOver();
                break;

            case GS_CLEAR:
                UpdateClear();
                DrawClear();      
                break;
        }

        SDL_Delay(15);
    }

    if (joyconEnabled) {
        joycon_close(&gJC);
    }

DESTROYALL:
    DestroyWindow();
DESTROYSYSTEM:
    DestroySystem();
    SDL_Quit();

    return 0;
}

void UpdateTitle(void)
{

    if (gGame.input.jump) { 
        gGame.stageNum = 1;

        gGame.input.jump = SDL_FALSE;
        
        gGame.gamescene = GS_STAGESELECT;
    }
}

void UpdateSelect(void)
{
    if (gGame.input.left) {
        gGame.stageNum--;
        if (gGame.stageNum < 1) gGame.stageNum = 5;
        gGame.input.left = SDL_FALSE;
    }

    if (gGame.input.right) {
        gGame.stageNum++;
        if (gGame.stageNum > 5) gGame.stageNum = 1;
        gGame.input.right = SDL_FALSE;
    }

    if (gGame.input.jump) {
        gGame.input.jump = SDL_FALSE;

        if (gGame.stageNum == STAGE1)
            memcpy(mapData, mapData_stage1, sizeof(mapData_stage1));
        else if (gGame.stageNum == STAGE2)
            memcpy(mapData, mapData_stage2, sizeof(mapData_stage2));
        else if (gGame.stageNum == STAGE3)
            memcpy(mapData, mapData_stage3, sizeof(mapData_stage3));
        else if (gGame.stageNum == STAGE4)
            memcpy(mapData, mapData_stage4, sizeof(mapData_stage4));
        else if (gGame.stageNum == STAGE5)
            memcpy(mapData, mapData_stage5, sizeof(mapData_stage5));

        InitPlayer();
        InitEnemies();

        if (gGame.stageNum == 5)
            Trapdamege = 100;
        else if (gGame.stageNum == 4)
            Trapdamege = 15;
        else 
            Trapdamege = 10;
        gGame.gamescene = GS_PLAYING;
    }
}

void UpdateGame(void)
{
    if (gGame.gravityCooldown > 0)
    {
        gGame.gravityCooldown -= 1.0f / 60.0f;

        if (gGame.gravityCooldown < 0)
            gGame.gravityCooldown = 0;
    }

    if (player.hp <= 0) {
        gGame.gamescene = GS_GAMEOVER;
    }

    UpdatePlayer();
    UpdateEnemies();
    CheckHitEnemy();
    CheckEnemyCollision();
    
    UpdateCamera();

    if (player.invincibleTime > 0) {
        player.invincibleTime--;
    }

    if (player.isGround) {

        // 一定時間以上落下していたらダメージ
        if (player.fallTime > 120) {
                player.hp -= 100;
                damageFlash = 5;
                player.invincibleTime = 60;  // 無敵時間
        }
        else if (player.fallTime > 60) {
                player.hp -= 20;
                damageFlash = 5;
                player.invincibleTime = 60;  // 無敵時間

        }
    
        // 接地したのでリセット
        player.fallTime = 0;
    }
}

void UpdatePlayer(void)
{
    const float G = 0.8f;            // 重力加速度
    const float MAX_V = 15.0f;       // 速度上限
    const float Jump_power = 15.0f;
    // タイルサイズとプレイヤーサイズ
    const int TILE = 32;
    const int W = 32;
    const int H = 32;

    // 落下中なら fallTime++
    if (!player.isGround) {
        player.fallTime++;
        if (player.fallTime > 10) {
            gGame.input.jump = SDL_FALSE;
        }
    }


    
    if ( player.gravity == GRAVITY_Down ) 
    { 
        if (gGame.input.right) { 
            player.vx = 4.0f;
        } 
        else if (gGame.input.left) { 
            player.vx = -4.0f; 
        } 
        else { 
            player.vx = 0; 
        } 
    } 
    if ( player.gravity == GRAVITY_Up ) 
    { 
        if (gGame.input.right) { 
            player.vx = -4.0f;
        } 
        else if (gGame.input.left) { 
            player.vx = 4.0f; 
        } 
        else { 
            player.vx = 0; 
        } 
    } 
    if ( player.gravity == GRAVITY_Left ) { 
        if (gGame.input.right) { 
            player.vy = 4.0f; 
        } 
        else if (gGame.input.left) { 
            player.vy = -4.0f; 
        } 
        else { 
            player.vy = 0; 
        } 
    }
    if ( player.gravity == GRAVITY_Right ) { 
        if (gGame.input.right) { 
            player.vy = -4.0f; 
        } 
        else if (gGame.input.left) { 
            player.vy = 4.0f; 
        } 
        else { 
            player.vy = 0; 
        } 
    }

    // 重力方向に応じた加速度
    switch (player.gravity) {
    case GRAVITY_Down:  player.ax = 0;  player.ay =  G; break;
    case GRAVITY_Up:    player.ax = 0;  player.ay = -G; break;
    case GRAVITY_Left:  player.ax = -G; player.ay = 0;  break;
    case GRAVITY_Right: player.ax =  G; player.ay = 0;  break;
    }

    if ( player.isGround == SDL_TRUE && gGame.input.jump == SDL_TRUE && player.invincibleTime == 0 ) { 
        switch(player.gravity)
        {
            case GRAVITY_Down:
                player.vy = -Jump_power;
                break;

            case GRAVITY_Up:
                player.vy = Jump_power;
                break;

            case GRAVITY_Left:
                player.vx = Jump_power;
                break;

            case GRAVITY_Right:
                player.vx = -Jump_power;
                break;
        }
        player.isGround = SDL_FALSE;
        gGame.input.jump = SDL_FALSE;
    }

    // 接地中はその方向の加速度を無効化して速度を固定
    if (player.isGround) {
        if (player.gravity == GRAVITY_Down || player.gravity == GRAVITY_Up) {
            player.vy = 0;
            player.ay = 0;
        } else {
            player.vx = 0;
            player.ax = 0;
        }
    } else {
        // 接地していなければ加速度を速度に反映
        player.vx += player.ax;
        player.vy += player.ay;
    }

    // 速度の上限
    if (player.vx >  MAX_V) player.vx =  MAX_V;
    if (player.vx < -MAX_V) player.vx = -MAX_V;
    if (player.vy >  MAX_V) player.vy =  MAX_V;
    if (player.vy < -MAX_V) player.vy = -MAX_V;

     // 位置更新の直前に、一旦接地フラグをクリアする
     player.isGround = SDL_FALSE;

     // 位置更新
     
     //float oldX = player.point.x;
     //float oldY = player.point.y;

     // ==========================================
     // X 移動と X 衝突チェック
     // ==========================================
     player.point.x += player.vx;
     {
         int leftTile  = (int)(player.point.x) / TILE;
         int rightTile = (int)(player.point.x + W - 1) / TILE;
         int topTile   = (int)(player.point.y) / TILE;
         int bottomTile= (int)(player.point.y + H - 1) / TILE;
 
         // 右方向の衝突チェック
         if (player.vx > 0) {
             for (int ty = topTile; ty <= bottomTile; ++ty) {
                 if (mapData[ty][rightTile] != 0 && !IsGravityBlock(mapData[ty][rightTile])) {
                    if (mapData[ty][rightTile] == 2) {
                    gGame.gamescene = GS_CLEAR;
                    }
                    else if (mapData[ty][rightTile] == 3) {
                        // トラップダメージ
                        if (player.hp > 0) {
                            TrapDamege();
                        }
                    }
                     player.point.x = rightTile * TILE - W;
                     player.vx = 0;
                     // 右重力のときに右壁にぶつかったら接地
                     if (player.gravity == GRAVITY_Right) {
                         player.isGround = SDL_TRUE;
                     }
                     break;
                 }
             }
         }
         // 左方向の衝突チェック
         else if (player.vx < 0) {
             for (int ty = topTile; ty <= bottomTile; ++ty) {
                 if (mapData[ty][leftTile] != 0 && !IsGravityBlock(mapData[ty][leftTile])) {
                    if (mapData[ty][leftTile] == 2) {
                    gGame.gamescene = GS_CLEAR;
                    }
                    else if (mapData[ty][leftTile] == 3) {
                        // トラップダメージ
                        if (player.hp > 0) {
                            TrapDamege();
                        }
                    }
                     player.point.x = leftTile * TILE + TILE;
                     player.vx = 0;
                     // 左重力のときに左壁にぶつかったら接地
                     if (player.gravity == GRAVITY_Left) {
                         player.isGround = SDL_TRUE;
                     }
                     break;
                 }
             }
         }
     }
 
     // ==========================================
     // Y 移動と Y 衝突チェック
     // ==========================================
     player.point.y += player.vy;
     {
         int leftTile  = (int)(player.point.x) / TILE;
         int rightTile = (int)(player.point.x + W - 1) / TILE;
         int topTile   = (int)(player.point.y) / TILE;
         int bottomTile= (int)(player.point.y + H - 1) / TILE;
 
         // 下方向の衝突チェック
         if (player.vy > 0) {
             for (int tx = leftTile; tx <= rightTile; ++tx) {
                 if (mapData[bottomTile][tx] != 0 && !IsGravityBlock(mapData[bottomTile][tx])) {
                    if (mapData[bottomTile][tx] == 2) {
                    gGame.gamescene = GS_CLEAR;
                    }                     
                    else if (mapData[bottomTile][tx] == 3) {
                        // トラップダメージ
                        if (player.hp > 0) {
                            TrapDamege();
                        }
                    }
                    player.point.y = bottomTile * TILE - H;
                     player.vy = 0;
                     // 下重力のときに床にぶつかったら接地
                     if (player.gravity == GRAVITY_Down) {
                         player.isGround = SDL_TRUE;
                     }
                     break;
                 }
             }
         }
         // 上方向の衝突チェック
         else if (player.vy < 0) {
             for (int tx = leftTile; tx <= rightTile; ++tx) {
                 if (mapData[topTile][tx] != 0 && !IsGravityBlock(mapData[topTile][tx])) {
                    if (mapData[topTile][tx] == 2) {
                    gGame.gamescene = GS_CLEAR;
                    }
                    else if (mapData[topTile][tx] == 3) {
                        // トラップダメージ
                        if (player.hp > 0) {
                            TrapDamege();
                        }
                    }
                     player.point.y = topTile * TILE + TILE;
                     player.vy = 0;
                     // 上重力のときに天井にぶつかったら接地
                     if (player.gravity == GRAVITY_Up) {
                         player.isGround = SDL_TRUE;
                     }
                     break;
                 }
             }
         }
     }

    PlayerDirection();
    CheckOutOfMap();
}


void CheckOutOfMap(void)
{

    int mapWidth  = MAP_W * TILE_SIZE;
    int mapHeight = MAP_H * TILE_SIZE;

    if (player.point.x < 0 ||
        player.point.y < 0 ||
        player.point.x + TILE_SIZE > mapWidth ||
        player.point.y + TILE_SIZE > mapHeight)
    {
        player.hp = 0;
    }
}


void UpdateGameOver(void)
{
    if (gGame.input.jump) {
        gGame.input.jump = SDL_FALSE;
        gGame.gamescene = GS_TITLE;
    }
}

void UpdateClear(void)
{
    if (gGame.input.jump) {
        gGame.input.jump = SDL_FALSE;
        gGame.gamescene = GS_TITLE;
    }
}

void UpdateEnemies(void)
{
    const float G = 0.8f;   
    const int TILE = 32;
    const int W = 32;
    const int H = 32;

    for (int i = 0; i < enemyCount; i++) {

        // Enemy2：プレイヤーの上下重力だけ反映
        if (enemies[i].type == CT_Enemy2) {

            if (player.gravity == GRAVITY_Down) {
                enemies[i].gravity = GRAVITY_Down;
            }
            else if (player.gravity == GRAVITY_Up) {
                enemies[i].gravity = GRAVITY_Up;
            }
            else {
                // 左右重力は無視
                enemies[i].gravity = GRAVITY_Down;
            }
        }

        // 重力加速度（上下のみ）
        if (enemies[i].gravity == GRAVITY_Down) {
            enemies[i].ay = G;
        } else {
            enemies[i].ay = -G;
        }

        enemies[i].ax = 0;

        enemies[i].vx += enemies[i].ax;
        enemies[i].vy += enemies[i].ay;

        if ( enemies[i].run == SDL_FALSE) {
            float distance = CheckDistance(  enemies[i].point.x,
                                        enemies[i].point.y,
                                        player.point.x,
                                        player.point.y
                                        );

            if ( distance < ENEMY_ACTIVE_DISTANCE) {
                enemies[i].run = SDL_TRUE;
            }
        }
        // runがTRUE:移動
        if (enemies[i].run) {
            enemies[i].point.x += enemies[i].vx;
        }

        // 壁衝突（左右）
        int bottomTile = (int)(enemies[i].point.y + H - 1) / TILE;
        int topTile    = (int)(enemies[i].point.y) / TILE;
        int leftTile   = (int)(enemies[i].point.x) / TILE;
        int rightTile  = (int)(enemies[i].point.x + W - 1) / TILE;

        if (enemies[i].vx > 0) {
            for (int ty = topTile; ty <= bottomTile; ty++) {
                if (mapData[ty][rightTile] != 0) {
                    enemies[i].point.x = rightTile * TILE - W;
                    enemies[i].vx = -2.0f;   // 反転後も速度を維持
                    break;
                }
            }
        }
        else if (enemies[i].vx < 0) {
            for (int ty = topTile; ty <= bottomTile; ty++) {
                if (mapData[ty][leftTile] != 0) {
                    enemies[i].point.x = leftTile * TILE + TILE;
                    enemies[i].vx = 2.0f;    // 反転後も速度を維持
                    break;
                }
            }
        }

        // 縦移動
        enemies[i].point.y += enemies[i].vy;

        leftTile   = (int)(enemies[i].point.x) / TILE;
        rightTile  = (int)(enemies[i].point.x + W - 1) / TILE;
        bottomTile = (int)(enemies[i].point.y + H - 1) / TILE;
        topTile    = (int)(enemies[i].point.y) / TILE;

        // 下衝突
        if (enemies[i].vy > 0) {
            for (int tx = leftTile; tx <= rightTile; tx++) {
                if (mapData[bottomTile][tx] != 0) {
                    enemies[i].point.y = bottomTile * TILE - H;
                    enemies[i].vy = 0;
                    break;
                }
            }
        }

        // 上衝突
        if (enemies[i].vy < 0) {
            for (int tx = leftTile; tx <= rightTile; tx++) {
                if (mapData[topTile][tx] != 0) {
                    enemies[i].point.y = topTile * TILE + TILE;
                    enemies[i].vy = 0;
                    break;
                }
            }
        }

        if (enemies[i].vx > 0) {
            enemies[i].direction = 2;   // 右向き
        }
        else if (enemies[i].vx < 0) {
            enemies[i].direction = 1;   // 左向き
        }

        if (enemies[i].vx != 0) {
            enemies[i].animTimer += 1;
            if (enemies[i].animTimer > 12) {
                enemies[i].animFrame = (enemies[i].animFrame + 1) % 3;
                enemies[i].animTimer = 0;
            }
        } else {
            enemies[i].animFrame = 0;
        }
    }
}



void CheckHitEnemy(void)
{
    const int W = 32;
    const int H = 32;

    int px1 = (int)player.point.x;
    int py1 = (int)player.point.y;
    int px2 = px1 + W;
    int py2 = py1 + H;

    for (int i = 0; i < enemyCount; i++) {

        int ex1 = (int)enemies[i].point.x;
        int ey1 = (int)enemies[i].point.y;
        int ex2 = ex1 + W;
        int ey2 = ey1 + H;

        if (px1 < ex2 &&
            px2 > ex1 &&
            py1 < ey2 &&
            py2 > ey1)
        {
            if (player.invincibleTime == 0) {   //無敵中はダメージ無効
                player.hp -= 10;
                damageFlash = 5;
                player.invincibleTime = 30;     // 1秒くらい無敵（60fps前提）
            }

            enemies[i] = enemies[enemyCount - 1];
            enemyCount--;

            // i番目に新しい敵が入ったので、同じiをもう一度チェックする
            i--;
        }
    }
}


void CheckEnemyCollision(void)
{
    const int W = 32;
    const int H = 32;

    for (int i = 0; i < enemyCount; i++) {
        int ax1 = (int)enemies[i].point.x;
        int ay1 = (int)enemies[i].point.y;
        int ax2 = ax1 + W;
        int ay2 = ay1 + H;

        for (int j = i + 1; j < enemyCount; j++) {
            int bx1 = (int)enemies[j].point.x;
            int by1 = (int)enemies[j].point.y;
            int bx2 = bx1 + W;
            int by2 = by1 + H;

            // 判定（敵同士）
            if (ax1 < bx2 &&
                ax2 > bx1 &&
                ay1 < by2 &&
                ay2 > by1)
            {
                //速度反転
                enemies[i].vx = -enemies[i].vx;
                enemies[j].vx = -enemies[j].vx;
            }
        }
    }
}

void TrapDamege(void)
{
    if (player.invincibleTime == 0) {   // 無敵中はダメージ無効
        player.hp -= Trapdamege;
        damageFlash = 5;
        player.invincibleTime = 30;
    }
}

void UpdateCamera(void)
{
    gGame.cameraX = player.point.x + 16 - WD_WIDTH / 2;
    //gGame.cameraY = player.point.y + 16 - (WD_HEIGHT * 3 / 4 );
    gGame.cameraY = player.point.y + 16 - (WD_HEIGHT * 1 / 2 );

    if (gGame.cameraX < 0)
        gGame.cameraX = 0;

    if (gGame.cameraY < 0)
        gGame.cameraY = 0;

    float maxX = MAP_W * TILE_SIZE - WD_WIDTH;
    float maxY = MAP_H * TILE_SIZE - WD_HEIGHT;

    if (gGame.cameraX > maxX)
        gGame.cameraX = maxX;

    if (gGame.cameraY > maxY)
        gGame.cameraY = maxY;
}


SDL_bool InputEvent(void)
{
    SDL_Event event;
    while (SDL_PollEvent(&event)) {
        switch (event.type) {
        case SDL_QUIT:
            // 終了指示 
            return SDL_FALSE;
        case SDL_KEYDOWN:
            // キーリピートは無視
            if (event.key.repeat)
                break;
            // キーが押された方向を設定 
            switch (event.key.keysym.sym) {
            case SDLK_ESCAPE:
                // 終了指示 
                return SDL_FALSE;
            case SDLK_UP:
                gGame.input.gravityup    = SDL_TRUE;
                gGame.input.gravitydown  = SDL_FALSE;
                gGame.input.gravityright = SDL_FALSE;
                gGame.input.gravityleft  = SDL_FALSE;
                ChangeGravity();
                break;
            case SDLK_DOWN:
                gGame.input.gravityup    = SDL_FALSE;
                gGame.input.gravitydown  = SDL_TRUE;
                gGame.input.gravityright = SDL_FALSE;
                gGame.input.gravityleft  = SDL_FALSE;
                ChangeGravity();
                break;
            case SDLK_RIGHT:
                gGame.input.gravityup    = SDL_FALSE;
                gGame.input.gravitydown  = SDL_FALSE;
                gGame.input.gravityright = SDL_TRUE;
                gGame.input.gravityleft  = SDL_FALSE;
                ChangeGravity();
                break;
            case SDLK_LEFT:
                gGame.input.gravityup    = SDL_FALSE;
                gGame.input.gravitydown  = SDL_FALSE;
                gGame.input.gravityright = SDL_FALSE;
                gGame.input.gravityleft  = SDL_TRUE;
                ChangeGravity();
                break;
            case SDLK_d:
                gGame.input.right = SDL_TRUE;
                break;
            case SDLK_a:
                gGame.input.left = SDL_TRUE;
                break;
            case SDLK_w:
                gGame.input.up = SDL_TRUE;
                break;
            case SDLK_s:
                gGame.input.down = SDL_TRUE;
                break;
            case SDLK_SPACE:
                gGame.input.jump = SDL_TRUE;
                break;
            case SDLK_TAB:
                gGame.gamescene = GS_STAGESELECT;
            default:
                break;
            }
            break;
        case SDL_KEYUP:
            if (event.key.repeat)
                break;
            // 離されたときは解除 
            switch (event.key.keysym.sym) {
            case SDLK_d:
                gGame.input.right = SDL_FALSE;
                break;
            case SDLK_a:
                gGame.input.left = SDL_FALSE;
                break;
            default:
                break;
            }
        default:
            break;
        }
    }
    if (joyconEnabled) {
    btn         = gJC.button;
    joycon_get_state(&gJC);

    if(gJC.button.btn.Home) {
            // 終了指示 
        return SDL_FALSE;
    }

    if (gGame.gamescene == GS_TITLE ||
        gGame.gamescene == GS_STAGESELECT ||
        gGame.gamescene == GS_CLEAR ||
        gGame.gamescene == GS_GAMEOVER) {
            if (btn.btn.X != gJC.button.btn.X) {
                if (gJC.button.btn.X) {
                    gGame.input.jump = SDL_TRUE;
                }
            }
            if (btn.btn.A != gJC.button.btn.A) {
                if (gJC.button.btn.A) {
                    gGame.input.right = SDL_TRUE;
                }
            }
            else if (btn.btn.Y != gJC.button.btn.Y) {
                if (gJC.button.btn.Y) {
                    gGame.input.left = SDL_TRUE;
                }
            }
        }
    
    if (gGame.gamescene == GS_PLAYING) {
        if (gJC.button.btn.Y) {
                    gGame.input.gravityup    = SDL_TRUE;
                    gGame.input.gravitydown  = SDL_FALSE;
                    gGame.input.gravityright = SDL_FALSE;
                    gGame.input.gravityleft  = SDL_FALSE;
                    ChangeGravity();
        }
        else if (gJC.button.btn.A) {
                    gGame.input.gravityup    = SDL_FALSE;
                    gGame.input.gravitydown  = SDL_TRUE;
                    gGame.input.gravityright = SDL_FALSE;
                    gGame.input.gravityleft  = SDL_FALSE;
                    ChangeGravity();
        }
        else if (gJC.button.btn.X) {
                    gGame.input.gravityup    = SDL_FALSE;
                    gGame.input.gravitydown  = SDL_FALSE;
                    gGame.input.gravityright = SDL_TRUE;
                    gGame.input.gravityleft  = SDL_FALSE;
                    ChangeGravity();
        }
        else if (gJC.button.btn.B) {
                    gGame.input.gravityup    = SDL_FALSE;
                    gGame.input.gravitydown  = SDL_FALSE;
                    gGame.input.gravityright = SDL_FALSE;
                    gGame.input.gravityleft  = SDL_TRUE;
                    ChangeGravity();
        }   
        if (gJC.stick.y < -0.2) {
            gGame.input.right = SDL_TRUE;
        }
        else {
            gGame.input.right = SDL_FALSE;
        }
        if (gJC.stick.y > 0.2) {
                    gGame.input.left = SDL_TRUE;
        } 
        else {
            gGame.input.left = SDL_FALSE;
        }
        if (btn.btn.SR_r != gJC.button.btn.SR_r) {
                if (gJC.button.btn.SR_r) {
                    gGame.input.jump = SDL_TRUE;
            }
        }
        if (btn.btn.SR_l != gJC.button.btn.SR_l) {
                if (gJC.button.btn.SR_l) {
                    gGame.gamescene = GS_STAGESELECT;
            }
        }
    }
    }   
    return SDL_TRUE;   
}
