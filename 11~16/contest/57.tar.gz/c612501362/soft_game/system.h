/*
system.h
ヘッダファイル
*/

#pragma once

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>

//マップサイズ

//ウィンドウサイズ
//#define WD_WIDTH 720
//#define WD_HEIGHT 360

#define WD_WIDTH 720
#define WD_HEIGHT 540
//マップサイズ
#define TILE_SIZE 32

#define MAP_W 100
#define MAP_H 20

#define Wall    1
#define Gall    2
#define Trap    3
#define Enemy   4

extern int mapData[MAP_H][MAP_W];
extern int mapData_stage1[MAP_H][MAP_W];
extern int mapData_stage2[MAP_H][MAP_W];
extern int mapData_stage3[MAP_H][MAP_W];
extern int mapData_stage4[MAP_H][MAP_W];
extern int mapData_stage5[MAP_H][MAP_W];

//定義
#define ENEMY_ACTIVE_DISTANCE 850

//キャラクタータイプ
typedef enum {
    CT_Player   = 0,
    CT_Enemy1    = 1,
    CT_Enemy2     = 2,
    CT_Wall     = 3,
} CharaType;
#define CHARATYPE_NUM 4

typedef enum {
    STAGE1 = 1,
    STAGE2 = 2,
    STAGE3 = 3,
    STAGE4 = 4,
    STAGE5 = 5
} StageNum;

//重力方向のタイプ
typedef enum {
    GRAVITY_Down    = 0,
    GRAVITY_Right   = 1,
    GRAVITY_Up      = 2,
    GRAVITY_Left    = 3,
} GravityDir;

//キャラクタータイプ別情報
typedef struct {
    int w;
    int h;
    SDL_Rect baserect;
    char* path;
} CharatypeInfo;

//キャラクター情報
typedef struct {
    CharaType type;
    int hp;
    int MAX_Hp;
    int invincibleTime;
    int fallTime;
    GravityDir gravity;
    float vx, vy;
    float ax, ay;
    SDL_FPoint point;
    SDL_bool isGround;
    SDL_bool run;

    int animFrame;
    float animTimer;
    int direction;
} CharaInfo_t;

typedef struct {
    SDL_bool right;
    SDL_bool left;
    SDL_bool up;
    SDL_bool down;

    SDL_bool jump;
    
    SDL_bool gravityup;
    SDL_bool gravitydown;
    SDL_bool gravityright;
    SDL_bool gravityleft;
} KeyStts;

typedef enum {
    GS_TITLE        = 0,
    GS_STAGESELECT  = 1,
    GS_PLAYING      = 2,
    GS_GAMEOVER     = 3,
    GS_CLEAR        = 4
} GameStts;

//ゲームの情報
typedef struct {
    KeyStts input;
    GameStts gamescene;
    float timeDelta;
    SDL_Window* window;
    SDL_Renderer* render;

    StageNum stageNum;
    SDL_bool isRunning;

    float cameraX;
    float cameraY;

    float gravityCooldown;  //重力変更可能までの残り時間
} GameInfo;

extern GameInfo gGame;
extern CharaInfo_t player;

int InitWindow(void);
void DestroyWindow(void);
SDL_bool InputEvent(void);
void UpdateGame(void);
void UpdateTitle(void);
void InitPlayer(void);
void RenderWindow(void);
int PrintError(const char* msg);
void DestroySystem(void);
void ChangeGravity(void);
SDL_bool IsGravityBlock(int tile);
void PlayerDirection(void);

#define ENEMY_MAX 50
extern CharaInfo_t enemies[ENEMY_MAX];
extern int enemyCount;
void InitEnemies(void);
float CheckDistance(float x1, float y1, float x2, float y2);
void UpdateEnemies(void);
void UpdatePlayer(void);
void UpdateGameOver(void);
void UpdateClear(void);
void CheckOutOfMap(void);
void CheckHitEnemy(void);
void CheckEnemyCollision(void);
void TrapDamege();

extern int damageFlash;

extern SDL_Texture* playerTex;
extern SDL_Texture* enemyTex1;
extern SDL_Texture* enemyTex2;
extern TTF_Font* font;

void DrawText(const char* msg, int x, int y, SDL_Color color);
void DrawGame(void);
void DrawTitle(void);
void DrawSelect(void);
void DrawClear(void);
void DrawGameOver(void);
void DrawClear(void);
void DrawPlayer(void);
void DrawEnemies(void);
void DrawGravityPanel(void);
void DrawArrowUp(int x, int y);
void DrawArrowDown(int x, int y);
void DrawArrowLeft(int x, int y);
void DrawArrowRight(int x, int y);
void DrawHpBar(void);

void UpdateSelect(void);
void UpdateCamera(void);