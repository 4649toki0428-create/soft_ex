/*
window.c
*/

#include "system.h"
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <math.h>
#include <stdio.h>

static char gFontFile[] = "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf";
TTF_Font* font = NULL;

SDL_Rect panel;

void DrawGravityArrow(void);
void DrawGravityPanel(void);

int InitWindow(void) 
{
    if (TTF_Init() < 0) {
        return PrintError("failed to initialize SDL_ttf");
    }
    
    font = TTF_OpenFont(gFontFile, 32);
    if (!font) {
        return PrintError("failed to load font");
    }

    /* SDL_image初期化 */
    if (IMG_INIT_PNG != IMG_Init(IMG_INIT_PNG)) {
        return PrintError("failed to initialize SDL_image");
    }

    // プレイヤー画像の読み込み（InitWindow内）
    SDL_Surface* ps = IMG_Load("player.png");
    if (ps == NULL) {
        return PrintError("failed to open player.png");
    }
    SDL_Surface* es1 = IMG_Load("enemy1.png");
    if (!es1) {
        return PrintError("failed to open enemy_red.png");
    }

    SDL_Surface* es2 = IMG_Load("enemy2.png");
    if (!es2) {
        return PrintError("failed to open enemy_blue.png");
    }

    /** メインのウインドウ(表示画面)とレンダラーの作成 **/
    gGame.window = SDL_CreateWindow("Gravity Shift Runner", 80, 50, WD_WIDTH, WD_HEIGHT, 0);
    if (gGame.window == NULL)
        return PrintError(SDL_GetError());

    gGame.render = SDL_CreateRenderer(gGame.window, -1, 0);
    if (gGame.render == NULL)
        return PrintError(SDL_GetError()); 
    
    RenderWindow();

    playerTex = SDL_CreateTextureFromSurface(gGame.render, ps);
    SDL_FreeSurface(ps);
    if (playerTex == NULL) {
        return PrintError(SDL_GetError());
    }

    enemyTex1 = SDL_CreateTextureFromSurface(gGame.render, es1);
    SDL_FreeSurface(es1);
    if (!enemyTex1) {
        return PrintError(SDL_GetError());
    }

    enemyTex2 = SDL_CreateTextureFromSurface(gGame.render, es2);
    SDL_FreeSurface(es2);
    if (!enemyTex2) {
        return PrintError(SDL_GetError());
    }

    return 0;
}

void DrawText(const char* msg, int cx, int cy, SDL_Color color)
{
    SDL_Surface* surf = TTF_RenderUTF8_Blended(font, msg, color);
    SDL_Texture* tex = SDL_CreateTextureFromSurface(gGame.render, surf);

    SDL_Rect rect = {
        cx - surf->w / 2,
        cy - surf->h / 2,
        surf->w,
        surf->h
    };

    SDL_RenderCopy(gGame.render, tex, NULL, &rect);

    SDL_FreeSurface(surf);
    SDL_DestroyTexture(tex);
}

void DrawTitle(void)
{
    SDL_SetRenderDrawColor(gGame.render, 0, 0, 0, 255);
    SDL_RenderClear(gGame.render);

    SDL_Color white = {255, 255, 255};

    int cx = WD_WIDTH / 2;
    int cy = WD_HEIGHT / 3;

    DrawText("Gravity Shift Runner", cx, cy, white);
    DrawText("Press X or Space to Start", cx, cy + WD_HEIGHT / 6, white);

    SDL_RenderPresent(gGame.render);
}

void DrawSelect(void)
{
    SDL_SetRenderDrawColor(gGame.render, 20, 20, 20, 255);
    SDL_RenderClear(gGame.render);

    SDL_Color white = {255, 255, 255};
    SDL_Color yellow = {255, 255, 100};

    int cx = WD_WIDTH / 2;
    int cy = WD_HEIGHT / 4;

    DrawText("STAGE SELECT", cx, cy, white);

    // 選択中のステージをハイライト
    SDL_Color c1 = (gGame.stageNum == 1 ? yellow : white);
    SDL_Color c2 = (gGame.stageNum == 2 ? yellow : white);
    SDL_Color c3 = (gGame.stageNum == 3 ? yellow : white);
    SDL_Color c4 = (gGame.stageNum == 4 ? yellow : white);
    SDL_Color c5 = (gGame.stageNum == 5 ? yellow : white);

    int baseY = cy + WD_HEIGHT / 6;

    DrawText("1 : Tutorial",         cx, baseY + 0,   c1);
    DrawText("2 : Normal Stage",     cx, baseY + 40,  c2);
    DrawText("3 : Gravity Maze",       cx, baseY + 80,  c3);
    DrawText("4 : Avoid Enemies",    cx, baseY + 120, c4);
    DrawText("5 : Extra Stage",  cx, baseY + 160, c5);

    DrawText("Press X or Space to Start", cx, WD_HEIGHT * 4 / 5, white);

    SDL_RenderPresent(gGame.render);
}

void DrawGame(void)
{
    SDL_SetRenderDrawColor(gGame.render, 0, 0, 0, 255);
    SDL_RenderClear(gGame.render);

    // タイルサイズ
    const int TILE = 32;

    // マップ描画

    /* カメラから見えている範囲を計算 */
    int startX = (int)(gGame.cameraX / TILE);
    int endX   = startX + (WD_WIDTH / TILE) + 2;

    int startY = (int)(gGame.cameraY / TILE);
    int endY   = startY + (WD_HEIGHT / TILE) + 2;

    /* 範囲チェック */
    if (startX < 0) startX = 0;
    if (startY < 0) startY = 0;

    if (endX > MAP_W) endX = MAP_W;
    if (endY > MAP_H) endY = MAP_H;

    /* マップ描画 */
    for (int y = startY; y < endY; y++) {
        for (int x = startX; x < endX; x++) {

            SDL_Rect rect = {
                x * TILE - (int)gGame.cameraX,
                y * TILE - (int)gGame.cameraY,
                TILE,
                TILE
            };

            switch (mapData[y][x]) {

                case 1:     // 壁
                    SDL_SetRenderDrawColor(gGame.render, 100, 100, 100, 255);
                    SDL_RenderFillRect(gGame.render, &rect);
                    break;

                case 2:     // ゴール
                    SDL_SetRenderDrawColor(gGame.render, 100, 200, 200, 255);
                    SDL_RenderFillRect(gGame.render, &rect);
                    break;

                case 3:     // トラップ
                    SDL_SetRenderDrawColor(gGame.render, 100, 255, 100, 255);
                    SDL_RenderFillRect(gGame.render, &rect);
                    break;

                case 5:     // 上重力のみ通過可能
                    SDL_SetRenderDrawColor(gGame.render,180, 80, 255, 255);
                    SDL_RenderFillRect(gGame.render, &rect);
                    
                    // 上向き矢印表示
                    SDL_SetRenderDrawColor(gGame.render,255,255,255,255);

                    SDL_RenderDrawLine(
                        gGame.render,
                        rect.x + 16,
                        rect.y + 8,
                        rect.x + 16,
                        rect.y + 24
                    );

                    SDL_RenderDrawLine(
                        gGame.render,
                        rect.x + 16,
                        rect.y + 8,
                        rect.x + 10,
                        rect.y + 15
                    );

                    SDL_RenderDrawLine(
                        gGame.render,
                        rect.x + 16,
                        rect.y + 8,
                        rect.x + 22,
                        rect.y + 15
                    );
                    
                    break;


                case 6:     // 下重力のみ通過可能
                    SDL_SetRenderDrawColor(gGame.render,255,150,50,255);
                    SDL_RenderFillRect(gGame.render,&rect);

                    
                    SDL_SetRenderDrawColor(gGame.render,255,255,255,255);

                    SDL_RenderDrawLine(
                        gGame.render,
                        rect.x + 16,
                        rect.y + 24,
                        rect.x + 16,
                        rect.y + 8
                    );

                    SDL_RenderDrawLine(
                        gGame.render,
                        rect.x + 16,
                        rect.y + 24,
                        rect.x + 10,
                        rect.y + 17
                    );

                    SDL_RenderDrawLine(
                        gGame.render,
                        rect.x + 16,
                        rect.y + 24,
                        rect.x + 22,
                        rect.y + 17
                    );
                    
                    break;


                case 7:     // 左重力のみ通過可能
                    SDL_SetRenderDrawColor(gGame.render,50,150,255,255);
                    SDL_RenderFillRect(gGame.render,&rect);

                
                    SDL_SetRenderDrawColor(gGame.render,255,255,255,255);

                    SDL_RenderDrawLine(
                        gGame.render,
                        rect.x + 8,
                        rect.y + 16,
                        rect.x + 24,
                        rect.y + 16
                    );

                    SDL_RenderDrawLine(
                        gGame.render,
                        rect.x + 8,
                        rect.y + 16,
                        rect.x + 15,
                        rect.y + 10
                    );

                    SDL_RenderDrawLine(
                        gGame.render,
                        rect.x + 8,
                        rect.y + 16,
                        rect.x + 15,
                        rect.y + 22
                    );
                    
                    break;


                case 8:     // 右重力のみ通過可能
                    SDL_SetRenderDrawColor(gGame.render,255,220,50,255);
                    SDL_RenderFillRect(gGame.render,&rect);


                    SDL_SetRenderDrawColor(gGame.render,255,255,255,255);

                    SDL_RenderDrawLine(
                        gGame.render,
                        rect.x + 24,
                        rect.y + 16,
                        rect.x + 8,
                        rect.y + 16
                    );

                    SDL_RenderDrawLine(
                        gGame.render,
                        rect.x + 24,
                        rect.y + 16,
                        rect.x + 17,
                        rect.y + 10
                    );

                    SDL_RenderDrawLine(
                        gGame.render,
                        rect.x + 24,
                        rect.y + 16,
                        rect.x + 17,
                        rect.y + 22
                    );

                    break;

                default:
                    break;
                }
            }
    }

    if ((player.invincibleTime > 0 && (player.invincibleTime / 5) % 2 == 0) == 0) {
        DrawPlayer();
    }

    DrawEnemies();

    //ダメージエフェクト
    if (damageFlash > 0) {
        SDL_SetRenderDrawBlendMode(gGame.render, SDL_BLENDMODE_BLEND);
        SDL_SetRenderDrawColor(gGame.render, 255, 0, 0, 120); // 半透明の赤
        SDL_Rect r = {0, 0, WD_WIDTH, WD_HEIGHT};
        SDL_RenderFillRect(gGame.render, &r);

        damageFlash--;
    }

    DrawHpBar();
    DrawGravityPanel();
    DrawGravityArrow();

    SDL_RenderPresent(gGame.render);
}

void DrawGameOver(void)
{
    SDL_SetRenderDrawColor(gGame.render, 0, 0, 0, 100);

    SDL_Color red = {255, 50, 50};
    SDL_Color white = {255, 255, 255};

    int cx = WD_WIDTH / 2;
    int cy = WD_HEIGHT / 3;

    DrawText("GAME OVER", cx, cy, red);
    DrawText("Press X or Space to return to Title", cx, cy + WD_HEIGHT / 6, white);

    SDL_RenderPresent(gGame.render);
}

void DrawClear(void)
{
    SDL_SetRenderDrawColor(gGame.render, 0, 0, 0, 255);
    SDL_RenderClear(gGame.render);

    SDL_Color cyan = {100, 255, 255};
    SDL_Color white = {255, 255, 255};

    int cx = WD_WIDTH / 2;
    int cy = WD_HEIGHT / 3;

    DrawText("STAGE CLEAR!", cx, cy, cyan);
    DrawText("Press X or Space to return to Title", cx, cy + WD_HEIGHT / 6, white);

    SDL_RenderPresent(gGame.render);
}

void RenderWindow(void)
{
    // とりあえず
}

void DrawPlayer(void)
{
    if (!playerTex) return;

    SDL_Rect src;
    src.w = 32;
    src.h = 32;

    // 左右移動アニメ（2行目＝左、3行目＝右）
    src.x = player.animFrame * 32;      // 横方向のフレーム
    src.y = player.direction * 32;      // 縦方向の行（左右アニメ）

    SDL_Rect dst;
    dst.x = (int)(player.point.x - gGame.cameraX);
    dst.y = (int)(player.point.y - gGame.cameraY);
    dst.w = 32;
    dst.h = 32;

    // 重力方向に応じた回転
    double angle = 0.0;
    switch (player.gravity) {
        case GRAVITY_Down:  angle = 0; break;
        case GRAVITY_Right: angle = 270; break;
        case GRAVITY_Up:    angle = 180; break;
        case GRAVITY_Left:  angle = 90; break;
    }

    SDL_RenderCopyEx(gGame.render, playerTex, &src, &dst, angle, NULL, SDL_FLIP_NONE);
}

void DrawEnemies(void)
{
    for (int i = 0; i < enemyCount; i++) {

        SDL_Texture* tex;
        SDL_RendererFlip flip = SDL_FLIP_NONE;

        if (enemies[i].type == CT_Enemy1) {
            tex = enemyTex1;   // 赤
        } else {
            tex = enemyTex2;   // 青

            // Enemy2 は重力方向が Up のとき上下反転
            if (player.gravity == GRAVITY_Up) {
                flip = SDL_FLIP_VERTICAL;
            }
        }

        SDL_Rect src = {
            enemies[i].animFrame * 32,     // 横方向（アニメ）
            enemies[i].direction * 32,     // 縦方向（左=1, 右=2）
            32, 32
        };

        SDL_Rect dst = {
            (int)(enemies[i].point.x - gGame.cameraX),
            (int)(enemies[i].point.y - gGame.cameraY),
            32, 32
        };

        SDL_RenderCopyEx(gGame.render, tex, &src, &dst, 0, NULL, flip);
    }
}


void DrawGravityPanel(void)
{
    SDL_Rect panel = { 5, 5, 64, 64 };

    SDL_SetRenderDrawBlendMode(gGame.render, SDL_BLENDMODE_BLEND);
    //SDL_SetRenderDrawColor(gGame.render, 0, 0, 0, 150);  // 半透明黒
    // クールタイムが満タンなら明るくする
    if (gGame.gravityCooldown <= 0.0f) {
        SDL_SetRenderDrawColor(gGame.render, 80, 80, 80, 200);  // 明るい灰色
    } else {
        SDL_SetRenderDrawColor(gGame.render, 0, 0, 0, 150);     // 通常の暗いパネル
    }
    SDL_RenderFillRect(gGame.render, &panel);

    SDL_SetRenderDrawColor(gGame.render, 255, 255, 255, 200); // 白枠
    SDL_RenderDrawRect(gGame.render, &panel);

     // クールタイムゲージ（重力変更の再使用までの時間）
     if (gGame.gravityCooldown > 0) {

        float maxCooldown = 1.5f;  // ChangeGravity() で設定している最大値
        float rate = gGame.gravityCooldown / maxCooldown;
        if (rate > 1.0f) rate = 1.0f;

        // ゲージの高さ（パネル内に収まるように）
        int gaugeHeight = (int)(rate * 64);

        SDL_Rect gauge = {
            panel.x + 4,
            panel.y + (64 - gaugeHeight),
            8,
            gaugeHeight
        };

        SDL_SetRenderDrawColor(gGame.render, 0, 200, 255, 255); // 水色ゲージ
        SDL_RenderFillRect(gGame.render, &gauge);
    }
}

void DrawArrowUp(int x, int y)
{
    int cx = x + 32;
    int cy = y + 32;

    SDL_SetRenderDrawColor(gGame.render, 255, 255, 255, 255);

    // 三角形
    SDL_RenderDrawLine(gGame.render, cx,     cy-12, cx-8,  cy+4);
    SDL_RenderDrawLine(gGame.render, cx,     cy-12, cx+8,  cy+4);
    SDL_RenderDrawLine(gGame.render, cx-8,   cy+4,  cx+8,  cy+4);

    // 棒
    SDL_RenderDrawLine(gGame.render, cx, cy+4, cx, cy+20);
}

void DrawArrowDown(int x, int y)
{
    int cx = x + 32;
    int cy = y + 32;

    SDL_SetRenderDrawColor(gGame.render, 255, 255, 255, 255);

    // 三角形
    SDL_RenderDrawLine(gGame.render, cx,     cy+12, cx-8,  cy-4);
    SDL_RenderDrawLine(gGame.render, cx,     cy+12, cx+8,  cy-4);
    SDL_RenderDrawLine(gGame.render, cx-8,   cy-4,  cx+8,  cy-4);

    // 棒
    SDL_RenderDrawLine(gGame.render, cx, cy-4, cx, cy-20);
}

void DrawArrowLeft(int x, int y)
{
    int cx = x + 32;
    int cy = y + 32;

    SDL_SetRenderDrawColor(gGame.render, 255, 255, 255, 255);

    // 三角形
    SDL_RenderDrawLine(gGame.render, cx-12, cy,    cx+4,  cy-8);
    SDL_RenderDrawLine(gGame.render, cx-12, cy,    cx+4,  cy+8);
    SDL_RenderDrawLine(gGame.render, cx+4,  cy-8,  cx+4,  cy+8);

    // 棒
    SDL_RenderDrawLine(gGame.render, cx+4, cy, cx+20, cy);
}

void DrawArrowRight(int x, int y)
{
    int cx = x + 32;
    int cy = y + 32;

    SDL_SetRenderDrawColor(gGame.render, 255, 255, 255, 255);

    // 三角形
    SDL_RenderDrawLine(gGame.render, cx+12, cy,    cx-4,  cy-8);
    SDL_RenderDrawLine(gGame.render, cx+12, cy,    cx-4,  cy+8);
    SDL_RenderDrawLine(gGame.render, cx-4,  cy-8,  cx-4,  cy+8);

    // 棒
    SDL_RenderDrawLine(gGame.render, cx-4, cy, cx-20, cy);
}

void DrawGravityArrow(void)
{
    int x = 5;
    int y = 5;

    switch (player.gravity) {
        case GRAVITY_Up:    DrawArrowUp(x, y);    break;
        case GRAVITY_Down:  DrawArrowDown(x, y);  break;
        case GRAVITY_Left:  DrawArrowLeft(x, y);  break;
        case GRAVITY_Right: DrawArrowRight(x, y); break;
    }
}

void DrawHpBar(void)
{
    int h = 10;
    int x = WD_WIDTH * 0.01;
    int y = WD_HEIGHT * 0.95;
    int w = WD_WIDTH * 0.15;   // 画面幅の15%

    SDL_Rect back = { x, y, w, h };
    SDL_SetRenderDrawBlendMode(gGame.render, SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(gGame.render, 0, 0, 0, 180);
    SDL_RenderFillRect(gGame.render, &back);

    // 枠線（白）
    SDL_SetRenderDrawColor(gGame.render, 255, 255, 255, 255);
    SDL_RenderDrawRect(gGame.render, &back);

    // 現在HPの割合
    float rate = (float)player.hp / (float)player.MAX_Hp;
    if (rate < 0) rate = 0;

    SDL_Rect bar = { x+1, y+1, (int)((w-2) * rate), h-2 };

    // 割合に応じて色を変える
    if (rate <= 0.25f) {
        SDL_SetRenderDrawColor(gGame.render, 255, 0, 0, 255);      // 赤
    } else if (rate <= 0.50f) {
        SDL_SetRenderDrawColor(gGame.render, 255, 255, 0, 255);    // 黄
    } else {
        SDL_SetRenderDrawColor(gGame.render, 0, 255, 0, 255);      // 緑
    }

    SDL_RenderFillRect(gGame.render, &bar);
}

void DestroyWindow(void)
{
    SDL_DestroyTexture(playerTex);
    playerTex = NULL;
    TTF_CloseFont(font);
    font = NULL;

    IMG_Quit();
    TTF_Quit();

    SDL_DestroyRenderer(gGame.render);
    SDL_DestroyWindow(gGame.window);
}
