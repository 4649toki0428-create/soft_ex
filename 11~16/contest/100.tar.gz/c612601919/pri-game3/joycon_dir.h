#ifndef JOYCON_DIR_H
#define JOYCON_DIR_H

#include "joyconlib.h"
#include "snake.h"

// Returns a Direction based on Joy‑Con button state and current stage.
// Returns -1 if no directional button is pressed.
int joycon_get_direction(int stage);

#endif // JOYCON_DIR_H
