// Updated map handling for multiple stages
#include "map.h"

#define TILE_SIZE  60
#define MAP_WIDTH  17
#define MAP_HEIGHT 13

/*
 * Tile definitions:
 * 0: floor (walkable)
 * 1: wall (impassable)
 * 2: special tile (e.g., monster room entrance)
 */

// Stage 1 map (original map)
static const int stage1_map[MAP_HEIGHT][MAP_WIDTH] = {
    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
    {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {1,0,0,1,1,0,0,1,1,0,0,0,1,1,0,0,1},
    {1,0,0,0,0,0,0,1,1,0,0,0,1,1,0,0,1},
    {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {1,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0,1},
    {3,0,0,0,0,0,1,1,1,0,1,1,0,1,0,0,2},
    {1,0,0,0,0,0,0,1,0,0,1,1,0,0,0,0,1},
    {1,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,1},
    {1,0,0,1,1,0,0,0,0,0,0,1,1,0,0,0,1},
    {1,0,0,1,1,0,0,1,1,0,0,1,1,0,0,0,1},
    {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
};

// Stage 2 map
static const int stage2_map[MAP_HEIGHT][MAP_WIDTH] = {
    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
    {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {1,0,1,0,0,1,0,1,0,1,1,0,1,0,0,1,1},
    {1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1},
    {1,0,1,0,1,0,0,0,1,0,1,0,0,0,1,0,1},
    {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {3,0,0,0,0,0,1,1,1,0,1,1,0,1,0,0,2},
    {1,0,1,1,0,0,1,1,1,0,1,0,0,0,0,0,1},
    {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {1,0,1,0,0,0,1,1,1,1,0,0,1,0,0,0,1},
    {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
};

// Stage 3 map
static const int stage3_map[MAP_HEIGHT][MAP_WIDTH] = {
    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
    {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {1,0,0,1,1,0,1,1,0,1,1,0,1,1,0,4,1},
    {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {1,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,1},
    {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {3,0,0,1,1,0,1,1,1,0,1,1,1,0,1,0,2},
    {1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1},
    {1,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,1},
    {1,0,1,5,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {1,0,1,1,1,0,1,1,0,1,1,0,1,1,0,0,1},
    {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
};

// Start and goal positions for each stage
static const int stage_start_pos[3][2] = {
    {16, 6}, // Stage 1 start (tile 2)
    {16, 6}, // Stage 2 start
    {16, 6}  // Stage 3 start
};

static const int stage_goal_pos[3][2] = {
    {0, 6}, // Stage 1 goal (tile 3)
    {0, 6}, // Stage 2 goal
    {0, 6}  // Stage 3 goal
};

// Retrieve map for the given stage number (1-3). Defaults to stage 1.
const int (*get_stage_map(int stage))[MAP_WIDTH] {
    switch (stage) {
        case 1: return stage1_map;
        case 2: return stage2_map;
        case 3: return stage3_map;
        default: return stage1_map;
    }
}

// Retrieve start position (tile coordinates) for a given stage (1-3)
void get_stage_start(int stage, int *out_x, int *out_y) {
    if (stage < 1 || stage > 3) stage = 1;
    *out_x = stage_start_pos[stage-1][0];
    *out_y = stage_start_pos[stage-1][1];
}

void get_stage_goal(int stage, int *out_x, int *out_y) {
    if (stage < 1 || stage > 3) stage = 1;
    *out_x = stage_goal_pos[stage-1][0];
    *out_y = stage_goal_pos[stage-1][1];
}

// Enemy start positions for each stage (up to 3 enemies)
static const int stage_enemy_start[3][3][2] = {
    // Stage 1 enemy positions (x, y)
    { {1,1}, {15,11}, {0,0} },
    // Stage 2 enemy positions (reuse same as stage 1 for first two, add third)
    { {1,1}, {15,11}, {8,6} },
    // Stage 3 enemy positions (three enemies)
    { {1,1}, {15,11}, {8,6} }
};

// Retrieve enemy start position for a given stage and index (0‑based)
void get_stage_enemy_start(int stage, int idx, int *out_x, int *out_y) {
    if (stage < 1 || stage > 3) stage = 1;
    if (idx < 0) idx = 0;
    if (idx > 2) idx = 2;
    *out_x = stage_enemy_start[stage-1][idx][0];
    *out_y = stage_enemy_start[stage-1][idx][1];
}

// For compatibility with existing code that expects a global `map_data` symbol,
// we expose the stage-1 map as `map_data`.
const int (*map_data)[MAP_WIDTH] = stage1_map; // default map for compatibility