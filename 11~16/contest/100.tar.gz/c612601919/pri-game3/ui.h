#ifndef UI_H
#define UI_H

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <stdbool.h>

/* UI lifecycle */
void ui_init(void);
void ui_cleanup(void);

/* HUD and full-screen messages */
void ui_draw_game_hud(SDL_Renderer *renderer, TTF_Font *font, int life, int stamina, int max_stamina, int light_count, int stage, bool has_star, SDL_Texture *starTex);
void ui_draw_game_over(SDL_Renderer *renderer, TTF_Font *font);
void ui_draw_game_clear(SDL_Renderer *renderer, TTF_Font *font);

#endif // UI_H
