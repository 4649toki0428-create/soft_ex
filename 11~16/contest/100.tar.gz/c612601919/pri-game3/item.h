#ifndef ITEM_H
#define ITEM_H

#include <SDL2/SDL.h>
#include <stdbool.h>

#define MAP_WIDTH 17
#define MAP_HEIGHT 13

typedef enum {
    ITEM_APPLE,
    ITEM_LIGHT,
    ITEM_STAR
} ItemType;

typedef struct {
    int x; // pixel
    int y; // pixel
    bool active;
    ItemType type;
} Item;

void item_init(Item *item, ItemType type, const int map[MAP_HEIGHT][MAP_WIDTH]);
void item_reposition(Item *item, const int map[MAP_HEIGHT][MAP_WIDTH]);
void item_render(const Item *item, SDL_Renderer *renderer, SDL_Texture *texture);

#endif // ITEM_H
