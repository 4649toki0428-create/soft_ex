#include "item.h"
#include "snake.h"
#include <stdlib.h>

void item_init(Item *item, ItemType type, const int map[MAP_HEIGHT][MAP_WIDTH])
{
    item->type = type;
    item->active = true;
    item_reposition(item, map);
}

void item_reposition(Item *item, const int map[MAP_HEIGHT][MAP_WIDTH])
{
    int empty_tiles[MAP_WIDTH * MAP_HEIGHT][2];
    int count = 0;

    for (int y = 0; y < MAP_HEIGHT; y++) {
        for (int x = 0; x < MAP_WIDTH; x++) {
            if (map[y][x] == 0) {
                empty_tiles[count][0] = x;
                empty_tiles[count][1] = y;
                count++;
            }
        }
    }

    if (count > 0) {
        int idx = rand() % count;
        item->x = empty_tiles[idx][0] * TILE_SIZE;
        item->y = empty_tiles[idx][1] * TILE_SIZE;
        item->active = true;
    }
}

void item_render(const Item *item, SDL_Renderer *renderer, SDL_Texture *texture)
{
    if (!item->active || !texture) return;

    SDL_Rect dst = { item->x, item->y, TILE_SIZE, TILE_SIZE };
    SDL_RenderCopy(renderer, texture, NULL, &dst);
}
