#include "joycon_dir.h"
#include "joyconlib.h"
//#include <SDL2/SDL.h>
//#include <stdlib.h>

// Declare the Joy‑Con state variable defined in main.c
extern joyconlib_t jc;

int joycon_get_direction(int stage) {
    
    // Determine direction based on stage‑specific mapping
    if (jc.button.btn.X) {
        if (stage == 1) return DIR_UP;
        if (stage == 2) return DIR_DOWN;
        if (stage == 3) return DIR_DOWN;
        //return current_map[0]; // stage 3
    }
    if (jc.button.btn.A) {
        if (stage == 1) return DIR_RIGHT;
        if (stage == 2) return DIR_LEFT;
        if (stage == 3) return DIR_LEFT;
        //return current_map[1];
    }
    if (jc.button.btn.B) {
        if (stage == 1) return DIR_DOWN;
        if (stage == 2) return DIR_UP;
        if (stage == 3) return DIR_UP;
        //return current_map[2];
    }
    if (jc.button.btn.Y) {
        if (stage == 1) return DIR_LEFT;
        if (stage == 2) return DIR_RIGHT;
        if (stage == 3) return DIR_RIGHT;
        //return current_map[3];
    }
    return -1; // no directional button pressed
}
