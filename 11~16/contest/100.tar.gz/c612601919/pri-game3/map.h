#ifndef MAP_H
#define MAP_H

#include <stdio.h>

// Map dimensions (must match map.c definitions)
#define TILE_SIZE  60
#define MAP_WIDTH  17
#define MAP_HEIGHT 13

// Retrieve map data for a stage (1‑3). Returns pointer to 2D array.
const int (*get_stage_map(int stage))[MAP_WIDTH];

// Retrieve start tile (player spawn) for a stage.
void get_stage_start(int stage, int *out_x, int *out_y);

// Retrieve goal tile for a stage.
void get_stage_goal(int stage, int *out_x, int *out_y);

// Retrieve enemy start position for a stage and enemy index (0‑based).
void get_stage_enemy_start(int stage, int idx, int *out_x, int *out_y);

#endif // MAP_H
