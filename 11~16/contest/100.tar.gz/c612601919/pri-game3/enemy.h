#ifndef ENEMY_H
#define ENEMY_H

#include <SDL2/SDL.h>
#include <stdbool.h>
#include "snake.h" // Direction, TILE_SIZE などを流用

typedef enum {
    ENEMY_TRACKER,  // 最短経路追跡型 (BFS)
    ENEMY_PREDICT   // 先読み追跡型 (3マス先)
} EnemyType;

typedef struct {
    int x;
    int y;
    int prev_x; // previous tile x for collision checks
    int prev_y; // previous tile y for collision checks
    int frame;
    int moveTimer; // 最終移動時刻(ms)の管理
    EnemyType type;
    Direction dir;
} Enemy;

void enemy_init(Enemy *e, int gridX, int gridY, EnemyType type);
void enemy_update(Enemy *e, Uint32 now, const int map[13][17], const Snake *player);
void enemy_render(const Enemy *e, SDL_Renderer *renderer, SDL_Texture *tileset);

#endif // ENEMY_H
