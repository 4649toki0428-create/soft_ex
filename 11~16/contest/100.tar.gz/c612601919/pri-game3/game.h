#ifndef GAME_H
#define GAME_H

#include <SDL2/SDL.h>
#include <stdbool.h>
#include "snake.h"
#include "enemy.h"
#include "item.h"

typedef enum {
    STATE_TITLE,
    STATE_GUIDE,
    STATE_PLAYING,
    STATE_GAMEOVER,
    STATE_CLEAR
} GameState;

typedef struct {
    int life;
    int stamina;
    int max_stamina;
    int light_count;
    
    Uint32 invincibleTimer; // 無敵終了時刻(ms)
    GameState state;

    Item apple;
    Item light;

    Snake player;
    Enemy enemies[3];

    // ダッシュ用フラグとタイマー
    bool is_dashing;
    bool warp_cooldown; // prevents immediate re-warping

    int stage; // current stage (1-3)
    bool map_switched; // whether background image a->b switched
    bool goal_opened; // goal is open after collecting lights
    int goal_x; // goal tile x (in tiles)
    int goal_y; // goal tile y (in tiles)

    // スター関連
    Item star;
    bool has_star;
    bool is_star_invincible;
    Uint32 star_invincible_timer; // 無敵終了時刻(ms)
} GameContext;

// Input mapping for portability (e.g. Home button on Joy-Con)
#define KEY_HOME SDLK_r

void game_init(GameContext *ctx, const int map[MAP_HEIGHT][MAP_WIDTH]);
void game_restart(GameContext *ctx, const int map[MAP_HEIGHT][MAP_WIDTH]);
void get_stage_goal(int stage, int *out_x, int *out_y);
void game_update(GameContext *ctx, Uint32 now, const int map[MAP_HEIGHT][MAP_WIDTH]);
void game_handle_keydown(GameContext *ctx, SDL_Keycode key, const int map[MAP_HEIGHT][MAP_WIDTH]);
void game_handle_keyup(GameContext *ctx, SDL_Keycode key);

#endif // GAME_H
