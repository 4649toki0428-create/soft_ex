#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <stdbool.h>
#include <time.h>
#include "snake.h"
#include "enemy.h"
#include "item.h"
#include "ui.h"
#include <SDL2/SDL_ttf.h>
#include "game.h"
#include "map.h"
// Joy-Con library header
#include <joyconlib.h>
#include "joycon_dir.h"

// Global Joy‑Con state variable
joyconlib_t jc;

#define SCREEN_WIDTH 1020
#define SCREEN_HEIGHT 780

#define LOGICAL_WIDTH 1020
#define LOGICAL_HEIGHT 780

#define ANIM_INTERVAL 150

// Prototype for map retrieval function
extern const int (*get_stage_map(int stage))[MAP_WIDTH];

int main(int argc, char *argv[])
{
    (void)argc;
    (void)argv;

    srand((unsigned)time(NULL));

    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_JOYSTICK | SDL_INIT_GAMECONTROLLER) != 0)
        return 1;

    if (!(IMG_Init(IMG_INIT_PNG) & IMG_INIT_PNG))
    {
        SDL_Quit();
        return 1;
    }

    SDL_Window *window = SDL_CreateWindow(
        "Snake Dungeon Game",
        SDL_WINDOWPOS_CENTERED,
        SDL_WINDOWPOS_CENTERED,
        SCREEN_WIDTH,
        SCREEN_HEIGHT,
        SDL_WINDOW_SHOWN);

    if (!window)
    {
        IMG_Quit();
        SDL_Quit();
        return 1;
    }

    SDL_Renderer *renderer = SDL_CreateRenderer(
        window,
        -1,
        SDL_RENDERER_ACCELERATED );
        //| SDL_RENDERER_PRESENTVSYNC
    if (!renderer)
    {
        SDL_DestroyWindow(window);
        IMG_Quit();
        SDL_Quit();
        return 1;
    }

    // Initialize Joy‑Con using joyconlib (optional)
    bool joycon_connected = false;
    joycon_err err = joycon_open(&jc, JOYCON_R);
    if (JOYCON_ERR_NONE == err) {
        joycon_connected = true;
    } else {
        SDL_Log("Joy‑Con open failed (ignored): %d", err);
        // Continue without Joy‑Con; game will rely on keyboard controls.
    }
    // Edge detection flags for one‑shot buttons
    bool prevA = false, prevB = false, prevR = false, prevY = false, prevHome = false;

    SDL_RenderSetLogicalSize(renderer,
                             LOGICAL_WIDTH,
                             LOGICAL_HEIGHT);
    // Initialize SDL_ttf and load font
    if (TTF_Init() != 0) {
        SDL_Log("Failed to initialize TTF: %s", TTF_GetError());
        // Continue without font (may cause UI without text)
    }
    TTF_Font *font = TTF_OpenFont("assert/arial.ttf", 24);
    if (!font) {
        // Fallback to a common system font
        const char *fallback_path = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf";
        font = TTF_OpenFont(fallback_path, 24);
        if (!font) {
            SDL_Log("Failed to load fallback font at %s: %s", fallback_path, TTF_GetError());
        } else {
            SDL_Log("Loaded fallback font from %s", fallback_path);
        }
    }

    // Load background textures for stages a and b
    // Load background textures for stages a and b (correct filenames)
    SDL_Texture *mapATex[3] = {NULL};
    SDL_Texture *mapBTex[3] = {NULL};
    const char *mapApaths[3] = {"assert/mapa1.png", "assert/mapb1.png", "assert/mapc1.png"};
    const char *mapBpaths[3] = {"assert/mapa2.png", "assert/mapb2.png", "assert/mapc2.png"};
    for (int i = 0; i < 3; ++i) {
        mapATex[i] = IMG_LoadTexture(renderer, mapApaths[i]);
        if (!mapATex[i]) SDL_Log("Failed to load %s: %s", mapApaths[i], IMG_GetError());
        mapBTex[i] = IMG_LoadTexture(renderer, mapBpaths[i]);
        if (!mapBTex[i]) SDL_Log("Failed to load %s: %s", mapBpaths[i], IMG_GetError());
    }
    // Load UI textures
    // Load UI textures (pause screens). Stage 3 pause screen not used.
    SDL_Texture *stagePauseTex[3] = {NULL};
    stagePauseTex[0] = IMG_LoadTexture(renderer, "assert/stage1.png");
    if (!stagePauseTex[0]) SDL_Log("Failed to load %s: %s", "assert/stage1.png", IMG_GetError());
    stagePauseTex[1] = IMG_LoadTexture(renderer, "assert/stage2.png");
    if (!stagePauseTex[1]) SDL_Log("Failed to load %s: %s", "assert/stage2.png", IMG_GetError());
    // stagePauseTex[2] remains NULL.
    SDL_Texture *clearTex = IMG_LoadTexture(renderer, "assert/clear.png");

    // Fallback if loading fails
    // Individual texture loading errors are reported above in the loading loops.

    SDL_Texture *snakeTex =
        IMG_LoadTexture(renderer, "assert/snake1.png");

    SDL_Texture *enemyTex =
        IMG_LoadTexture(renderer, "assert/enemy2.png");

    SDL_Texture *appleTex =
        IMG_LoadTexture(renderer, "assert/apple.png");

    SDL_Texture *lightTex =
        IMG_LoadTexture(renderer, "assert/light.png");

    SDL_Texture *roopTex =
        IMG_LoadTexture(renderer, "assert/roop.png");

    SDL_Texture *starTex =
        IMG_LoadTexture(renderer, "assert/star.png");

    SDL_Texture *titleTex = IMG_LoadTexture(renderer, "assert/first.png");
    // Load game over texture
    SDL_Texture *gameoverTex = IMG_LoadTexture(renderer, "assert/gameover.png");
    // Load guide texture
    SDL_Texture *guideTex = IMG_LoadTexture(renderer, "assert/guide.png");
    if (!titleTex || !gameoverTex || !guideTex) {
        if (titleTex) SDL_DestroyTexture(titleTex);
        if (gameoverTex) SDL_DestroyTexture(gameoverTex);
        if (guideTex) SDL_DestroyTexture(guideTex);
        SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(window);
        IMG_Quit();
        SDL_Quit();
        return 1;
    }



    //---------------------------------
    // Game Context & Initialization
    //---------------------------------
    GameContext gameCtx = {0};
    gameCtx.stage = 1;
    game_init(&gameCtx, get_stage_map(1));
    gameCtx.state = STATE_TITLE;

    bool quit = false;
    Uint32 lastAnim = SDL_GetTicks();
    Uint32 lastMoveTime = 0;

    //---------------------------------
    // Main Loop
    //---------------------------------
    while (!quit)
    {
        SDL_Event e;
        Uint32 now = SDL_GetTicks();
        Direction nextDir = gameCtx.player.dir;
        bool moveRequested = false;

        while (SDL_PollEvent(&e))
        {
            if (e.type == SDL_QUIT)
            {
                quit = true;
            }
            else if (e.type == SDL_KEYDOWN)
            {
                // タイトル画面でEnterキーを押したらゲーム開始
                if (gameCtx.state == STATE_TITLE && e.key.keysym.sym == SDLK_RETURN)
                {
                    gameCtx.stage = 1;
                    game_init(&gameCtx, get_stage_map(1));
                    gameCtx.state = STATE_PLAYING;
                }else{
                    game_handle_keydown(&gameCtx, e.key.keysym.sym,get_stage_map(gameCtx.stage));
                }
            }
            else if (e.type == SDL_KEYUP)
            {
                game_handle_keyup(&gameCtx, e.key.keysym.sym);
            }
        }
        // Retrieve Joy‑Con state each frame (if connected)
        if (joycon_connected) {
            joycon_get_state(&jc);
        }
        // Keyboard directional input (arrow keys) and other actions
        const Uint8 *keystate = SDL_GetKeyboardState(NULL);
        // Keyboard directional input
        if (gameCtx.stage == 1) {
        // Stage1：通常操作
            if (keystate[SDL_SCANCODE_UP]) {
                nextDir = DIR_UP;
                moveRequested = true;
            } else if (keystate[SDL_SCANCODE_DOWN]) {
                nextDir = DIR_DOWN;
                moveRequested = true;
            } else if (keystate[SDL_SCANCODE_LEFT]) {
                nextDir = DIR_LEFT;
                moveRequested = true;
            } else if (keystate[SDL_SCANCODE_RIGHT]) {
                nextDir = DIR_RIGHT;
                moveRequested = true;
            }
        }else {
        // Stage2・Stage3：反転操作
            if (keystate[SDL_SCANCODE_UP]) {
                nextDir = DIR_DOWN;
                moveRequested = true;
            } else if (keystate[SDL_SCANCODE_DOWN]) {
                nextDir = DIR_UP;
                moveRequested = true;
            } else if (keystate[SDL_SCANCODE_LEFT]) {
                nextDir = DIR_RIGHT;
                moveRequested = true;
            } else if (keystate[SDL_SCANCODE_RIGHT]) {
                nextDir = DIR_LEFT;
                moveRequested = true;
            }
        }
        // Space – use star (same as R button)
        if (keystate[SDL_SCANCODE_SPACE]) {
            if (gameCtx.has_star && !gameCtx.is_star_invincible) {
                gameCtx.has_star = false;
                gameCtx.is_star_invincible = true;
                gameCtx.star_invincible_timer = SDL_GetTicks() + 3000;
            }
        }

        // Escape – act like Home button (return to title screen)
        if (keystate[SDL_SCANCODE_ESCAPE]) {
            gameCtx.stage = 1;
            game_init(&gameCtx, get_stage_map(1));
            gameCtx.state = STATE_TITLE;
        }
        // B key – show guide screen (same as Joy-Con B button)
        if (keystate[SDL_SCANCODE_B]) {
            if (gameCtx.state == STATE_TITLE) {
                gameCtx.state = STATE_GUIDE;
            }
        }
        // Y key – restart stage on game over (same as Joy-Con Y button)
        if (keystate[SDL_SCANCODE_Y]) {
            if (gameCtx.state == STATE_GAMEOVER) {
                game_restart(&gameCtx, get_stage_map(gameCtx.stage));
            }
        }
        // Edge detection for one‑shot buttons (Joy‑Con only)
        if (joycon_connected) {
            // A button – start / stage clear advance
            if (jc.button.btn.A && !prevA) {
                if (gameCtx.state == STATE_TITLE) {
                    gameCtx.stage = 1;
                    game_init(&gameCtx, get_stage_map(1));
                    gameCtx.state = STATE_PLAYING;
                }
            }

            // B button – show guide screen
            if (jc.button.btn.B && !prevB) {
                if (gameCtx.state == STATE_TITLE) {
                    gameCtx.state = STATE_GUIDE;
                }
            }

            // R button – use star (edge triggered)
            if (jc.button.btn.R && !prevR) {
                if (gameCtx.has_star && !gameCtx.is_star_invincible) {
                    gameCtx.has_star = false;
                    gameCtx.is_star_invincible = true;
                    gameCtx.star_invincible_timer = SDL_GetTicks() + 3000;
                }
            }

            // ZR button – dash while held
            // ZR button or Shift key – dash while held
            gameCtx.is_dashing =
            (jc.button.btn.ZR && gameCtx.stamina > 0) ||
            (keystate[SDL_SCANCODE_LSHIFT] && gameCtx.stamina > 0);

            // Y button – restart stage on game over (edge)
            if (jc.button.btn.Y && !prevY) {
                if (gameCtx.state == STATE_GAMEOVER) {
                    game_restart(&gameCtx, get_stage_map(gameCtx.stage));
                }
            }

            // Home button – return to title screen (edge)
            if (jc.button.btn.Home && !prevHome) {
                gameCtx.stage = 1;
                game_init(&gameCtx, get_stage_map(1));
                // Ensure we end at TITLE state
                gameCtx.state = STATE_TITLE;
            }

            // D‑Pad check for directional movement (Joy‑Con mapping)
            int dir = joycon_get_direction(gameCtx.stage);
            if (dir != -1) {
                nextDir = dir;
                moveRequested = true;
            }
        }
        
        // Remember previous button states for edge detection
        if (joycon_connected) {
            prevA = jc.button.btn.A;
            prevB = jc.button.btn.B;
            prevR = jc.button.btn.R;
            prevY = jc.button.btn.Y;
            prevHome = jc.button.btn.Home;
        } else {
            // No Joy‑Con: reset previous flags
            prevA = prevB = prevR = prevY = prevHome = false;
        }
        
        if (moveRequested)
        {
            // 向きのセット
            snake_set_dir(&gameCtx.player, nextDir);

            // ダッシュ及び通常時の移動制限時間 (ダッシュ時は70ms、通常時は1400msの間隔)
            Uint32 moveInterval = gameCtx.is_dashing ? 70 : 140;
            if (now - lastMoveTime >= moveInterval)
            {
                lastMoveTime = now;

                int nextX = gameCtx.player.x;
                int nextY = gameCtx.player.y;

                switch (nextDir)
                {
                    case DIR_UP:    nextY -= TILE_SIZE; break;
                    case DIR_DOWN:  nextY += TILE_SIZE; break;
                    case DIR_LEFT:  nextX -= TILE_SIZE; break;
                    case DIR_RIGHT: nextX += TILE_SIZE; break;
                }

                int gx = nextX / TILE_SIZE;
                int gy = nextY / TILE_SIZE;

                if (gx >= 0 && gx < MAP_WIDTH && gy >= 0 && gy < MAP_HEIGHT && get_stage_map(gameCtx.stage)[gy][gx] != 1)
                {
                    snake_move(&gameCtx.player);
                    snake_advance_frame(&gameCtx.player);
                }
            }
        }

        // ゲームステータス等の更新
        if (gameCtx.state == STATE_PLAYING)
        {
            game_update(&gameCtx, now, get_stage_map(gameCtx.stage));
        }

        // アニメーション更新
        if (now - lastAnim >= ANIM_INTERVAL)
        {
            lastAnim = now;
        }

        //---------------------------------
        // Render
        //---------------------------------
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);

        if (gameCtx.state == STATE_TITLE) {
            if (titleTex) SDL_RenderCopy(renderer, titleTex, NULL, NULL);
            SDL_RenderPresent(renderer);
            continue;
        }

        if (gameCtx.state == STATE_GUIDE) {
            if (guideTex)
            SDL_RenderCopy(renderer, guideTex, NULL, NULL);
            SDL_RenderPresent(renderer);
            continue;
        }

        // マップ描画
        // Render appropriate background based on map_switched flag and current stage
        int stageIdx = gameCtx.stage - 1;
        if (gameCtx.map_switched) {
            if (mapBTex[stageIdx]) SDL_RenderCopy(renderer, mapBTex[stageIdx], NULL, NULL);
        } else {
            if (mapATex[stageIdx]) SDL_RenderCopy(renderer, mapATex[stageIdx], NULL, NULL);
        }

        // Warp portals render
        const int (*currentMap)[MAP_WIDTH] = get_stage_map(gameCtx.stage);
        for (int y = 0; y < MAP_HEIGHT; y++) {
            for (int x = 0; x < MAP_WIDTH; x++) {
                if (currentMap[y][x] == 4 || currentMap[y][x] == 5) {
                    SDL_Rect dst = { x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE };
                    SDL_RenderCopy(renderer, roopTex, NULL, &dst);
                }
            }
        }

        // アイテム描画
        item_render(&gameCtx.apple, renderer, appleTex);
        item_render(&gameCtx.light, renderer, lightTex);
        if (gameCtx.stage == 3) {
            item_render(&gameCtx.star, renderer, starTex);
        }

        // プレイヤー描画 (無敵中は点滅させる効果)
        bool drawPlayer = true;
        if (gameCtx.is_star_invincible && now < gameCtx.star_invincible_timer) {
            // 100ms表示(0)→100ms非表示(1)を繰り返す
            if ((now / 100) % 2 == 1) {
                drawPlayer = false;
            }
        } else if (now < gameCtx.invincibleTimer) {
            // 200msごとに点滅
            if ((now / 200) % 2 == 0) {
                drawPlayer = false;
            }
        }

        if (drawPlayer) {
            SDL_Rect src, dst;
            snake_get_src_rect(&gameCtx.player, &src);
            dst.x = gameCtx.player.x;
            dst.y = gameCtx.player.y;
            dst.w = TILE_SIZE;
            dst.h = TILE_SIZE;
            SDL_RenderCopy(renderer, snakeTex, &src, &dst);
        }

        // 敵描画
        int enemy_cnt = (gameCtx.stage == 3) ? 3 : 2;
        for (int i = 0; i < enemy_cnt; i++) {
            enemy_render(&gameCtx.enemies[i], renderer, enemyTex);
        }

        // UI表示
        ui_draw_game_hud(renderer, font, gameCtx.life, gameCtx.stamina, gameCtx.max_stamina, gameCtx.light_count, gameCtx.stage, gameCtx.has_star, starTex);

        // Stage clear handling
        if (gameCtx.state == STATE_CLEAR)
        {
            if (gameCtx.stage < 3) {
                // Award one life for clearing this stage (max 99)
                if (gameCtx.life < 99) {
                    gameCtx.life++;
                }

                // Show stage pause image
                SDL_Texture *pauseTex = stagePauseTex[gameCtx.stage-1]; // stage-1 index
                if (pauseTex) SDL_RenderCopy(renderer, pauseTex, NULL, NULL);
                SDL_RenderPresent(renderer);
                // Wait for Enter key or Joy‑Con A button
                bool waitEnter = true;
                SDL_Event ev;
                // Remember Joy‑Con state for edge detection inside this loop
                bool localPrevA = prevA;
            // Home button handling inside clear wait loop
            bool localPrevHome = prevHome;
                while (waitEnter) {
                    while (SDL_PollEvent(&ev)) {
                        if (ev.type == SDL_QUIT) {
                            quit = true;
                            waitEnter = false;
                        } else if (ev.type == SDL_KEYDOWN) {
                            // Enter：次ステージ
                            if (ev.key.keysym.sym == SDLK_RETURN) {
                                waitEnter = false;
                            }
                            // Esc：タイトルへ戻る
                            else if (ev.key.keysym.sym == SDLK_ESCAPE) {
                                gameCtx.stage = 1;
                                game_init(&gameCtx, get_stage_map(1));
                                gameCtx.state = STATE_TITLE;
                                waitEnter = false;
                            }
                        }
                    }
                    // Joy‑Con check (only if connected)
                    if (joycon_connected) {
                        joycon_get_state(&jc);
                        if (jc.button.btn.A && !localPrevA) {
                            waitEnter = false;
                        }
                        // Home button: return to title screen
                        if (jc.button.btn.Home && !localPrevHome) {
                            // Reset to title
                            gameCtx.stage = 1;
                            game_init(&gameCtx, get_stage_map(1));
                            gameCtx.state = STATE_TITLE;
                            waitEnter = false;
                        }
                        localPrevA = jc.button.btn.A;
                        localPrevHome = jc.button.btn.Home;
                    }
                }
                // Advance to next stage if we did not return to title
                if (gameCtx.state != STATE_TITLE) {
                    gameCtx.stage++;
                    // Reinitialize for next stage
                    // Reset flags
                    gameCtx.map_switched = false;
                    gameCtx.goal_opened = false;
                    gameCtx.light_count = 0;
                    // Load new map data
                    const int (*newMap)[MAP_WIDTH] = get_stage_map(gameCtx.stage);
                    game_init(&gameCtx, newMap);
                    // After reinitialization, set state back to PLAYING
                    gameCtx.state = STATE_PLAYING;
                }
                // Skip further rendering this frame; will render next loop iteration
                continue;
            }else {
                if (clearTex)SDL_RenderCopy(renderer, clearTex, NULL, NULL);
                gameCtx.has_star = false;
                gameCtx.is_star_invincible = false;
                gameCtx.star_invincible_timer = 0;

                SDL_Event ev;
                while (SDL_PollEvent(&ev)) {
                    if (ev.type == SDL_QUIT) {
                        quit = true;
                    }
                    else if (ev.type == SDL_KEYDOWN && ev.key.keysym.sym == SDLK_ESCAPE) {
                        gameCtx.stage = 1;
                        game_init(&gameCtx, get_stage_map(1));
                        gameCtx.state = STATE_TITLE;
                    }
                }  

                if (joycon_connected) {
                    joycon_get_state(&jc);

                    if (jc.button.btn.Home && !prevHome) {
                        gameCtx.stage = 1;
                        game_init(&gameCtx, get_stage_map(1));
                        gameCtx.state = STATE_TITLE;
                    }
                }
            }
        } else if (gameCtx.state == STATE_GAMEOVER) {
            // Render full-screen game over image
            if (gameoverTex) SDL_RenderCopy(renderer, gameoverTex, NULL, NULL);
            SDL_RenderPresent(renderer);
            // Skip all other game logic while in game over state
            continue;
        }

        SDL_RenderPresent(renderer);
    }

    // クリーンアップ
    SDL_DestroyTexture(snakeTex);
    SDL_DestroyTexture(enemyTex);
    SDL_DestroyTexture(appleTex);
    SDL_DestroyTexture(lightTex);
    SDL_DestroyTexture(roopTex);
    SDL_DestroyTexture(starTex);
    SDL_DestroyTexture(titleTex);
    SDL_DestroyTexture(gameoverTex);
    for (int i = 0; i < 3; ++i) {
        if (mapATex[i]) SDL_DestroyTexture(mapATex[i]);
        if (mapBTex[i]) SDL_DestroyTexture(mapBTex[i]);
    }
    for (int i = 0; i < 3; ++i) {
        if (stagePauseTex[i]) SDL_DestroyTexture(stagePauseTex[i]);
    }
    if (clearTex) SDL_DestroyTexture(clearTex);

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);

    if (font) TTF_CloseFont(font);
    TTF_Quit();
    IMG_Quit();
    // Close Joy‑Con if it was opened
    if (joycon_connected) {
        joycon_close(&jc);
    }
    SDL_Quit();

    return 0;
}
