#include "enemy.h"
#include <stdlib.h>
#include <string.h>

#define MAP_WIDTH 17
#define MAP_HEIGHT 13
#define ENEMY_MOVE_INTERVAL 600 // 0.3秒(300ms)ごとに移動

// 向きからスプライトシート上の行インデックスを取得
// 一番上が下(0)、2列目が上(1)、3列目が左(2)、4列目が右(3)
static int direction_to_row(Direction dir)
{
    switch (dir)
    {
        case DIR_DOWN:  return 0;
        case DIR_UP:    return 1;
        case DIR_LEFT:  return 2;
        case DIR_RIGHT: return 3;
        default:        return 0;
    }
}

void enemy_init(Enemy *e, int gridX, int gridY, EnemyType type)
{
    e->x = gridX * TILE_SIZE;
    e->y = gridY * TILE_SIZE;
    e->prev_x = e->x;
    e->prev_y = e->y;
    e->frame = 0;
    e->moveTimer = 0;
    e->type = type;
    e->dir = DIR_DOWN;
}

// BFS 用のキューと探索データ構造
typedef struct {
    int x, y;
} Point;

// BFSで (startX, startY) から (targetX, targetY) への最短経路の最初の1歩（方向）を求める関数
static bool find_next_step_bfs(int startX, int startY, int targetX, int targetY, const int map[MAP_HEIGHT][MAP_WIDTH], Direction *outDir)
{
    // すでに目的地にいる場合
    if (startX == targetX && startY == targetY) {
        return false;
    }

    // 範囲外チェックと正規化
    if (targetX < 0) targetX = 0;
    if (targetX >= MAP_WIDTH) targetX = MAP_WIDTH - 1;
    if (targetY < 0) targetY = 0;
    if (targetY >= MAP_HEIGHT) targetY = MAP_HEIGHT - 1;

    // もし目的地が壁なら、目的地に最も近い空きマスを探す簡易フォールバック
    if (map[targetY][targetX] == 1) {
        int bestX = targetX, bestY = targetY;
        int min_dist = 999999;
        for (int y = 0; y < MAP_HEIGHT; y++) {
            for (int x = 0; x < MAP_WIDTH; x++) {
                if (map[y][x] != 1) {
                    int d = abs(x - targetX) + abs(y - targetY);
                    if (d < min_dist) {
                        min_dist = d;
                        bestX = x;
                        bestY = y;
                    }
                }
            }
        }
        targetX = bestX;
        targetY = bestY;
    }

    // 探索用の親情報テーブル (y * MAP_WIDTH + x)
    // 経路復元のために使用
    int parent[MAP_HEIGHT][MAP_WIDTH];
    memset(parent, -1, sizeof(parent));

    Point queue[MAP_WIDTH * MAP_HEIGHT];
    int head = 0, tail = 0;

    // 初期ノード
    queue[tail++] = (Point){startX, startY};
    parent[startY][startX] = startY * MAP_WIDTH + startX; // 自分自身を親として訪問済みにする

    bool found = false;
    int dirs_x[4] = { 0, 0, -1, 1 }; // UP, DOWN, LEFT, RIGHT
    int dirs_y[4] = { -1, 1, 0, 0 };


    while (head < tail) {
        Point curr = queue[head++];

        if (curr.x == targetX && curr.y == targetY) {
            found = true;
            break;
        }

        for (int i = 0; i < 4; i++) {
            int nx = curr.x + dirs_x[i];
            int ny = curr.y + dirs_y[i];

            if (nx >= 0 && nx < MAP_WIDTH && ny >= 0 && ny < MAP_HEIGHT) {
                if (map[ny][nx] != 1 && parent[ny][nx] == -1) {
                    parent[ny][nx] = curr.y * MAP_WIDTH + curr.x;
                    queue[tail++] = (Point){nx, ny};
                }
            }
        }
    }

    if (!found) {
        return false; // 経路が見つからなかった
    }

    // 目的地からスタート地点に向かって経路を逆戻りし、スタート地点の「次の1歩」を特定する
    int cx = targetX;
    int cy = targetY;

    while (true) {
        int p = parent[cy][cx];
        int px = p % MAP_WIDTH;
        int py = p / MAP_WIDTH;

        if (px == startX && py == startY) {
            // この (cx, cy) がスタート地点から進むべき次のマス
            if (cx > startX) *outDir = DIR_RIGHT;
            else if (cx < startX) *outDir = DIR_LEFT;
            else if (cy > startY) *outDir = DIR_DOWN;
            else if (cy < startY) *outDir = DIR_UP;
            return true;
        }

        cx = px;
        cy = py;
    }
}

void enemy_update(Enemy *e, Uint32 now, const int map[13][17], const Snake *player)
{
    // Save previous tile position for collision checks
    e->prev_x = e->x;
    e->prev_y = e->y;
    if (e->moveTimer == 0) {
        e->moveTimer = now + ENEMY_MOVE_INTERVAL;
    } else if (now >= (Uint32)e->moveTimer) {
        e->moveTimer += ENEMY_MOVE_INTERVAL;
        if (now >= (Uint32)e->moveTimer) {
            e->moveTimer = now + ENEMY_MOVE_INTERVAL;
        }
    } else {
        return; // まだ移動時間ではない
    }

    int curX = e->x / TILE_SIZE;
    int curY = e->y / TILE_SIZE;

    int targetX = player->x / TILE_SIZE;
    int targetY = player->y / TILE_SIZE;
    // プレイヤーがスタート地点にいる間は敵はランダム移動
    if (targetX == 16 && targetY == 6) {
        Direction dirs[4] = {
            DIR_UP, DIR_DOWN,
            DIR_LEFT, DIR_RIGHT
        };

        Direction possible_dirs[4];
        int possible_count = 0;

        for (int i = 0; i < 4; i++) {
            int nx = curX;
            int ny = curY;

            switch (dirs[i]) {
                case DIR_UP:    ny--; break;
                case DIR_DOWN:  ny++; break;
                case DIR_LEFT:  nx--; break;
                case DIR_RIGHT: nx++; break;
            }

            if (nx >= 0 && nx < MAP_WIDTH &&
                ny >= 0 && ny < MAP_HEIGHT &&
                map[ny][nx] != 1)
            {
                possible_dirs[possible_count++] = dirs[i];
            }
        }

        if (possible_count > 0) {
            e->dir = possible_dirs[rand() % possible_count];

            switch (e->dir) {
                case DIR_UP:    e->y -= TILE_SIZE; break;
                case DIR_DOWN:  e->y += TILE_SIZE; break;
                case DIR_LEFT:  e->x -= TILE_SIZE; break;
                case DIR_RIGHT: e->x += TILE_SIZE; break;
            }
        }

        return;
    }
    // 先読み追跡型の場合、プレイヤーの向きに合わせて3マス先を目標にする
    if (e->type == ENEMY_PREDICT) {
        int steps = 3;
        int px = targetX;
        int py = targetY;

        switch (player->dir) {
            case DIR_UP:    py -= steps; break;
            case DIR_DOWN:  py += steps; break;
            case DIR_LEFT:  px -= steps; break;
            case DIR_RIGHT: px += steps; break;
        }

        // 3マス先が範囲内かつ壁でないかをチェックし、壁なら到達可能な手前のマスに調節する
        while (steps > 0) {
            int testX = targetX;
            int testY = targetY;
            switch (player->dir) {
                case DIR_UP:    testY -= steps; break;
                case DIR_DOWN:  testY += steps; break;
                case DIR_LEFT:  testX -= steps; break;
                case DIR_RIGHT: testX += steps; break;
            }

            if (testX >= 0 && testX < MAP_WIDTH && testY >= 0 && testY < MAP_HEIGHT) {
                if (map[testY][testX] != 1) {
                    targetX = testX;
                    targetY = testY;
                    break;
                }
            }
            steps--;
        }
    }

    // BFSで最短経路を探して進む
    Direction nextDir = e->dir;
    if (find_next_step_bfs(curX, curY, targetX, targetY, map, &nextDir)) {
        e->dir = nextDir;
        
        // 1マス移動
        switch (e->dir) {
            case DIR_UP:    e->y -= TILE_SIZE; break;
            case DIR_DOWN:  e->y += TILE_SIZE; break;
            case DIR_LEFT:  e->x -= TILE_SIZE; break;
            case DIR_RIGHT: e->x += TILE_SIZE; break;
        }
    } else {
        // BFSで見つからなかった場合（目標への到達が完全に不可能な場合など）、周囲の行ける場所へランダム移動するフォールバック
        Direction dirs[4] = { DIR_UP, DIR_DOWN, DIR_LEFT, DIR_RIGHT };
        Direction possible_dirs[4];
        int possible_count = 0;

        for (int i = 0; i < 4; i++) {
            int nx = curX;
            int ny = curY;
            switch (dirs[i]) {
                case DIR_UP:    ny--; break;
                case DIR_DOWN:  ny++; break;
                case DIR_LEFT:  nx--; break;
                case DIR_RIGHT: nx++; break;
            }
            if (nx >= 0 && nx < MAP_WIDTH && ny >= 0 && ny < MAP_HEIGHT) {
                if (map[ny][nx] != 1) {
                    possible_dirs[possible_count++] = dirs[i];
                }
            }
        }
        if (possible_count > 0) {
            e->dir = possible_dirs[rand() % possible_count];
            switch (e->dir) {
                case DIR_UP:    e->y -= TILE_SIZE; break;
                case DIR_DOWN:  e->y += TILE_SIZE; break;
                case DIR_LEFT:  e->x -= TILE_SIZE; break;
                case DIR_RIGHT: e->x += TILE_SIZE; break;
            }
        }
    }
}

void enemy_render(const Enemy *e, SDL_Renderer *renderer, SDL_Texture *tileset)
{
    SDL_Rect src;
    src.x = e->frame * TILE_SIZE;
    src.y = direction_to_row(e->dir) * TILE_SIZE;
    src.w = TILE_SIZE;
    src.h = TILE_SIZE;

    SDL_Rect dst;
    dst.x = e->x;
    dst.y = e->y;
    dst.w = TILE_SIZE;
    dst.h = TILE_SIZE;

    SDL_RenderCopy(renderer, tileset, &src, &dst);
}
