#include "game.h"
#include "map.h"

void game_init(GameContext *ctx, const int map[MAP_HEIGHT][MAP_WIDTH])
{
    ctx->life = 3;
    ctx->stamina = 100;
    ctx->max_stamina = 100;
    ctx->light_count = 0;
    ctx->invincibleTimer = 0;
    ctx->state = STATE_PLAYING;
    ctx->is_dashing = false;
    ctx->warp_cooldown = false;
    // Initialize stage only on first init
    if (ctx->stage == 0) ctx->stage = 1; // start at stage 1 if not set
    ctx->map_switched = false;
    ctx->goal_opened = false;
    ctx->has_star = false;
    ctx->is_star_invincible = false;
    ctx->star_invincible_timer = 0;
    // Initialize goal position for current stage
    get_stage_goal(ctx->stage, &ctx->goal_x, &ctx->goal_y);

    // Initialize player position based on stage start tile
    int start_x, start_y;
    get_stage_start(ctx->stage, &start_x, &start_y);
    snake_init(&ctx->player, start_x * TILE_SIZE, start_y * TILE_SIZE);

    // Initialize enemies based on stage configuration
    int enemy_cnt = (ctx->stage == 3) ? 3 : 2;
    for (int i = 0; i < enemy_cnt; ++i) {
        int ex, ey;
        get_stage_enemy_start(ctx->stage, i, &ex, &ey);
        // For simplicity, use ENEMY_TRACKER for first, ENEMY_PREDICT for others
        EnemyType type = (i == 0) ? ENEMY_TRACKER : ENEMY_PREDICT;
        enemy_init(&ctx->enemies[i], ex, ey, type);
    }

    // Initialize items (apple and light) at random positions
    item_init(&ctx->apple, ITEM_APPLE, map);
    item_init(&ctx->light, ITEM_LIGHT, map);
    // Ensure light does not overlap apple
    if (ctx->apple.x == ctx->light.x && ctx->apple.y == ctx->light.y) {
        item_reposition(&ctx->light, map);
    }

    // Initialize star item in stage 3
    if (ctx->stage == 3) {
        item_init(&ctx->star, ITEM_STAR, map);
        // Reposition star so it does not overlap: player, enemies, blue lights (light), apples (apple), goal, loop portals (4, 5)
        int retries = 0;
        while (retries < 100) {
            bool conflict = false;
            int sx = ctx->star.x / TILE_SIZE;
            int sy = ctx->star.y / TILE_SIZE;
            
            // Wall tile check
            if (map[sy][sx] == 1) conflict = true;
            
            // Loop portal checks (4 and 5)
            if (map[sy][sx] == 4 || map[sy][sx] == 5) conflict = true;
            
            // Player position check
            if (ctx->star.x == ctx->player.x && ctx->star.y == ctx->player.y) conflict = true;
            
            // Apple check
            if (ctx->apple.active && ctx->star.x == ctx->apple.x && ctx->star.y == ctx->apple.y) conflict = true;
            
            // Light check
            if (ctx->light.active && ctx->star.x == ctx->light.x && ctx->star.y == ctx->light.y) conflict = true;
            
            // Goal check
            if (sx == ctx->goal_x && sy == ctx->goal_y) conflict = true;
            
            // Enemies check
            for (int i = 0; i < enemy_cnt; i++) {
                if (ctx->star.x == ctx->enemies[i].x && ctx->star.y == ctx->enemies[i].y) {
                    conflict = true;
                    break;
                }
            }
            
            if (!conflict) break;
            item_reposition(&ctx->star, map);
            retries++;
        }
    } else {
        ctx->star.active = false;
    }
}

void game_restart(GameContext *ctx, const int map[MAP_HEIGHT][MAP_WIDTH])
{
    game_init(ctx, map);
}

void game_update(GameContext *ctx, Uint32 now, const int map[MAP_HEIGHT][MAP_WIDTH])
{
    if (ctx->state != STATE_PLAYING) return;

    // Stamina management (dash consumes stamina, no automatic regeneration)
    static Uint32 lastDashUpdate = 0;
    if (lastDashUpdate == 0) lastDashUpdate = now;
    if (now - lastDashUpdate >= 100) {
        lastDashUpdate = now;
        if (ctx->is_dashing && ctx->stamina > 0) {
            ctx->stamina -= 5;
            if (ctx->stamina < 0) {
                ctx->stamina = 0;
                ctx->is_dashing = false;
            }
        }
    }

    // Warp logic (Stage 3 loop feature)
    if (ctx->stage == 3) {
        int px = ctx->player.x / TILE_SIZE;
        int py = ctx->player.y / TILE_SIZE;
        int current_tile = map[py][px];
        if (current_tile == 4 || current_tile == 5) {
            if (!ctx->warp_cooldown) {
                int dest_val = (current_tile == 4) ? 5 : 4;
                int dest_x = -1, dest_y = -1;
                for (int y = 0; y < MAP_HEIGHT; y++) {
                    for (int x = 0; x < MAP_WIDTH; x++) {
                        if (map[y][x] == dest_val) {
                            dest_x = x;
                            dest_y = y;
                            break;
                        }
                    }
                    if (dest_x != -1) break;
                }
                if (dest_x != -1 && dest_y != -1) {
                    ctx->player.x = dest_x * TILE_SIZE;
                    ctx->player.y = dest_y * TILE_SIZE;
                    ctx->warp_cooldown = true;
                }
            }
        } else {
            ctx->warp_cooldown = false;
        }
    }

    // Enemy update (stage dependent)
    int enemy_cnt = (ctx->stage == 3) ? 3 : 2;
    for (int i = 0; i < enemy_cnt; i++) {
        enemy_update(&ctx->enemies[i], now, map, &ctx->player);
    }
    // Prevent overlapping enemies
    for (int i = 0; i < enemy_cnt; i++) {
        for (int j = i + 1; j < enemy_cnt; j++) {
            if (ctx->enemies[i].x == ctx->enemies[j].x && ctx->enemies[i].y == ctx->enemies[j].y) {
                ctx->enemies[j].x = ctx->enemies[j].prev_x; ctx->enemies[j].y = ctx->enemies[j].prev_y;
            }
            if (ctx->enemies[i].x == ctx->enemies[j].prev_x && ctx->enemies[i].y == ctx->enemies[j].prev_y &&
                ctx->enemies[j].x == ctx->enemies[i].prev_x && ctx->enemies[j].y == ctx->enemies[i].prev_y) {
                ctx->enemies[j].x = ctx->enemies[j].prev_x; ctx->enemies[j].y = ctx->enemies[j].prev_y;
            }
        }
    }

    // Update star invincibility status
    if (ctx->is_star_invincible && now >= ctx->star_invincible_timer) {
        ctx->is_star_invincible = false;
    }

    // Collision with enemies
    bool inv = (now < ctx->invincibleTimer) || (ctx->is_star_invincible && now < ctx->star_invincible_timer);
    if (!inv) {
        int px = ctx->player.x / TILE_SIZE, py = ctx->player.y / TILE_SIZE;
        for (int i = 0; i < enemy_cnt; i++) {
            int ex = ctx->enemies[i].x / TILE_SIZE, ey = ctx->enemies[i].y / TILE_SIZE;
            if (px == ex && py == ey) {
                ctx->life--;
                if (ctx->life <= 0) {
                    ctx->state = STATE_GAMEOVER;
                    // Reset star state and invincibility on game over
                    ctx->has_star = false;
                    ctx->is_star_invincible = false;
                    ctx->star_invincible_timer = 0;
                } else {
                    int start_x, start_y;
                    get_stage_start(ctx->stage, &start_x, &start_y);
                    snake_init(&ctx->player, start_x * TILE_SIZE, start_y * TILE_SIZE);
                    
                    // Reset enemies for this stage using get_stage_enemy_start
                    for (int i = 0; i < enemy_cnt; i++) {
                        int ex, ey;
                        get_stage_enemy_start(ctx->stage, i, &ex, &ey);
                        EnemyType type = (i == 0) ? ENEMY_TRACKER : ENEMY_PREDICT;
                        enemy_init(&ctx->enemies[i], ex, ey, type);
                    }
                    ctx->invincibleTimer = now + 2000;
                }
                break;
            }
        }
    }

    // Apple collision
    if (ctx->apple.active) {
        int px = ctx->player.x / TILE_SIZE, py = ctx->player.y / TILE_SIZE;
        int ix = ctx->apple.x / TILE_SIZE, iy = ctx->apple.y / TILE_SIZE;
        if (px == ix && py == iy) {
            ctx->apple.active = false;
            // Restore 50% of maximum stamina, clamped to max
            ctx->stamina += ctx->max_stamina / 2;
            if (ctx->stamina > ctx->max_stamina) ctx->stamina = ctx->max_stamina;
            item_reposition(&ctx->apple, map);
            if (ctx->light.active && ctx->apple.x == ctx->light.x && ctx->apple.y == ctx->light.y) {
                item_reposition(&ctx->apple, map);
            }
        }
    }

    // Star collision
    if (ctx->stage == 3 && ctx->star.active) {
        int px = ctx->player.x / TILE_SIZE, py = ctx->player.y / TILE_SIZE;
        int sx = ctx->star.x / TILE_SIZE, sy = ctx->star.y / TILE_SIZE;
        if (px == sx && py == sy) {
            ctx->star.active = false;
            ctx->has_star = true;
        }
    }

    // Light (goal) collision
    if (ctx->light.active) {
        int px = ctx->player.x / TILE_SIZE, py = ctx->player.y / TILE_SIZE;
        int ix = ctx->light.x / TILE_SIZE, iy = ctx->light.y / TILE_SIZE;
        if (px == ix && py == iy) {
            ctx->light.active = false;
            ctx->light_count++;
            if (ctx->light_count >= 5) {
                // All lights collected: open goal and switch to "b" background
                ctx->goal_opened = true;
                ctx->map_switched = true;
                // Reset light count (no more lights needed this stage)
                //ctx->light_count = 0;
            } else {
                // Reposition next light ensuring no conflict with player, apple, enemies, or goal
                do {
                    item_reposition(&ctx->light, map);
                    // check conflict with player
                    if (ctx->light.x == ctx->player.x && ctx->light.y == ctx->player.y) continue;
                    // conflict with apple
                    if (ctx->light.x == ctx->apple.x && ctx->light.y == ctx->apple.y) continue;
                    // conflict with any enemy
                    bool enemy_conflict = false;
                    for (int i = 0; i < ((ctx->stage == 3) ? 3 : 2); ++i) {
                        if (ctx->light.x == ctx->enemies[i].x && ctx->light.y == ctx->enemies[i].y) { enemy_conflict = true; break; }
                    }
                    if (enemy_conflict) continue;
                    // conflict with goal tile (should be non-zero, but double‑check)
                    if (ctx->light.x == ctx->goal_x * TILE_SIZE && ctx->light.y == ctx->goal_y * TILE_SIZE) continue;
                    // no conflict found
                    break;
                } while (1);
            }
        }
    }

    // Goal detection: allow clear only after goal is opened
    if (ctx->goal_opened) {
        int px = ctx->player.x / TILE_SIZE;
        int py = ctx->player.y / TILE_SIZE;
        if (px == ctx->goal_x && py == ctx->goal_y) {
            ctx->state = STATE_CLEAR;
        }
    }
}

void game_handle_keydown(GameContext *ctx, SDL_Keycode key, const int map[MAP_HEIGHT][MAP_WIDTH])
{
    if (ctx->state == STATE_GAMEOVER) {
        if (key == SDLK_y) {
            game_restart(ctx, map);
        } else if (key == KEY_HOME) {
            ctx->stage = 1;
            game_restart(ctx, map);
            ctx->state = STATE_TITLE;
        }
        return;
    }
    if (ctx->state != STATE_PLAYING) {
        return;
    }
    if (key == SDLK_LSHIFT || key == SDLK_RSHIFT) {
        if (ctx->stamina > 0) ctx->is_dashing = true;
    }
    if (key == SDLK_r) {
        if (ctx->has_star) {
            ctx->has_star = false;
            ctx->is_star_invincible = true;
            ctx->star_invincible_timer = SDL_GetTicks() + 3000;
        }
    }
}

void game_handle_keyup(GameContext *ctx, SDL_Keycode key)
{
    if (key == SDLK_LSHIFT || key == SDLK_RSHIFT) ctx->is_dashing = false;
}
