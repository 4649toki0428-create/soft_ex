# Specification Document for Simple SDL Snake Prototype

## 1. Overview
This document describes the minimal implementation of a 2‑D grid snake game written in **C** using **SDL2**. The prototype focuses exclusively on the core mechanics required by the request:
- Rendering a background map (`map.png`).
- Displaying a snake head sprite taken from `snake.png`.
- Controlling the snake with the arrow keys.
- Animating the snake head (4 frames per direction) with correct handling of per‑row sprite dimensions.

All other game features (food, growth, collision detection, scoring, UI …) are intentionally omitted.

---
## 2. Asset Layout
### 2.1 Map
- File: `map.png`
- Used as a full‑screen background. The program loads it as a texture and draws it covering the entire window.

### 2.2 Snake Sprite Sheet (`snake.png`)
The sprite sheet contains **8 rows** × **4 columns** (animation frames).
| Row Index | Direction / Pose | Frame Size (W×H) | Description |
|-----------|------------------|------------------|-------------|
| 0 | Down (small) | 32 × 32 | Front view, short body |
| 1 | Up (back) | 32 × 32 | Back view |
| 2 | Left (wide) | 48 × 32 | Body stretched horizontally |
| 3 | Right (wide) | 48 × 32 | Body stretched horizontally |
| 4 | Down (large 1) | 32 × 48 | Taller front view |
| 5 | Down (large 2) | 32 × 48 | Taller front view |
| 6 | Right (compact) | 32 × 32 | Small right‑facing pose |
| 7 | Right (compact) | 32 × 32 | Small right‑facing pose |

Each row uses the same number of animation frames (4). The column index (`frame`) runs from 0 to 3.

---
## 3. Data Structures
### 3.1 `Direction`
```c
typedef enum { DIR_UP, DIR_DOWN, DIR_LEFT, DIR_RIGHT } Direction;
```
Represents the four possible movement directions.

### 3.2 `Snake`
```c
typedef struct {
    int x;            // top‑left pixel X of the sprite head
    int y;            // top‑left pixel Y of the sprite head
    Direction dir;    // current moving direction
    int row;          // sprite‑sheet row (0‑7) that matches `dir`
    int frame;        // animation frame (0‑3)
    Uint32 animTimer; // elapsed ms for animation step
    Uint32 moveTimer; // elapsed ms for movement step
} Snake;
```
Only the head is stored, as the prototype does not manage a body.

---
## 4. Core Functions (`snake.c`)
| Function | Purpose |
|----------|---------|
| `snake_init` | Initialise position, direction (default down), set row, reset timers. |
| `snake_set_dir` | Change direction and update the sprite‑sheet row. |
| `snake_advance_frame` | Cycle `frame` from 0→3 on each animation tick. |
| `snake_move` | Move the head one grid step (32 px) in the current direction. |
| `snake_get_src_rect` | Compute the source rectangle for `SDL_RenderCopy`. Width/height are taken from per‑row tables (`ROW_WIDTH`, `ROW_HEIGHT`). X offset = `frame * width`. Y offset is the cumulative sum of previous rows' heights, handling rows with differing heights. |

---
## 5. Main Loop (`main.c`)
1. Initialise SDL video subsystem and create a window (`SCREEN_WIDTH`×`SCREEN_HEIGHT`).
2. Create a renderer with hardware acceleration and VSync.
3. Load `map.png` and `snake.png` as textures using **SDL_image**.
4. Initialise a `Snake` instance at the centre of the window.
5. Enter the event‑render loop:
   - Poll SDL events; on `SDL_KEYDOWN` change direction via `snake_set_dir`.
   - Every `ANIM_INTERVAL` ms call `snake_advance_frame`.
   - Every `MOVE_INTERVAL` ms call `snake_move`.
   - Clear the screen, draw the map, fetch the source rect with `snake_get_src_rect`, and render the snake head at `(snake.x, snake.y)` using the destination rect sized to the source rect.
6. Clean up textures, renderer, window, and quit SDL.

---
## 6. Build System (`Makefile`)
```makefile
CC = gcc
CFLAGS = -Wall -O2 `sdl2-config --cflags`
LDFLAGS = `sdl2-config --libs` -lSDL2_image

all: snake

snake: main.c snake.c
	$(CC) $(CFLAGS) -o snake main.c snake.c $(LDFLAGS)

clean:
	rm -f snake
```
Running `make` produces the executable `snake`.

---
## 7. Usage
```bash
make
./snake
```
Place `map.png` and `snake.png` next to the executable. Use the arrow keys to move the snake head; the animation automatically cycles.

---
## 8. Extensibility Notes (outside current scope)
- **Food & Growth**: Add a linked‑list or array to store body segments, extend `snake_move` to shift positions.
- **Collision Detection**: Compare head coordinates with walls or body segments.
- **Scoring & UI**: Render text using SDL_ttf.
- **Variable Grid Size**: Replace the hard‑coded `step = 32` with a macro derived from the smallest sprite dimension.

---
## 9. License
Public domain (or any permissive license of your choice).
