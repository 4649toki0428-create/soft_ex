# 2D Dungeon Snake Game

A simple grid‑based dungeon game written in **C** using **SDL2**.  
The player controls a snake‑like character that moves on a 17×13 tile map (each tile 60 px).

## New Feature – Enemies

Two enemy types have been added:

1. **Tracker (ENEMY_TRACKER)** – Uses BFS to follow the shortest path to the player.
2. **Predictor (ENEMY_PREDICT)** – Predicts the player’s direction and tries to intercept three tiles ahead.

Both enemies move every **0.3 s** and respect wall collisions.

## Controls
- Arrow keys – move the snake.
- **Shift** – dash (speed‑up, stamina system – already in the code base).
- **Esc** – quit.

## Build & Run
```bash
cd /home/vmware/Documents/pri-game2
make            # compiles `snake`
./snake         # launch the game
```

The Makefile already includes `enemy.c` in the build.

## Files
- `main.c` – game loop, integrates enemies.
- `enemy.h` / `enemy.c` – enemy definitions and logic.
- `snake.h` / `snake.c` – player implementation.
- `map.c`, `game.c`, `item.c`, `ui.c` – supporting modules.
- `README.md` – this document.

Enjoy playing and feel free to extend the AI or add more enemy behaviours!