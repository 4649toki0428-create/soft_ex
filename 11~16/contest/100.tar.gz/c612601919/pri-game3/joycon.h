#ifndef JOYCON_H
#define JOYCON_H

#include <stdbool.h>
#include <SDL2/SDL.h>

// Simple error enum for joycon operations
typedef enum {
    JOYCON_ERR_NONE = 0,
    JOYCON_ERR_OPEN = -1
} joycon_err;

// Button state structure
typedef struct {
    bool A;
    bool B;
    bool X;
    bool Y;
    bool R;
    bool ZR;
    bool Home;
    bool Up;
    bool Down;
    bool Left;
    bool Right;
} JoyConButtons;

// JoyCon state container
typedef struct {
    JoyConButtons btn;
} JoyCon;

// Initialize Joy-Con (opens first available controller)
joycon_err joycon_open(JoyCon *jc);

// Close Joy-Con (frees resources)
void joycon_close(JoyCon *jc);

// Retrieve current button states (fills the JoyCon struct)
void joycon_get_state(JoyCon *jc);

#endif // JOYCON_H
