#include "ui.h"
#include <SDL2/SDL_ttf.h>

#include <stdio.h>
#include <string.h>
#define LOGICAL_WIDTH 1020
#define LOGICAL_HEIGHT 780
static void draw_text(SDL_Renderer *renderer, TTF_Font *font, const char *text, int x, int y, SDL_Color color)
{
    if (!font) return;
    SDL_Surface *surface = TTF_RenderUTF8_Blended(font, text, color);
    if (!surface) return;
    SDL_Texture *texture = SDL_CreateTextureFromSurface(renderer, surface);
    // Enable blending for the text texture to handle alpha correctly
    SDL_SetTextureBlendMode(texture, SDL_BLENDMODE_BLEND);
    SDL_Rect dest = { x, y, surface->w, surface->h };
    SDL_RenderCopy(renderer, texture, NULL, &dest);
    SDL_DestroyTexture(texture);
    SDL_FreeSurface(surface);
}

void ui_draw_game_hud(SDL_Renderer *renderer, TTF_Font *font, int life, int stamina, int max_stamina, int light_count, int stage, bool has_star, SDL_Texture *starTex)
{
    SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
    for (int i = 0; i < life; i++) {
        SDL_Rect heart = { 20 + i * 40, 15, 30, 30 };
        SDL_RenderFillRect(renderer, &heart);
    }

    SDL_Rect stamina_bg = { 200, 15, 200, 30 };
    SDL_SetRenderDrawColor(renderer, 50, 50, 50, 255);
    SDL_RenderFillRect(renderer, &stamina_bg);

    if (stamina > 0) {
        int width = (int)((float)stamina / max_stamina * 200);
        SDL_Rect stamina_fg = { 200, 15, width, 30 };
        SDL_SetRenderDrawColor(renderer, 0, 255, 0, 255);
        SDL_RenderFillRect(renderer, &stamina_fg);
     }

    SDL_SetRenderDrawColor(renderer, 0, 191, 255, 255);
    for (int i = 0; i < 5; i++) {
        SDL_Rect indicator = { 450 + i * 35, 15, 25, 30 };
        if (i < light_count) {
             SDL_RenderFillRect(renderer, &indicator);
        } else {
             SDL_RenderDrawRect(renderer, &indicator);
        }
    }

    if (has_star && starTex) {
        SDL_Rect starRect = { 645, 10, 40, 40 };
        SDL_RenderCopy(renderer, starTex, NULL, &starRect);
    }

    // Draw stage indicator
    char stageText[32];
    snprintf(stageText, sizeof(stageText), "STAGE %d", stage);
    SDL_Color white = { 255, 255, 255, 255 };
    int text_w = (int)strlen(stageText) * 12;
    int x = (LOGICAL_WIDTH - text_w) / 2;
    draw_text(renderer, font, stageText, x, 60, white);
}

void ui_draw_game_over(SDL_Renderer *renderer, TTF_Font *font)
{
    // Enable blending for semi‑transparent overlay
    SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
    // Dark translucent background covering the whole screen
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 200);
    SDL_Rect overlay = { 0, 0, LOGICAL_WIDTH, LOGICAL_HEIGHT };
    SDL_RenderFillRect(renderer, &overlay);

    // Red box frame around the message
    SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
    SDL_Rect box1 = { 310, 270, 400, 240 };
    SDL_RenderDrawRect(renderer, &box1);

    // Center the text inside the box (rough approximation)
    SDL_Color white = { 255, 255, 255, 255 };
    const char *msg = "GAME OVER";
    const char *hint = "Press Y to Restart";
    const char *hint2 = "Press R to Title";
    // Approximate text width assuming 12‑px average per character (adjust if needed)
    int text_w = (int)strlen(msg) * 12;
    int hint_w = (int)strlen(hint) * 12;
    int hint2_w = (int)strlen(hint2) * 12;
    int x_msg = box1.x + (box1.w - text_w) / 2;
    int x_hint = box1.x + (box1.w - hint_w) / 2;
    int x_hint2 = box1.x + (box1.w - hint2_w) / 2;
    draw_text(renderer, font, msg, x_msg, box1.y + 40, white);
    draw_text(renderer, font, hint, x_hint, box1.y + 110, white);
    draw_text(renderer, font, hint2, x_hint2, box1.y + 170, white);
}

void ui_draw_game_clear(SDL_Renderer *renderer, TTF_Font *font)
{
    // Enable blending for semi‑transparent overlay
    SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
    // Dark translucent background covering the whole screen
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 200);
    SDL_Rect overlay = { 0, 0, LOGICAL_WIDTH, LOGICAL_HEIGHT };
    SDL_RenderFillRect(renderer, &overlay);

    // Green box frame around the message
    SDL_SetRenderDrawColor(renderer, 0, 255, 0, 255);
    SDL_Rect box1 = { 310, 290, 400, 200 };
    SDL_RenderDrawRect(renderer, &box1);

    // Center "GAME CLEAR" inside the box
    SDL_Color white = { 255, 255, 255, 255 };
    const char *msg = "GAME CLEAR";
    int text_w = (int)strlen(msg) * 12; // rough width estimate
    int x_msg = box1.x + (box1.w - text_w) / 2;
    draw_text(renderer, font, msg, x_msg, box1.y + 60, white);

    // Optional hint line (kept as‑is)
    SDL_Rect hint_line = { 410, 440, 200, 5 };
    SDL_RenderFillRect(renderer, &hint_line);
}
