#include "snake.h"

#define ANIM_FRAME_MAX 4

static int direction_to_row(Direction dir)
{
    switch (dir)
    {
        case DIR_UP:
            return 0;

        case DIR_DOWN:
            return 1;

        case DIR_RIGHT:
            return 2;

        case DIR_LEFT:
            return 3;

        default:
            return 1;
    }
}

void snake_init(Snake* s, int start_x, int start_y)
{
    s->x = start_x;
    s->y = start_y;

    s->dir = DIR_DOWN;
    s->row = direction_to_row(DIR_DOWN);

    s->frame = 0;

    s->animTimer = 0;
    s->moveTimer = 0;
}

void snake_set_dir(Snake* s, Direction dir)
{
    s->dir = dir;
    s->row = direction_to_row(dir);
}

void snake_advance_frame(Snake* s)
{
    s->frame++;

    if (s->frame >= ANIM_FRAME_MAX)
    {
        s->frame = 0;
    }
}

void snake_move(Snake* s)
{
    switch (s->dir)
    {
        case DIR_UP:
            s->y -= TILE_SIZE;
            break;

        case DIR_DOWN:
            s->y += TILE_SIZE;
            break;

        case DIR_LEFT:
            s->x -= TILE_SIZE;
            break;

        case DIR_RIGHT:
            s->x += TILE_SIZE;
            break;

        default:
            break;
    }
}

void snake_get_src_rect(const Snake* s, SDL_Rect* out)
{
    out->x = s->frame * TILE_SIZE;
    out->y = s->row * TILE_SIZE;
    out->w = TILE_SIZE;
    out->h = TILE_SIZE;
}

bool snake_check_wall_collision(const Snake* s,
                                const int *map,
                                int map_w,
                                int map_h)
{
    int grid_x = s->x / TILE_SIZE;
    int grid_y = s->y / TILE_SIZE;

    if (grid_x < 0 || grid_x >= map_w ||
        grid_y < 0 || grid_y >= map_h)
    {
        return true;
    }

    if (map[grid_y * map_w + grid_x] == 1)
    {
        return true;
    }

    return false;
}

void snake_reset_position(Snake* s)
{
    s->x = 15 * TILE_SIZE;
    s->y = 7 * TILE_SIZE;
    s->dir = DIR_DOWN;
    s->row = direction_to_row(DIR_DOWN);
    s->frame = 0;
}
