#ifndef SNAKE_H
#define SNAKE_H

#include <SDL2/SDL.h>
#include <stdbool.h>
#define TILE_SIZE 60
#define CHARACTER_SIZE 60

typedef enum { DIR_UP, DIR_DOWN, DIR_LEFT, DIR_RIGHT } Direction;

typedef struct {
    int x;               // pixel X coordinate of the head
    int y;               // pixel Y coordinate of the head
    Direction dir;       // current travelling direction
    int row;             // sprite‑sheet row (0‑7) matching the direction
    int frame;           // animation frame (0‑3)
    Uint32 animTimer;    // accumulator for animation timing
    Uint32 moveTimer;    // accumulator for movement timing
} Snake;

void snake_init(Snake* s, int start_x, int start_y);
void snake_set_dir(Snake* s, Direction dir);
void snake_advance_frame(Snake* s);
void snake_move(Snake* s);
void snake_get_src_rect(const Snake* s, SDL_Rect* out);

bool snake_check_wall_collision(const Snake* s, const int *map, int map_w, int map_h);
void snake_reset_position(Snake* s);

#endif // SNAKE_H
