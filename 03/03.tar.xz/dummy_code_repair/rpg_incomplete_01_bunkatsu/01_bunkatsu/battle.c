/**
 * battle.c  ―  戦闘システム
 *
 * 【このファイルの役割】
 *   ・ダメージ計算  … calc_damage()   ← TODO
 *   ・戦闘ループ    … start_battle()  ← TODO
 *
 * 【戦闘の流れ（実装のイメージ）】
 *   どちらかのHPが0になるまで繰り返す:
 *     1. プレイヤ・敵のステータスを表示
 *     2. プレイヤのコマンドを選択（攻撃 / 回復 / 逃げる）
 *     3. 選択に応じて処理（攻撃なら calc_damage を呼ぶ）
 *     4. 敵のターン（ランダムに行動させる）
 *     5. HP をチェックして勝敗を判定 → 戻り値で返す
 */

#include "header.h"

/* ---------------------------------------------------------
 * calc_damage  ―  ダメージ値を計算する
 *
 * 引数: attack   攻撃側の攻撃力
 *       defense  防御側の防御力
 * 戻値: 与えるダメージ（最低 1 になるようにすること）
 *
 * 【実装のヒント】
 *   ・基本ダメージ = attack - defense
 *   ・ダメージが 1 未満になった場合は 1 に補正する
 *   ・（発展）rand() を使ってダメージにばらつきを持たせてみよう
 *   ・（発展）属性相性による倍率を掛けてみよう
 * --------------------------------------------------------- */
int calc_damage(int attack, int defense)
{
    /* TODO: ダメージを計算して return する */
    int dmg = attack - defense;
    if (dmg < 1) dmg = 1;
    return dmg;

    printf("calc_damage(): 未実装\n"); /* 実装したらこの行を削除する */
}

/* ---------------------------------------------------------
 * start_battle  ―  戦闘のメインループ
 *
 * 引数: player  プレイヤの構造体ポインタ（HP等が書き換わる）
 *       enemy   敵の構造体ポインタ   （HP等が書き換わる）
 * 戻値: BATTLE_WIN         … プレイヤ勝利
 *       BATTLE_PLAYER_DEAD … プレイヤ敗北
 *       BATTLE_ESCAPED     … 逃げた
 *
 * 【実装のヒント】
 *   (1) 敵登場メッセージを printf で表示する
 *       （発展）show_ascii_art(enemy->art_file) でAAも表示する
 *   (2) while(1) でループを作る
 *   (3) ループの中でプレイヤと敵のステータスを表示する
 *   (4) 「1:攻撃 / 2:回復 / 3:逃げる」を表示して fgets で入力を受け取る
 *   (5) 入力に応じて処理を分岐する
 *       1 → calc_damage(player->attack, enemy->defense) でダメージ計算
 *            → enemy->hp を減らす
 *       2 → player->hp を回復する（max_hp を超えないよう注意）
 *       3 → BATTLE_ESCAPED を return する
 *   (6) enemy->hp <= 0 なら BATTLE_WIN を return する
 *   (7) 敵のターン: calc_damage(enemy->attack, player->defense) でダメージ計算
 *            → player->hp を減らす
 *   (8) player->hp <= 0 なら BATTLE_PLAYER_DEAD を return する
 * --------------------------------------------------------- */
BattleResult start_battle(Player *player, Enemy *enemy)
{
    /* TODO: 敵登場メッセージを表示する (1)*/
    printf("%s が飛び出してきた！\n", enemy->name);

    /* TODO: 戦闘ループを実装する (2)*/
    while (1)
    {
        srand((unsigned int)time(NULL));
        // (3)
        printf("\n====================\n");
        printf("%s HP: %d/%d%d\n", player->name, player->hp, player->max_hp);
        printf("%s HP: %d\n", enemy->name, enemy->hp);
        printf("====================\n");
        // (4)
        printf("1:攻撃 2:回復 3:逃げる");

        char buf[16];
        fgets(buf, sizeof(buf), stdin);
        int choice = atoi(buf);

        if(choice < 1 || choice > 3)
        {
            printf("無効な入力です\n");
            continue;
        }
        if(choice == 1)
        {
            int dmg = calc_damage(player->attack, enemy->defense);
            enemy->hp -= dmg;
            // HPマイナスを避ける処理
            if(enemy->hp < 0)
            {
                enemy->hp = 0;
            }
            printf("%sの攻撃！ %sに%dダメージ！\n", player->name, enemy->name, dmg);
        }
        else if(choice == 2)
        {
            int heal = rand()%15 + 1;
            player->hp += heal;
            // HPが最大値より多くなるのを避ける処理
            if(player->hp > player->max_hp)
            {
                player->hp = player->max_hp;
            }
            printf("%d回復した！", heal);
        }
        else if(choice == 3)
        {
            return BATTLE_ESCAPED;
        }
        // 敵を倒したかの判定
        if(enemy->hp = 0);
        printf("%sを倒した！", enemy->name);
        return BATTLE_WIN;
        // 敵のターン
        int dmg = calc_damage(enemy->attack, player->defense);
        player->hp -= dmg;
        // HPマイナスを避ける処理
        if(player->hp < 0)
        {
            player->hp = 0;
        }
        printf("%sの攻撃！ %sに%dダメージ！\n", enemy->name, player->name, dmg);
        // プレイヤーが倒されたかの判定
        if(player->hp == 0)
        {
            return BATTLE_PLAYER_DEAD;
        }
    }

    printf("start_battle(): 未実装\n"); /* 実装したらこの行を削除する */
}
