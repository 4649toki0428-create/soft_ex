/**
 * main.c  ―  RPGゲーム メイン関数
 *
 * 【このファイルの役割】
 *   main.c には「メイン関数だけ」を書く。
 *   個々の処理は map.c / battle.c / resource.c に実装した関数を呼び出す。
 *   ゲームの"進行管理"のみをここで行うイメージ。
 *
 * 【ゲームの流れ】
 *   1. 初期化（マップ・乱数）
 *   2. メインループ
 *        描画 → 入力 → 移動 → イベント判定 → イベント処理
 *   3. ゲーム終了
 *
 * ※ このファイルはすでに完成しています。
 *   map.c / battle.c / resource.c の TODO を実装してください。
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "header.h"

int main(void)
{
    /* 乱数シードの設定 */
    srand((unsigned int)time(NULL));

    /* マップ状態の初期化 */
    MapState map;
    init_map(&map);

    printf(COLOR_CYAN "=== テキストRPG ===\n" COLOR_RESET);
    printf("操作: w=上 s=下 a=左 d=右 q=終了\n\n");

    /* -------------------------------------------------------
     * メインループ
     * ------------------------------------------------------- */
    while (1) {

        /* (1) マップを描画する */
        draw_map(&map);

        /* (2) キー入力を受け付ける */
        char input = get_input();

        /* (3) 'q' なら終了 */
        if (input == 'q') {
            clear_screen();
            printf("ゲームを終了します。\n");
            break;
        }

        /* (4) プレイヤを移動させる */
        move_player(&map, input);

        /* (5) 移動後のマス目でイベントを判定する */
        EventType event = check_event(&map);

        /* (6) イベントの種類に応じて処理を分岐する */
        if (event == EVENT_ENEMY) {

            BattleResult result = start_battle(&map.player, &map.current_enemy);

            if (result == BATTLE_WIN) {
                /* 敵を倒したらマップから消して残り数を減らす */
                map.tiles[map.player_y][map.player_x] = '.';
                map.enemies_remaining--;
                printf(COLOR_YELLOW "敵を倒した！ 残り敵数: %d\n" COLOR_RESET,
                       map.enemies_remaining);
            } else if (result == BATTLE_PLAYER_DEAD) {
                printf(COLOR_RED "\n--- GAME OVER ---\n" COLOR_RESET);
                break;
            }
            /* BATTLE_ESCAPED はそのまま次のループへ */

        } else if (event == EVENT_ITEM) {

            printf(COLOR_GREEN "アイテムを入手した！ %s (+%d HP)\n" COLOR_RESET,
                   map.current_item.name, map.current_item.heal_amount);
            /* HP を回復する（max_hp を超えないよう clamp） */
            map.player.hp += map.current_item.heal_amount;
            if (map.player.hp > map.player.max_hp)
                map.player.hp = map.player.max_hp;

        } else if (event == EVENT_GOAL) {

            if (map.enemies_remaining <= 0) {
                printf(COLOR_CYAN "\n=== GAME CLEAR! ===\n" COLOR_RESET);
                break;
            } else {
                printf(COLOR_YELLOW "まだ敵が残っている！（残り %d 体）\n" COLOR_RESET,
                       map.enemies_remaining);
            }
        }
    }

    return 0;
}
