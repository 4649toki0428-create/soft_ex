/**
 * header.h  ―  RPGゲーム 共通ヘッダ
 *
 * 【ヘッダファイルの役割】
 *   ・構造体定義（型の設計図）
 *   ・関数プロトタイプ宣言（関数の目次）
 *   ・マクロ定義（定数・色コードなど）
 *   ・多重インクルード防止（インクルードガード）
 *
 * このファイルを #include することで、main.c / map.c / battle.c
 * すべてから同じ型・関数が使えるようになる。
 */

#ifndef HEADER_H   /* インクルードガード開始 */
#define HEADER_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/* =========================================================
 * マクロ定義：ANSIカラーコード
 *   printf(COLOR_RED "文字" COLOR_RESET); のように使う
 * ========================================================= */
#define COLOR_RED     "\x1b[31m"
#define COLOR_GREEN   "\x1b[32m"
#define COLOR_YELLOW  "\x1b[33m"
#define COLOR_BLUE    "\x1b[34m"
#define COLOR_CYAN    "\x1b[36m"
#define COLOR_RESET   "\x1b[0m"

/* =========================================================
 * マクロ定義：マップサイズ
 * ========================================================= */
#define MAP_WIDTH  12
#define MAP_HEIGHT  8

/* =========================================================
 * 列挙型：属性
 *   TODO: 属性ごとの相性ボーナスを battle.c の計算に組み込む
 * ========================================================= */
typedef enum {
    ATTR_FIRE  = 0,
    ATTR_WATER,
    ATTR_WOOD,
    ATTR_LIGHT,
    ATTR_DARK,
    ATTR_NONE
} AttributeType;

/* =========================================================
 * 構造体：プレイヤ
 * ========================================================= */
typedef struct {
    char          name[32];
    int           hp;
    int           max_hp;
    int           attack;
    int           defense;
    AttributeType attribute;
    /* TODO: アイテム所持数など追加しても良い */
} Player;

/* =========================================================
 * 構造体：敵キャラクタ
 *   art_file にアスキーアートのファイルパスを入れ、
 *   resource.c の show_ascii_art() で表示する
 * ========================================================= */
typedef struct {
    char          name[32];
    int           hp;
    int           max_hp;
    int           attack;
    int           defense;
    AttributeType attribute;
    char          art_file[128];
    char          dialogue_attack[128];
    char          dialogue_dead[128];
} Enemy;

/* =========================================================
 * 構造体：アイテム
 *   TODO: アイテムをマップ上に配置し、プレイヤが踏んだら
 *         get_item() を呼び出してHPを回復する
 * ========================================================= */
typedef struct {
    char name[32];
    int  heal_amount;
    char art_file[128];
} Item;

/* =========================================================
 * 構造体：マップ状態
 *   tiles[y][x] の各セルの意味:
 *     '#' = 壁  '.' = 通路  'E' = 敵  'I' = アイテム  'G' = ゴール
 * ========================================================= */
typedef struct {
    char   tiles[MAP_HEIGHT][MAP_WIDTH + 1];
    int    player_x;
    int    player_y;
    Player player;
    Enemy  current_enemy;
    Item   current_item;
    int    enemies_remaining;
} MapState;

/* =========================================================
 * 列挙型：イベントの種類（check_event の戻り値）
 * ========================================================= */
typedef enum {
    EVENT_NONE  = 0,
    EVENT_ENEMY,
    EVENT_ITEM,
    EVENT_GOAL
} EventType;

/* =========================================================
 * 列挙型：戦闘結果（start_battle の戻り値）
 * ========================================================= */
typedef enum {
    BATTLE_WIN = 0,
    BATTLE_PLAYER_DEAD,
    BATTLE_ESCAPED
} BattleResult;

/* ---------------------------------------------------------
 * 関数プロトタイプ宣言（map.c）
 * --------------------------------------------------------- */
void      init_map(MapState *map);
void      draw_map(const MapState *map);
void      move_player(MapState *map, char input);
EventType check_event(MapState *map);

/* ---------------------------------------------------------
 * 関数プロトタイプ宣言（battle.c）
 * --------------------------------------------------------- */
BattleResult start_battle(Player *player, Enemy *enemy);
int          calc_damage(int attack, int defense);

/* ---------------------------------------------------------
 * 関数プロトタイプ宣言（resource.c）
 * --------------------------------------------------------- */
void        show_ascii_art(const char *filename);
void        generate_random_enemy(Enemy *enemy);
void        generate_random_item(Item *item);
const char *attribute_to_string(AttributeType attr);
char        get_input(void);
void        clear_screen(void);

#endif /* HEADER_H */
