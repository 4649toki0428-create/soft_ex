/**
 * map.c  ―  マップ管理
 *
 * 【このファイルの役割】
 *   ・マップの初期化・描画         … init_map(), draw_map()    ← 完成済み
 *   ・プレイヤの移動               … move_player()             ← TODO
 *   ・マス目のイベント判定         … check_event()             ← TODO
 */

#include "header.h"

/* =========================================================
 * マップデータ（初期配置）
 *   '#' = 壁  '.' = 通路  'E' = 敵  'I' = アイテム  'G' = ゴール
 *
 * TODO: マップを自由にカスタマイズしてみよう
 * ========================================================= */
static const char INITIAL_MAP[MAP_HEIGHT][MAP_WIDTH + 1] = {
    "############",
    "#@.........#",
    "#.###.###.E#",
    "#.#I......E#",
    "#.#.###.###.",
    "#...E.....G#",
    "#..........#",
    "############"
};

/* ---------------------------------------------------------
 * init_map  ―  マップ状態の初期化（完成済み）
 *
 * 引数: map  初期化する MapState へのポインタ
 * --------------------------------------------------------- */
void init_map(MapState *map)
{
    int y, x;

    /* 初期マップデータをコピー */
    for (y = 0; y < MAP_HEIGHT; y++) {
        for (x = 0; x < MAP_WIDTH; x++) {
            map->tiles[y][x] = INITIAL_MAP[y][x];
        }
        map->tiles[y][MAP_WIDTH] = '\0';
    }

    /* プレイヤの初期座標 */
    map->player_x = 1;
    map->player_y = 1;

    /* プレイヤの初期ステータス */
    strcpy(map->player.name, "勇者");
    map->player.hp        = 50;
    map->player.max_hp    = 50;
    map->player.attack    = 10;
    map->player.defense   =  3;
    map->player.attribute = ATTR_FIRE;

    /* 残り敵数（マップの 'E' の数に合わせる） */
    map->enemies_remaining = 3;
}

/* ---------------------------------------------------------
 * draw_map  ―  マップを画面に描画する（完成済み）
 *
 * 引数: map  描画する MapState への const ポインタ
 * --------------------------------------------------------- */
void draw_map(const MapState *map)
{
    int x, y;

    clear_screen();

    /* プレイヤ情報の表示 */
    printf(COLOR_CYAN "=== テキストRPG ===\n" COLOR_RESET);
    printf("HP %d/%d  攻撃:%d  防御:%d  属性:%s  残り敵:%d\n\n",
           map->player.hp, map->player.max_hp,
           map->player.attack, map->player.defense,
           attribute_to_string(map->player.attribute),
           map->enemies_remaining);

    /* マップ描画ループ */
    for (y = 0; y < MAP_HEIGHT; y++) {
        for (x = 0; x < MAP_WIDTH; x++) {
            if (x == map->player_x && y == map->player_y) {
                printf(COLOR_GREEN "@" COLOR_RESET);
            } else {
                char cell = map->tiles[y][x];
                switch (cell) {
                    case 'E': printf(COLOR_RED    "E" COLOR_RESET); break;
                    case 'I': printf(COLOR_YELLOW "I" COLOR_RESET); break;
                    case 'G': printf(COLOR_BLUE   "G" COLOR_RESET); break;
                    default:  putchar(cell);                        break;
                }
            }
        }
        putchar('\n');
    }

    printf("\n操作: w=上 s=下 a=左 d=右 q=終了\n");
}

/* ---------------------------------------------------------
 * move_player  ―  プレイヤをキー入力に応じて移動させる
 *
 * 引数: map    MapState へのポインタ
 *       input  受け取ったキー文字（'w'/'a'/'s'/'d'）
 *
 * 【実装のヒント】
 *   1. new_x / new_y に現在座標をコピーする
 *   2. input の値（'w','a','s','d'）に応じて new_x か new_y を ±1 する
 *   3. 以下の2つを確認してから map->player_x / player_y を更新する
 *        (a) new_x, new_y がマップの範囲内か？
 *            （0 以上かつ MAP_WIDTH / MAP_HEIGHT 未満）
 *        (b) 移動先のマス map->tiles[new_y][new_x] が壁 '#' でないか？
 * --------------------------------------------------------- */
void move_player(MapState *map, char input)
{
    /* TODO: 移動先の座標を計算する */
    /* int new_x = ...; */
    /* int new_y = ...; */

    /* TODO: input に応じて new_x / new_y を変化させる */
    /* if (input == 'w') ... */
    /* if (input == 's') ... */
    /* if (input == 'a') ... */
    /* if (input == 'd') ... */

    /* TODO: 範囲チェック・壁チェックを行い、問題なければ座標を更新する */
    /* if ( 範囲内 && 壁でない ) { */
    /*     map->player_x = new_x; */
    /*     map->player_y = new_y; */
    /* } */

    printf("move_player(): 未実装\n"); /* 実装したらこの行を削除する */
}

/* ---------------------------------------------------------
 * check_event  ―  プレイヤの現在地のイベントを判定する
 *
 * 引数: map  MapState へのポインタ
 * 戻値: EventType
 *         EVENT_ENEMY … 敵マス('E')に乗った
 *         EVENT_ITEM  … アイテムマス('I')に乗った
 *         EVENT_GOAL  … ゴールマス('G')に乗った
 *         EVENT_NONE  … 何もない
 *
 * 【実装のヒント】
 *   現在地のマスは map->tiles[map->player_y][map->player_x] で取得できる。
 *   'E' のとき → generate_random_enemy(&map->current_enemy) を呼んで
 *                 敵をランダム生成してから EVENT_ENEMY を返す。
 *   'I' のとき → generate_random_item(&map->current_item) を呼び、
 *                 マスを '.' に書き換えてから EVENT_ITEM を返す。
 *   'G' のとき → EVENT_GOAL を返す。
 *   それ以外   → EVENT_NONE を返す。
 * --------------------------------------------------------- */
EventType check_event(MapState *map)
{
    /* TODO: 現在地のマスを取得する */
    /* char tile = map->tiles[map->player_y][map->player_x]; */

    /* TODO: tile の値で分岐して適切な EventType を返す */

    printf("check_event(): 未実装\n"); /* 実装したらこの行を削除する */
    return EVENT_NONE;
}
