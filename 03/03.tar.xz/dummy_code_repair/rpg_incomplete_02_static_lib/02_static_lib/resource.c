/**
 * resource.c  ―  共通リソース管理
 *
 * 【このファイルの役割】
 *   ・テキストファイルの読み込み・表示  … show_ascii_art()        ← TODO
 *   ・敵のランダム生成                  … generate_random_enemy() ← TODO
 *   ・アイテムのランダム生成            … generate_random_item()  ← TODO
 *   ・属性名の文字列変換                … attribute_to_string()   ← TODO
 *   ・入力受付・画面クリア              … get_input(), clear_screen() ← 完成済み
 */

#include "header.h"

/* ---------------------------------------------------------
 * show_ascii_art  ―  テキストファイルを読み込んで1行ずつ表示する
 *
 * 引数: filename  表示するテキストファイルのパス
 *                 例: "assets/enemies/slime.txt"
 *
 * 【実装のヒント】
 *   ・fopen(filename, "r") でファイルを開く
 *   ・fgets() で1行ずつ読み込んで printf() で表示する
 *   ・ループを fgets() が NULL を返すまで繰り返す
 *   ・最後に fclose() でファイルを閉じる
 *   ・fopen が NULL を返した場合（ファイルが存在しない）は何もせず return する
 * --------------------------------------------------------- */
void show_ascii_art(const char *filename)
{
    /* TODO: ファイルを開いて1行ずつ表示する */
    /* FILE *fp = fopen(filename, "r"); */
    /* if (fp == NULL) { return; } */
    /* char line[256]; */
    /* while (fgets(line, sizeof(line), fp) != NULL) { */
    /*     printf("%s", line); */
    /* } */
    /* fclose(fp); */

    printf("show_ascii_art(): 未実装 (file: %s)\n", filename); /* 実装したらこの行を削除 */
}

/* ---------------------------------------------------------
 * generate_random_enemy  ―  敵をランダムに生成する
 *
 * 引数: enemy  生成した情報を書き込む Enemy へのポインタ
 *
 * 【実装のヒント】
 *   ・rand() % N で 0〜N-1 のランダムな整数を得られる
 *   ・switch 文で敵の種類を分岐し、name / hp / attack / defense などを設定する
 *   ・strcpy(enemy->name, "スライム"); のように文字列をコピーする
 *   ・art_file には "assets/enemies/スライム名.txt" のパスを設定する
 *   ・dialogue_attack / dialogue_dead にもセリフファイルのパスを設定する
 *   ・（発展）敵の種類を増やしたり、レベルに応じてパラメータを変えてみよう
 * --------------------------------------------------------- */
void generate_random_enemy(Enemy *enemy)
{
    /* TODO: ランダムに敵の種類を選んでパラメータを設定する */
    /* int type = rand() % 3; */
    /* switch (type) { */
    /*     case 0: ... スライム ... break; */
    /*     case 1: ... ゴブリン ... break; */
    /*     case 2: ... ドラゴン ... break; */
    /* } */

    printf("generate_random_enemy(): 未実装\n"); /* 実装したらこの行を削除 */

    /* 仮の値（関数が未実装でも main.c が動くよう最低限だけ設定） */
    strcpy(enemy->name, "？？？");
    enemy->hp = enemy->max_hp = 10;
    enemy->attack  = 3;
    enemy->defense = 0;
    enemy->attribute = ATTR_NONE;
    strcpy(enemy->art_file,        "assets/enemies/slime.txt");
    strcpy(enemy->dialogue_attack, "assets/dialogue/slime_attack.txt");
    strcpy(enemy->dialogue_dead,   "assets/dialogue/slime_dead.txt");
}

/* ---------------------------------------------------------
 * generate_random_item  ―  アイテムをランダムに生成する
 *
 * 引数: item  生成した情報を書き込む Item へのポインタ
 *
 * 【実装のヒント】
 *   ・rand() % N でアイテムの種類をランダムに選ぶ
 *   ・name / heal_amount / art_file を設定する
 *   ・（発展）アイテムの種類を増やしてみよう
 * --------------------------------------------------------- */
void generate_random_item(Item *item)
{
    /* TODO: ランダムにアイテムの種類を選んでパラメータを設定する */
    /* int type = rand() % 2; */
    /* switch (type) { */
    /*     case 0: ... ポーション ... break; */
    /*     case 1: ... 宝箱 ...     break; */
    /* } */

    printf("generate_random_item(): 未実装\n"); /* 実装したらこの行を削除 */

    /* 仮の値 */
    strcpy(item->name, "？？？");
    item->heal_amount = 0;
    strcpy(item->art_file, "assets/items/potion.txt");
}

/* ---------------------------------------------------------
 * attribute_to_string  ―  AttributeType を日本語文字列に変換する
 *
 * 引数: attr  AttributeType 列挙値
 * 戻値: 属性名の文字列ポインタ
 *
 * 【実装のヒント】
 *   ・switch 文で attr の値ごとに対応する文字列を return する
 *   ・文字列リテラルはそのまま return してよい（静的な定数なので free 不要）
 * --------------------------------------------------------- */
const char *attribute_to_string(AttributeType attr)
{
    /* TODO: attr の値に応じた文字列を return する */
    /* switch (attr) { */
    /*     case ATTR_FIRE:  return "火"; */
    /*     case ATTR_WATER: return "水"; */
    /*     ... */
    /* } */

    return "？"; /* 実装したら switch に置き換える */
}

/* ---------------------------------------------------------
 * get_input  ―  ユーザのキー入力を1文字受け取る（完成済み）
 *
 * 戻値: 入力された先頭の文字（EOF や失敗時は 'q'）
 *
 * ※ scanf ではなく fgets を使うことで、余分な入力が stdin に
 *    残るのを防いでいる
 * --------------------------------------------------------- */
char get_input(void)
{
    char buf[128];
    printf("> ");
    if (fgets(buf, sizeof(buf), stdin) == NULL) {
        return 'q';
    }
    return buf[0];
}

/* ---------------------------------------------------------
 * clear_screen  ―  ターミナル画面をクリアする（完成済み）
 * --------------------------------------------------------- */
void clear_screen(void)
{
    printf("\x1b[2J\x1b[H");
}
